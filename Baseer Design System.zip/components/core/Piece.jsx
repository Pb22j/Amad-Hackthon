import React from 'react';

const FILL={cream:'var(--cream)',blue:'var(--blue)',orange:'var(--orange)',green:'var(--green)',red:'var(--red)',ink:'var(--ink)',faint:'var(--ink-faint)'};
const TEXT={blue:'var(--cream)',red:'var(--cream)',ink:'var(--cream)'};

export function cutVar(cut){return cut==='circle'?'var(--circle)':cut==='torn'?'var(--torn)':'var(--cut-'+(cut||1)+')';}

export function Piece({as='div',color='cream',cut=1,lift=false,tilt=0,style,children,...rest}){
  const t=[];
  if(tilt) t.push('rotate('+tilt+'deg)');
  if(style&&style.transform) t.push(style.transform);
  return React.createElement(as,{...rest,style:{position:'relative',isolation:'isolate',color:TEXT[color]||'var(--ink)',filter:lift?'var(--lift)':undefined,...style,transform:t.length?t.join(' '):undefined}},
    React.createElement('span',{'aria-hidden':true,style:{position:'absolute',inset:0,zIndex:-1,backgroundColor:FILL[color]||color,backgroundImage:'var(--grain)',clipPath:cutVar(cut),pointerEvents:'none'}}),
    children);
}
