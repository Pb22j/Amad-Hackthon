Onboarding progress bars shown in the top bar during the setup flow.
```jsx
<StepIndicator count={4} current={2} />
```
