The single app header. Put a StepIndicator (onboarding) or NavTabs (home) inside.
```jsx
<TopBar onHome={home}><StepIndicator current={2}/></TopBar>
```
