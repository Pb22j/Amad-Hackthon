import React from 'react';

export function Assistant({state='idle',onClick,label}){
  const labels={idle:'تكلّم مع بصير',listening:'بصير يسمعك',speaking:'بصير يتكلم'};
  const hs=[8,18,12,22],delays=['0s','-.3s','-.6s','-.15s'];
  return React.createElement('button',{type:'button',onClick,'aria-label':label||labels[state],style:{position:'relative',width:72,height:72,flex:'none',border:0,padding:0,background:'none',cursor:'pointer',display:'grid',placeItems:'center',color:'var(--ink)'}},
    React.createElement('span',{'aria-hidden':true,style:{position:'absolute',inset:0,backgroundColor:'var(--orange)',backgroundImage:'var(--grain)',clipPath:'var(--circle)'}}),
    React.createElement('span',{'aria-hidden':true,style:{position:'absolute',inset:-10,border:'2px dashed var(--ink)',borderRadius:'50%',opacity:state==='listening'?1:0,animation:state==='listening'?'bs-spin 6s linear infinite':'none'}}),
    React.createElement('span',{'aria-hidden':true,style:{position:'relative',display:'flex',gap:3,alignItems:'center',height:26}},
      hs.map((h,i)=>React.createElement('i',{key:i,style:{display:'block',width:4,height:h,background:'var(--ink)',animation:state==='speaking'?'bs-bar .9s ease-in-out infinite alternate':'none',animationDelay:delays[i]}}))));
}
