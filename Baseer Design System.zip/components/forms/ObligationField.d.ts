/** A secondary numeric input printed on a lifted paper tile (rent, loans, expenses). */
export interface ObligationFieldProps{
  label?:string;
  value?:string;
  /** faint hint, default 0 */
  placeholder?:string;
  onChange?:(v:string)=>void;
  cut?:1|2|3|4;
  tilt?:number;
  color?:'cream'|'orange'|'green'|'blue'|'red';
}
export declare function ObligationField(props:ObligationFieldProps):JSX.Element;
