Allocation tile for one stock; four of them wrap in a centered row (gap 28).
```jsx
<StockCard name="أرامكو" amount={300} color="blue" onInc={inc} onDec={dec} />
```
- Source palette: أرامكو blue c1, الراجحي green c2 −2°, STC orange c3, سابك red c4 +2°.
