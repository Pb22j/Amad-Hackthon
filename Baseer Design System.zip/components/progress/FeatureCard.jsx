import React from 'react';
import { Piece } from '../core/Piece.jsx';

export function FeatureCard({icon,title,body,children,cut=2,color='cream',centered=false}){
  return React.createElement(Piece,{as:'article',color,cut,lift:true,style:{padding:32,display:'flex',flexDirection:'column',gap:12,alignItems:centered?'center':'flex-start',justifyContent:centered?'center':undefined,textAlign:centered?'center':undefined,minWidth:0}},
    icon||null,
    title?React.createElement('h2',{style:{font:'var(--type-title)',margin:0}},title):null,
    body?React.createElement('p',{style:{font:'var(--type-body)',margin:0,color:'var(--ink-muted)'}},body):null,
    children?React.createElement('div',{style:{marginTop:8}},children):null);
}
