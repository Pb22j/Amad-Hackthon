import * as React from 'react';
/** Achievement sticker: a tilted lifted paper scrap with a short phrase. */
export interface BadgeProps{
  color?:'orange'|'green'|'blue'|'red'|'cream';
  cut?:1|2|3|4;
  /** degrees, default -2 */
  tilt?:number;
  style?:React.CSSProperties;
  children?:React.ReactNode;
}
export declare function Badge(props:BadgeProps):JSX.Element;
