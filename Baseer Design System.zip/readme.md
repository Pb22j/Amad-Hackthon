# Baseer (بصير) Design System

بصير is a financial gamification platform that teaches Saudi employees to invest using a virtual portfolio built on their real salary, guided by a voice assistant that speaks Saudi dialect. Identity: cut and torn paper collage. Arabic, RTL.

## Sources
- `بصير/baseer.html` (local mount) — single-file web prototype; copied to `source/baseer.html`. Ground truth for every value here.
- `Thmanyah-Font-Family/` (local mount) — Thmanyah Sans / Serif Display / Serif Text, 5 weights each, woff2 copied to `fonts/` (licence: `fonts/LICENSE.pdf`).
- Brand brief: colours cream #F2EFE3, ink #1A1A1A, blue #3C5AA6, orange #E8833A, green #4F8F5E, red #C63B2D; Thmanyah family.

Product surfaces: one — the responsive web app (onboarding → portfolio → challenge → journey).

## Content fundamentals
- Language: Saudi colloquial Arabic (Najdi/Hijazi everyday register), not MSA. «وش يصير لو نزل السوق كله 10%؟», «ليش؟», «وقف وقف!», «لا تستحي، هذا سؤال زين.»
- Voice: a friendly, slightly cheeky older friend. Addresses the user as أنت, masculine singular (راتبك، محفظتك، كمّل رحلتك). The assistant speaks as بصير in first person («أسمعك…»).
- One idea per screen; headlines are questions or short verdicts: «كم راتبك؟», «فلوسك موجودة… بس هل تشتغل؟», «أنت مبتدئ… وماشي صح».
- Progress is always stars (تقييمك 3 من 5), never a numeric score or "درجة".
- Buttons: imperative verb-first, 1–4 words: «ابدأ رحلتك», «احسب هامشي», «وزّع لي», «جرّب هبوط السوق».
- Numbers: Western digits with en-US separators (8,000), currency word «ريال» after the number, arrows for direction (↓15%). Always the disclaimer «كل الأرقام أمثلة توضيحية».
- Ellipsis «…» for conversational pauses. No emoji. No exclamation spam (one per coach interruption at most).

## Visual foundations
- **World:** a single light "paper" world — cream page, everything else is a piece of coloured paper laid on it. No dark mode.
- **Colour:** blue = primary action / current; orange = the assistant and rewards; green = gain / done; red = loss. Cream text on blue & red, ink text on orange & green. Neutrals are ink at alpha (72% muted text, 60% outlines, 16% lines, 6% flat inactive paper).
- **Type:** Thmanyah Serif Display (700/900) for hero, headlines, titles and every big number; Serif Text (400/500) for leads, body and coach speech; Sans (500/700) for buttons, labels, nav and captions. Generous Arabic line-heights (1.35 hero → 1.75 body). Tabular numerals on all figures.
- **Paper pieces:** fill + `--grain` noise, clipped with `--cut-1…4` (slightly irregular rectangles) or `--circle`. Neighbours use different cuts. `--lift` (double drop-shadow) puts a piece above the page; rotations of ±1–2° add hand-placed feel.
- **Backgrounds:** flat cream. The only illustration is the welcome-screen collage band: torn blue sheet (`--torn`) with flat cut shapes. No photos, no gradients.
- **Corners:** radius 0 everywhere — softness comes only from the cut edge. Circles are polygon discs (assistant, score).
- **Borders:** 2px `--line-strong` for ghost buttons and the fullscreen square; 2px currentColor for steppers; 3px ink underline for the big amount input.
- **Shadows:** only `--lift`. No inner shadows, no blur, no transparency effects beyond ink alphas.
- **Motion:** screens enter with fade + 10px rise (.45s ease). Hover on buttons tilts paper -1° and scales 1.03 (.15s). Assistant: dashed ring spins 6s linear when listening; 4 bars bounce .9s alternate when speaking. All disabled under reduced motion. No bounces/springs.
- **States:** hover = tilt/scale; disabled = 40% (steppers 35%); empty stock tile = 45%; focus = 2px ink outline, 3px offset. No colour-darkening hovers.
- **Layout:** header 28px vertical / clamp(16,5vw,80) sides; screens padded clamp(16,6vw,120) with 140px bottom room; floating assistant fixed bottom-left; disclaimer pinned bottom-centre. Content centred, one primary action per screen. Buttons 60px tall, 44px min hit target.
- **Cards:** cream lifted paper, 32px padding, 12px gap, no border, no radius.

## Iconography
- No icon font or icon set. Icons are flat single-colour cut-paper silhouettes (inline SVG in source, extracted to `assets/shape-*.svg`): blue hexagon, green trapezoid, orange flame.
- UI glyphs are Unicode: ← (level path separators), ↓/↑ (change), + / − (steppers).
- One stroke icon: fullscreen corners (`assets/icon-fullscreen.svg`, 2px currentColor).
- No emoji. **Logo:** none provided — the wordmark is «بصير» set in Serif Display 900 (`Wordmark` component). Do not draw a logo.

## Index
- `styles.css` — entry; imports `tokens/fonts.css, colors.css, typography.css, spacing.css, paper.css, base.css`.
- `fonts/` — Thmanyah woff2. `assets/` — collage band, shapes, fullscreen icon. `source/` — original prototype.
- `guidelines/` — foundation cards (Colors, Type, Spacing, Paper, Brand).
- `components/` — core: Button, Piece, Badge, Wordmark · navigation: TopBar, StepIndicator, NavTabs · forms: AmountField, ObligationField · assistant: Assistant, CoachBubble, AssistantTip · finance: StockCard, OutcomeCard, Figure · progress: StarRating, LevelPath, FeatureCard · brand: CollageBand.
- `ui_kits/baseer-app/` — click-through recreation of the web app.
- `SKILL.md` — agent skill entry.

### Intentional additions
- `Piece` — exposes the source's `.piece` CSS pattern as a component so other parts can share it.
- `Figure`, `Wordmark`, `TopBar` — named wrappers for source patterns (`.figure-val`/`.points`, `.mark`, `.top`).
