Before/after or this-vs-that result tiles on the challenge result screen.
```jsx
<OutcomeCard label="سابك لحاله" value="↓15%" color="red" tilt={2}/>
<OutcomeCard label="محفظتك المتنوعة" value="↓4%" color="green" cut={3} tilt={-1} emphasis/>
```
