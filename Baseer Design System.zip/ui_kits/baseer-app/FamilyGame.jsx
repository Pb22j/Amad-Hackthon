(()=>{
const {Piece,Button}=window.BaseerDesignSystem_f0524d;
const WHO={abu:{n:'خالك أبو فهد',c:'blue',cut:1},cousin:{n:'ولد عمك',c:'green',cut:2},aunt:{n:'عمتك',c:'orange',cut:3}};
const MSG1=[['abu','شباب السهم الفلاني بيطير بكرة!! 🚀🚀'],['cousin','أنا دخلت بكل فلوسي 😎'],['abu','ولد خويي ربح الضعف بأسبوع'],['aunt','الله يرزقكم 🤲']];
const MSG2=[['abu','شباب… السهم نزل 30% 😅'],['cousin','😶']];
const WARN=['ارتفع 60% في أسبوع بدون خبر رسمي','ما حققت أرباح آخر سنتين','أغلب الكلام عنه في القروبات، مو في الإعلانات الرسمية'];
const tag=<GameTag n={2} icon="📱" name="قروب العيلة"/>;
function Bubble({who,text,i,delay}){const w=WHO[who];
  return <div style={{alignSelf:'flex-start',maxWidth:'90%',animation:'bs-deal .45s cubic-bezier(.2,.8,.2,1) both',animationDelay:delay+'ms'}}>
    <Piece color={w.c} cut={w.cut} lift tilt={[-1,1,-.5,.5][i%4]} style={{padding:'10px 20px 12px'}}>
      <b style={{display:'block',font:'700 13px/1.5 var(--f-sans)'}}>{w.n}</b>
      <span style={{font:'500 18px/1.6 var(--f-text)'}}>{text}</span>
    </Piece></div>;}
function Chat({week=false}){
  return <section aria-label="محادثة العيلة" style={{width:420,flex:'none',display:'flex',flexDirection:'column',gap:12}}>
    <div style={{display:'flex',gap:12,alignItems:'center'}}>
      <Piece color="ink" cut={4} lift tilt={-1} style={{padding:'12px 22px',font:'700 20px/1.3 var(--f-display)'}}>العيلة 🏠</Piece>
      <span style={{font:'var(--type-caption)',color:'var(--ink-muted)'}}>4 أعضاء</span>
    </div>
    <Piece color="faint" cut={1} style={{padding:'20px 18px',display:'flex',flexDirection:'column',gap:12}}>
      {MSG1.map((m,i)=><Bubble key={'a'+i} who={m[0]} text={m[1]} i={i} delay={week?0:150+i*260}/>)}
      {week&&<><div style={{alignSelf:'center',margin:'4px 0'}}><Chip color="cream" lift>بعد أسبوع</Chip></div>
        {MSG2.map((m,i)=><Bubble key={'b'+i} who={m[0]} text={m[1]} i={i+1} delay={500+i*600}/>)}</>}
    </Piece>
  </section>;
}
const Layout=({children,week})=><main style={{...bsScreen,gap:16}}>{tag}<div style={{flex:1,display:'flex',gap:56,alignItems:'center',justifyContent:'center'}}><Chat week={week}/><section style={{display:'flex',flexDirection:'column',gap:26,alignItems:'center',maxWidth:640,minWidth:0}}>{children}</section></div></main>;
function FamilyPlay({go,put}){
  return <Layout>
    <h1 style={{font:'var(--type-headline)',margin:0}}>وش بتسوي؟</h1>
    <div style={{display:'flex',gap:20}}>
      <ChoiceCard i={0} icon="🔥" label="أدخل بكل فلوسي" cut={1} tilt={-1.5} w={180} h={190} onClick={()=>{put({familyChoice:'all'});go('family-week');}}/>
      <ChoiceCard i={1} icon="🤏" label="أدخل بجزء صغير" cut={3} tilt={1} w={180} h={190} onClick={()=>{put({familyChoice:'part'});go('family-week');}}/>
      <ChoiceCard i={2} icon="🔍" label="أتحقق أول" cut={4} tilt={-.5} w={180} h={190} onClick={()=>go('family-verify')}/>
    </div>
  </Layout>;
}
function FamilyVerify({go,put}){
  const flip=useLater(350);
  const c=(k,i,ic,l,cut)=><ChoiceCard key={k} i={i} icon={ic} label={l} cut={cut} w={160} h={120} onClick={()=>{put({familyChoice:k});go('family-week');}}/>;
  return <Layout>
    <Flip w={480} h={260} flipped={flip} color="cream" backColor="cream" front={<span style={{font:'var(--type-title)'}}>🔍 معلومات السهم</span>}
      back={<div style={{display:'flex',flexDirection:'column',gap:10,width:'100%'}}>
        <span style={{font:'700 16px/1.4 var(--f-sans)',textAlign:'right'}}>لقيت 3 علامات تحذير:</span>
        {WARN.map((w,i)=><Piece key={i} color="orange" cut={i+1} style={{padding:'9px 16px',font:'700 15px/1.45 var(--f-sans)',textAlign:'right',animation:'bs-in .35s ease both',animationDelay:(800+i*200)+'ms'}}>⚠ {w}</Piece>)}</div>}/>
    <div style={{display:'flex',gap:16}}>{c('all',0,'🔥','أدخل بكل فلوسي',1)}{c('part',1,'🤏','أدخل بجزء صغير',3)}{c('none',2,'✋','ما أدخل',2)}</div>
  </Layout>;
}
function FamilyWeek({go,S}){
  const ch=S.familyChoice;
  return <Layout week>
    <div style={{animation:'bs-drop .7s cubic-bezier(.3,1.3,.5,1) both'}}>
      <Piece color="cream" cut="torn" lift tilt={-3} style={{padding:'38px 80px 32px',font:'900 clamp(48px,6vw,76px)/1.2 var(--f-display)'}}>بعد أسبوع…</Piece></div>
    <Chip color={ch==='all'?'red':'faint'}>{ch==='all'?'أنت دخلت بكل فلوسك':ch==='part'?'أنت دخلت بجزء صغير':'أنت ما دخلت'}</Chip>
    <Button onClick={()=>go(ch==='all'?'family-lose':'family-win')}>شوف النتيجة</Button>
  </Layout>;
}
function FamilyWin({go,S,onWin}){
  const part=S.familyChoice==='part',loss=Math.round(S.budget*.1*.3);
  return <Result id="family" win tag={tag} go={go} onWin={onWin} headline="كفو! القروب مو مصدر استثمار" lesson="لا تستثمر بناءً على إشاعة."
    scene={<Piece color="green" cut={3} lift tilt={-2} style={{padding:'34px 44px',font:'900 32px/1.4 var(--f-display)',textAlign:'center',maxWidth:340,fontVariantNumeric:'tabular-nums'}}>{part?'خسرت '+bsFmt(loss)+' بس، والباقي سليم':'فلوسك سليمة 100%'}</Piece>}/>;
}
function FamilyLose({go,S,onWin}){
  return <Result id="family" tag={tag} go={go} onWin={onWin} lesson="سمعت إن السهم زين؟ هذي بالضبط الجملة اللي نبيك تنساها."
    scene={<Torn color="red"><span style={{font:'900 34px/1.3 var(--f-display)',fontVariantNumeric:'tabular-nums'}}>خسرت {bsFmt(S.budget*.3)} ريال</span></Torn>}/>;
}
Object.assign(window,{FamilyPlay,FamilyVerify,FamilyWeek,FamilyWin,FamilyLose});
})();
