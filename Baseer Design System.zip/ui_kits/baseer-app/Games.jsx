(()=>{
const {Piece,Assistant,CoachBubble,StarRating,Button}=window.BaseerDesignSystem_f0524d;
const bsCol={display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',textAlign:'center'};
function useTween(target,ms=900){
  const [v,setV]=React.useState(target);const from=React.useRef(target);
  React.useEffect(()=>{let raf,st;const a=from.current;
    const tick=ts=>{if(!st)st=ts;const p=Math.min(1,(ts-st)/ms);const x=a+(target-a)*(1-Math.pow(1-p,3));setV(x);from.current=x;if(p<1)raf=requestAnimationFrame(tick);};
    raf=requestAnimationFrame(tick);return()=>cancelAnimationFrame(raf);},[target]);
  return v;
}
function useLater(ms=500){const [on,setOn]=React.useState(false);React.useEffect(()=>{const t=setTimeout(()=>setOn(true),ms);return()=>clearTimeout(t);},[]);return on;}
function Flip({flipped,front,back,w=220,h=160,color='cream',backColor='blue',cut=2,backCut=3}){
  const face={position:'absolute',inset:0,backfaceVisibility:'hidden',WebkitBackfaceVisibility:'hidden'};
  return <div style={{width:w,height:h,perspective:1000,flex:'none'}}>
    <div style={{position:'relative',width:'100%',height:'100%',transformStyle:'preserve-3d',transition:'transform .8s cubic-bezier(.3,1.3,.5,1)',transform:flipped?'rotateY(180deg)':'none'}}>
      <div style={face}><Piece color={color} cut={cut} lift style={{width:'100%',height:'100%',...bsCol,gap:6,padding:16}}>{front}</Piece></div>
      <div style={{...face,transform:'rotateY(180deg)'}}><Piece color={backColor} cut={backCut} lift style={{width:'100%',height:'100%',...bsCol,gap:6,padding:16}}>{back}</Piece></div>
    </div>
  </div>;
}
function Torn({color='red',w=340,h=150,children}){
  const L='polygon(0 0,52% 0,47% 18%,54% 35%,46% 55%,53% 72%,48% 100%,0 100%)';
  const R='polygon(52% 0,100% 0,100% 100%,48% 100%,53% 72%,46% 55%,54% 35%,47% 18%)';
  const half=(cp,a)=><div style={{position:'absolute',inset:0,clipPath:cp,animation:a+' .9s cubic-bezier(.3,1.2,.5,1) .6s both'}}><Piece color={color} cut={2} style={{width:'100%',height:'100%',...bsCol,padding:16}}>{children}</Piece></div>;
  return <div style={{position:'relative',width:w,height:h,filter:'var(--lift)'}}>{half(L,'bs-tearL')}{half(R,'bs-tearR')}</div>;
}
function TalkingOrb({text,big=false,hype=false,color='orange',speaker}){
  return <div style={{display:'flex',gap:big?44:20,alignItems:'flex-end',direction:'ltr',maxWidth:big?680:640}}>
    <div style={{flex:'none',transform:big?'scale(1.6)':'none',transformOrigin:'left bottom'}}>
      <div style={{animation:hype?'bs-hype .45s ease-in-out infinite alternate':'none'}}><Assistant state="speaking"/></div>
    </div>
    {text&&<div key={text} dir="rtl" style={{textAlign:'right',marginBottom:big?70:30,transformOrigin:'left bottom',animation:'bs-pop .45s cubic-bezier(.3,1.4,.5,1) .3s both'}}>
      <CoachBubble color={color} speaker={speaker}>{text}</CoachBubble></div>}
  </div>;
}
const LENS='polygon(0% 50%,8% 38%,18% 27%,30% 18%,42% 13%,50% 12%,58% 13%,70% 18%,82% 27%,92% 38%,100% 50%,92% 62%,82% 73%,70% 82%,58% 87%,50% 88%,42% 87%,30% 82%,18% 73%,8% 62%)';
function EyeOrb({alert=false}){
  const s=alert?120:64,c=alert?'var(--red)':'var(--blue)';
  const dot=(k,bg)=><span style={{position:'absolute',left:'50%',top:'50%',width:s*k,height:s*k,marginLeft:-s*k/2,marginTop:-s*k/2,background:bg,backgroundImage:'var(--grain)',clipPath:'var(--circle)'}}></span>;
  return <div role="img" aria-label={alert?'مراقب المخاطر ينبهك':'مراقب المخاطر'} style={{position:'relative',width:s*1.6,height:s,flex:'none',filter:'var(--lift)',animation:alert?'bs-shake .5s ease-in-out 3':'none'}}>
    <span style={{position:'absolute',inset:0,background:c,backgroundImage:'var(--grain)',clipPath:LENS}}></span>
    <span style={{position:'absolute',inset:'15% 11%',background:'var(--cream)',clipPath:LENS}}></span>
    {dot(.54,c)}{dot(.24,'var(--ink)')}
  </div>;
}
function GameTag({n,icon,name}){return <div style={{alignSelf:'flex-start'}}><Piece color="faint" cut={2} style={{padding:'8px 18px',font:'700 15px/1.4 var(--f-sans)',display:'inline-flex',gap:8,whiteSpace:'nowrap',flex:'none'}}><span>اللعبة {n}</span><span aria-hidden="true">·</span><span>{name} {icon}</span></Piece></div>;}
function ChoiceCard({icon,label,sub,on,onClick,cut=2,tilt=0,w=200,h=170,i=0,children}){
  const [hv,setHv]=React.useState(false);
  return <div style={{animation:'bs-deal .5s cubic-bezier(.2,.8,.2,1) both',animationDelay:(i*90)+'ms'}}>
    <Piece as="button" type="button" aria-pressed={on?'true':'false'} onClick={onClick} onMouseEnter={()=>setHv(true)} onMouseLeave={()=>setHv(false)} color={on?'blue':'cream'} cut={cut} lift tilt={on?-2:tilt}
      style={{border:0,background:'none',cursor:'pointer',width:w,minHeight:h,padding:'18px 16px',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:10,textAlign:'center',transition:'transform .15s',transform:hv&&!on?'scale(1.04)':undefined}}>
      {icon&&<span style={{fontSize:40,lineHeight:1}}>{icon}</span>}
      {children}
      <span style={{font:'700 19px/1.4 var(--f-sans)'}}>{label}</span>
      {sub&&<span style={{font:'500 14px/1.4 var(--f-sans)',opacity:.85}}>{sub}</span>}
    </Piece></div>;
}
const PLAY={d27:'d27-play',family:'family-play',team:'team-pick',coaster:'coaster-play',ice:'ice-play'};
function Result({id,win,tag,headline,lesson,scene,go,onWin}){
  React.useEffect(()=>{if(win)onWin(id);},[]);
  return <main style={{...bsScreen,gap:20}}>
    {tag}
    <div style={{flex:1,display:'flex',gap:'40px 64px',alignItems:'center',justifyContent:'center',flexWrap:'wrap'}}>
      {scene&&<div style={{flex:'none',animation:'bs-deal .6s cubic-bezier(.2,.8,.2,1) both'}}>{scene}</div>}
      <div style={{display:'flex',flexDirection:'column',gap:24,alignItems:'flex-start',maxWidth:600,minWidth:0}}>
        <div style={{display:'flex',gap:20,alignItems:'center'}}>
          <StarRating value={win?1:0} max={1} size={84} animate delay={250} label={win?'كسبت نجمة':'ما كسبت نجمة'}/>
          <div style={{display:'flex',flexDirection:'column',gap:4}}>
            <span style={{font:'var(--type-label)',color:'var(--ink-muted)'}}>{win?'نجحت · +1 نجمة':'ما نجحت هالمرة'}</span>
            {headline&&<h1 style={{font:'900 clamp(30px,3.4vw,42px)/1.35 var(--f-display)',margin:0,textWrap:'balance'}}>{headline}</h1>}
          </div>
        </div>
        <TalkingOrb text={lesson}/>
        <div style={{display:'flex',gap:16,flexWrap:'wrap'}}>
          {win?<Button onClick={()=>go('journey',{fly:id})}>ارجع للرحلة</Button>:<><Button onClick={()=>go(PLAY[id])}>جرّب مرة ثانية</Button><Button variant="ghost" onClick={()=>go('journey')}>ارجع للرحلة</Button></>}
        </div>
      </div>
    </div>
  </main>;
}
function Chip({color='faint',children,tilt=0,cut=2,big=false,lift=false}){return <Piece as="span" color={color} cut={cut} tilt={tilt} lift={lift} style={{display:'inline-flex',padding:big?'12px 26px':'6px 14px',font:(big?'700 22px':'700 15px')+'/1.4 var(--f-sans)',whiteSpace:'nowrap'}}><span>{children}</span></Piece>;}
Object.assign(window,{bsCol,useTween,useLater,Flip,Torn,TalkingOrb,EyeOrb,GameTag,ChoiceCard,Result,Chip});
})();
