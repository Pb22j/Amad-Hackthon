import React from 'react';

export function NavTabs({items=[],current,onChange}){
  return React.createElement('nav',{'aria-label':'التنقل',style:{display:'flex',gap:6}},items.map(it=>{
    const on=it.id===current;
    return React.createElement('button',{key:it.id,type:'button','aria-current':on?'page':undefined,onClick:()=>onChange&&onChange(it.id),style:{position:'relative',isolation:'isolate',background:'none',border:0,padding:'10px 16px',font:'700 16px/1 var(--f-sans)',cursor:'pointer',color:on?'var(--cream)':'var(--ink-muted)'}},
      on?React.createElement('span',{'aria-hidden':true,style:{position:'absolute',inset:0,zIndex:-1,background:'var(--blue)',clipPath:'var(--cut-2)'}}):null,it.label);
  }));
}
