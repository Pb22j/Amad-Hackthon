import React from 'react';

const STAR='polygon(50% 1%,62% 35%,98.5% 36%,69% 58%,80% 95%,50% 73%,19.5% 94%,31% 57.5%,1.5% 35%,38.5% 34%)';

export function StarRating({value=0,max=5,size=56,gap,animate=false,delay=0,step=260,label}){
  const stars=[];
  for(let i=0;i<max;i++){
    const fill=Math.max(0,Math.min(1,value-i));
    const piece=(bg,extra)=>React.createElement('span',{style:{position:'absolute',top:0,insetInlineStart:0,width:size,height:size,backgroundColor:bg,backgroundImage:'var(--grain)',clipPath:STAR,...extra}});
    stars.push(React.createElement('span',{key:i,style:{position:'relative',width:size,height:size,flex:'none',transform:'rotate('+[-4,3,-2,4,-3][i%5]+'deg)'}},
      piece('rgba(26,26,26,.1)'),
      fill>0?React.createElement('span',{style:{position:'absolute',top:0,insetInlineStart:0,width:(fill*100)+'%',height:size,overflow:'hidden',filter:'var(--lift)',animation:animate?'bs-pop .45s cubic-bezier(.3,1.5,.5,1) both':'none',animationDelay:(delay+i*step)+'ms'}},piece('var(--orange)')):null));
  }
  return React.createElement('div',{role:'img','aria-label':label||('تقييمك '+value+' من '+max),style:{display:'flex',gap:gap??Math.round(size*.18),alignItems:'center'}},stars);
}
