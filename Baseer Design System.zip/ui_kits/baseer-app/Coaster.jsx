(()=>{
const {Piece,Button}=window.BaseerDesignSystem_f0524d;
const CP=[[0,.30],[.12,.12],[.26,.48],[.38,.28],[.56,.86],[.74,.40],[.86,.14],[1,.06]];
const yAt=x=>{for(let i=0;i<CP.length-1;i++){const [x0,y0]=CP[i],[x1,y1]=CP[i+1];if(x<=x1){const m=(1-Math.cos((x-x0)/(x1-x0)*Math.PI))/2;return y0*(1-m)+y1*m;}}return CP[CP.length-1][1];};
const DIP=.56,TOPX=.9;
const tag=<GameTag n={4} icon="🎢" name="القطار الأفعواني"/>;
function Track({W=1000,H=340,cartX=DIP,ghostX,labels}){
  const N=64,strips=[],sup=[];
  for(let i=0;i<N;i++){const a=i/N,b=(i+1)/N,x0=a*W,y0=yAt(a)*H,x1=b*W,y1=yAt(b)*H,len=Math.hypot(x1-x0,y1-y0),ang=Math.atan2(y1-y0,x1-x0)*180/Math.PI,mx=(x0+x1)/2,my=(y0+y1)/2;
    strips.push(<span key={i} style={{position:'absolute',left:mx-len/2-1,top:my-5,width:len+3,height:10,background:i%2?'var(--ink)':'#2a2a2a',transform:'rotate('+ang+'deg)'}}></span>);
    if(i%5===2)sup.push(<span key={'s'+i} style={{position:'absolute',left:mx-3,top:my,width:6,height:H-my+20,background:'var(--line)'}}></span>);}
  const cart=(x,ghost)=>{const y=yAt(x)*H,ang=Math.atan2(yAt(x+.01)*H-yAt(x-.01)*H,.02*W)*180/Math.PI;
    return <div style={{position:'absolute',left:x*W,top:y-5,transform:'translate(-50%,-100%) rotate('+ang+'deg)',transformOrigin:'50% 100%',zIndex:2,opacity:ghost?.35:1}}>
      <Piece color={ghost?'cream':'orange'} cut={3} lift={!ghost} style={{width:120,height:54,display:'grid',placeItems:'center',font:'700 17px/1 var(--f-sans)',outline:ghost?'2px dashed var(--ink)':'none'}}>محفظتك</Piece>
      <span style={{position:'absolute',bottom:-8,left:18,width:16,height:16,background:'var(--ink)',clipPath:'var(--circle)'}}></span>
      <span style={{position:'absolute',bottom:-8,right:18,width:16,height:16,background:'var(--ink)',clipPath:'var(--circle)'}}></span>
    </div>;};
  return <div style={{position:'relative',width:W,height:H+20,direction:'ltr',flex:'none'}}>
    {sup}{strips}{ghostX!=null&&cart(ghostX,true)}{cart(cartX)}
    {(labels||[]).map((l,i)=><div key={i} style={{position:'absolute',left:l.x*W,top:yAt(l.x)*H+(l.dy||-120),transform:'translateX(-50%)',zIndex:3,direction:'rtl'}}>{l.el}</div>)}
  </div>;
}
function CoasterPlay({go}){
  return <main style={{...bsScreen,alignItems:'center',gap:14}}>
    {tag}
    <h1 style={{font:'var(--type-headline)',margin:0}}>أنت في أعمق نزلة… وش بتسوي؟</h1>
    <Track labels={[{x:.45,dy:-150,el:<div style={{'--r':'-8deg',animation:'bs-float .5s ease-in-out infinite alternate'}}><Chip color="red" big lift>بيطيييح!</Chip></div>},{x:.68,dy:-130,el:<div style={{'--r':'6deg',animation:'bs-float .6s ease-in-out infinite alternate'}}><Chip color="cream" big lift>ااااه 😱</Chip></div>}]}/>
    <span style={{font:'var(--type-caption)',color:'var(--ink-muted)',marginTop:-8}}>مسار السوق</span>
    <div style={{display:'flex',gap:28,alignItems:'center'}}>
      <button type="button" onClick={()=>go('coaster-lose')} style={{position:'relative',isolation:'isolate',border:0,background:'none',minHeight:88,padding:'0 64px',font:'900 36px/1 var(--f-display)',color:'var(--cream)',cursor:'pointer',animation:'bs-shake .55s ease-in-out infinite'}}>
        <span aria-hidden="true" style={{position:'absolute',inset:0,zIndex:-1,background:'var(--red)',backgroundImage:'var(--grain)',clipPath:'var(--cut-3)',filter:'var(--lift)'}}></span>نزّلني!</button>
      <Button variant="ghost" onClick={()=>go('coaster-win')}>أصبر وأكمل</Button>
    </div>
  </main>;
}
function MovingTrack(){const on=useLater(400);const x=useTween(on?TOPX:DIP,1600);return <Track W={820} H={280} cartX={x}/>;}
function CoasterWin({go,onWin}){return <Result id="coaster" win tag={tag} go={go} onWin={onWin} headline="الصبر هو نص اللعبة" lesson="لا تبيع بهلع وقت الهبوط." scene={<MovingTrack/>}/>;}
function CoasterLose({go,onWin}){return <Result id="coaster" tag={tag} go={go} onWin={onWin} lesson="أغلب الناس تخسر لأنها تنزل في أسوأ لحظة."
  scene={<Track W={820} H={280} ghostX={TOPX} labels={[{x:DIP,dy:-110,el:<Chip color="red" lift>نزلت هنا</Chip>},{x:TOPX,dy:-100,el:<Chip color="green" lift>السوق كمّل</Chip>}]}/>}/>;}
Object.assign(window,{CoasterPlay,CoasterWin,CoasterLose});
})();
