/** A stock as a coloured paper tile with its allocated amount and +/− steppers. Fades to 45% when empty.
 * @startingPoint section="Finance" subtitle="Stock allocation tiles" viewport="700x280" */
export interface StockCardProps{
  name?:string;
  /** small sector line under the name, e.g. طاقة */
  sector?:string;
  /** SAR allocated */
  amount?:number;
  color?:'blue'|'green'|'orange'|'red'|'cream';
  cut?:1|2|3|4;
  tilt?:number;
  onInc?:()=>void;
  onDec?:()=>void;
  incDisabled?:boolean;
  decDisabled?:boolean;
  /** fade to 45% when amount is 0 (default true) */
  dimEmpty?:boolean;
  style?:import('react').CSSProperties;
  /** replaces the +/− steppers (e.g. a change label) */
  children?:import('react').ReactNode;
}
export declare function StockCard(props:StockCardProps):JSX.Element;
