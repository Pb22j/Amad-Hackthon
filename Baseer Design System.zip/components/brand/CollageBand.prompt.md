Decorative collage strip for the welcome/hero screen only. Parent needs position:relative and enough bottom padding.
```jsx
<main style={{position:'relative',paddingBottom:'clamp(190px,30vh,320px)'}}>…<CollageBand/></main>
```
