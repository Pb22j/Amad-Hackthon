import React from 'react';

export function StepIndicator({count=4,current=1,label='خطوات البداية'}){
  const items=[];
  for(let i=0;i<count;i++){
    const bg=i<current-1?'var(--blue)':i===current-1?'var(--ink)':'var(--line)';
    items.push(React.createElement('li',{key:i,style:{width:28,height:6,background:bg}}));
  }
  return React.createElement('ol',{'aria-label':label,style:{display:'flex',gap:8,alignItems:'center',listStyle:'none',margin:0,padding:0}},items);
}
