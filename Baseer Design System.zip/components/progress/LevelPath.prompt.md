Investor-level progression ladder (RTL, arrows point ← toward the next level).
```jsx
<LevelPath current={1} />
```
