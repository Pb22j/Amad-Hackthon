(()=>{
const {Piece,Button}=window.BaseerDesignSystem_f0524d;
const tag=<GameTag n={5} icon="🍦" name="آيسكريم الصيف"/>;
const DRIP='polygon(0 0,100% 0,100% 72%,86% 90%,50% 100%,14% 90%,0 72%)';
function IceCream({s=1,melt=false}){
  const W=170*s,H=270*s;
  const disc=(c,size,bottom,dx=0)=><span style={{position:'absolute',left:W/2-size/2+dx,bottom,width:size,height:size,background:c,backgroundImage:'var(--grain)',clipPath:'var(--circle)'}}></span>;
  return <div style={{position:'relative',width:W,height:H,flex:'none',filter:'var(--lift)'}}>
    <span style={{position:'absolute',left:W/2-50*s,bottom:0,width:100*s,height:150*s,background:'var(--orange)',backgroundImage:'var(--grain)',clipPath:'polygon(0 0,100% 0,52% 100%,48% 100%)'}}></span>
    {disc('var(--green)',118*s,118*s)}{disc('var(--red)',100*s,180*s,6*s)}
    {melt&&[[-38,120,'var(--green)'],[30,128,'var(--green)'],[-6,190,'var(--red)']].map(([dx,b,c],i)=><span key={i} style={{position:'absolute',left:W/2+dx*s-8*s,bottom:(b-44)*s,width:16*s,height:50*s,background:c,clipPath:DRIP,transformOrigin:'top',animation:'bs-melt '+(1.6+i*.4)+'s ease-in-out infinite alternate'}}></span>)}
  </div>;
}
function Sun(){
  return <div style={{position:'relative',width:280,height:280,flex:'none'}}>
    <div aria-hidden="true" style={{position:'absolute',inset:0,animation:'bs-spin 40s linear infinite'}}>
      {[...Array(12)].map((_,i)=><span key={i} style={{position:'absolute',left:'50%',top:'50%',width:26,height:44,marginLeft:-13,marginTop:-22,background:'var(--orange)',clipPath:'polygon(50% 0,100% 100%,0 100%)',transform:'rotate('+i*30+'deg) translateY(-122px)'}}></span>)}
    </div>
    <Piece color="orange" cut="circle" lift style={{position:'absolute',inset:40,...bsCol,gap:4}}>
      <span style={{font:'900 36px/1.2 var(--f-display)'}}>التضخم</span><span style={{font:'700 20px/1 var(--f-sans)',direction:'rtl'}}>الرياض 47°</span>
    </Piece>
  </div>;
}
function Timer(){
  const [t,setT]=React.useState(10);
  React.useEffect(()=>{const id=setInterval(()=>setT(x=>x>0?x-1:0),1000);return()=>clearInterval(id);},[]);
  return <Piece color="ink" cut="circle" lift style={{width:120,height:120,...bsCol,flex:'none'}} aria-live="polite">
    <span style={{font:'900 48px/1 var(--f-display)',fontVariantNumeric:'tabular-nums'}}>{t}</span><span style={{font:'var(--type-caption)'}}>ثواني</span></Piece>;
}
function Puddle(){
  return <div style={{position:'relative',width:300,height:150,flex:'none',filter:'var(--lift)'}}>
    <span style={{position:'absolute',left:0,right:0,bottom:0,height:60,background:'var(--green)',backgroundImage:'var(--grain)',clipPath:'polygon(4% 60%,14% 22%,32% 8%,52% 18%,70% 4%,90% 20%,99% 55%,88% 90%,60% 100%,30% 94%,8% 88%)'}}></span>
    <span style={{position:'absolute',left:70,right:90,bottom:18,height:36,background:'var(--red)',backgroundImage:'var(--grain)',clipPath:'polygon(6% 50%,20% 10%,50% 0,80% 12%,96% 46%,80% 90%,40% 100%,10% 86%)'}}></span>
    <span style={{position:'absolute',right:6,bottom:30,width:80,height:118,background:'var(--orange)',backgroundImage:'var(--grain)',clipPath:'polygon(0 0,100% 0,52% 100%,48% 100%)',transform:'rotate(-104deg)'}}></span>
  </div>;
}
function Freezer(){
  return <Piece color="blue" cut={1} lift style={{width:250,height:340,flex:'none',padding:18}}>
    <Piece color="cream" cut={2} style={{width:'100%',height:'100%',display:'grid',placeItems:'end center',paddingBottom:14}}><IceCream s={.9}/></Piece>
    <span style={{position:'absolute',top:'40%',left:6,width:8,height:70,background:'var(--ink)'}}></span>
    <span style={{position:'absolute',top:-16,right:-14,zIndex:2}}><Chip color="cream" lift tilt={6}>❄️ فريزر</Chip></span>
  </Piece>;
}
function IcePlay({go,put}){
  return <main style={{...bsScreen,alignItems:'center',gap:20}}>
    {tag}
    <h1 style={{font:'var(--type-headline)',margin:0}}>الصيف وصل… وين بتحط آيسكريمك؟</h1>
    <div style={{display:'flex',gap:56,alignItems:'center',justifyContent:'center'}}>
      <Sun/><IceCream melt/><Timer/>
    </div>
    <div style={{display:'flex',gap:28}}>
      <ChoiceCard i={0} icon="✋" label="خله بيدي" sub="فلوس مركونة" cut={1} tilt={-1} w={220} h={150} onClick={()=>{put({iceChoice:'hand'});go('ice-timemachine');}}/>
      <ChoiceCard i={1} icon="❄️" label="حطه بالفريزر" sub="استثمار" cut={3} tilt={1} w={220} h={150} onClick={()=>{put({iceChoice:'freezer'});go('ice-timemachine');}}/>
    </div>
  </main>;
}
function IceTime({go,S}){
  return <main style={{...bsCenter,gap:34}}>
    {tag}
    <div style={{animation:'bs-drop .7s cubic-bezier(.3,1.3,.5,1) both'}}><Piece color="cream" cut="torn" lift tilt={-2} style={{padding:'28px 64px 22px',font:'900 clamp(40px,5vw,60px)/1.3 var(--f-display)',whiteSpace:'nowrap'}}>بعد 5 سنين…</Piece></div>
    <div style={{display:'flex',gap:110,alignItems:'flex-end',justifyContent:'center',marginTop:28}}>
      <div style={{...bsCol,gap:16,animation:'bs-in .5s ease .6s both'}}><Puddle/><Chip big>✋ المركون</Chip></div>
      <div style={{...bsCol,gap:16,animation:'bs-in .5s ease .9s both'}}><Freezer/><Chip big color="blue">❄️ المستثمر</Chip></div>
    </div>
    <Button onClick={()=>go(S.iceChoice==='freezer'?'ice-win':'ice-lose')}>شوف النتيجة</Button>
  </main>;
}
function IceWin({go,onWin}){return <Result id="ice" win tag={tag} go={go} onWin={onWin} headline="فلوسك ما ذابت!" lesson="الفلوس المركونة تخسر قيمتها بسبب التضخم." scene={<Freezer/>}/>;}
function IceLose({go,onWin}){return <Result id="ice" tag={tag} go={go} onWin={onWin} lesson="فلوسك المركونة مو آمنة… هي قاعدة تذوب." scene={<Puddle/>}/>;}
Object.assign(window,{IcePlay,IceTime,IceWin,IceLose});
})();
