import React from 'react';

export function Button({variant='primary',disabled=false,type='button',cut=2,children,style,onClick,...rest}){
  const [h,setH]=React.useState(false);
  const base={position:'relative',isolation:'isolate',display:'inline-flex',alignItems:'center',justifyContent:'center',gap:8,minHeight:60,padding:'0 44px',border:0,background:'none',cursor:disabled?'not-allowed':'pointer',font:'var(--type-button)',color:'var(--cream)',opacity:disabled?.4:1,whiteSpace:'nowrap'};
  let layer=null;
  if(variant==='primary'){
    layer=React.createElement('span',{'aria-hidden':true,style:{position:'absolute',inset:0,zIndex:-1,backgroundColor:'var(--blue)',backgroundImage:'var(--grain)',clipPath:'var(--cut-'+cut+')',transition:'transform .15s',transform:h&&!disabled?'rotate(-1deg) scale(1.03)':'none'}});
  }else if(variant==='ghost'){
    base.color='var(--ink)';
    layer=React.createElement('span',{'aria-hidden':true,style:{position:'absolute',inset:0,zIndex:-1,boxShadow:'inset 0 0 0 2px var(--line-strong)',transition:'transform .15s',transform:h&&!disabled?'rotate(-1deg) scale(1.03)':'none'}});
  }else if(variant==='quiet'){
    Object.assign(base,{color:'var(--blue)',padding:'0 12px',minHeight:44,textDecoration:'underline',textUnderlineOffset:6,textDecorationThickness:2});
  }
  return React.createElement('button',{type,disabled,onClick,onMouseEnter:()=>setH(true),onMouseLeave:()=>setH(false),style:{...base,...style},...rest},layer,children);
}
