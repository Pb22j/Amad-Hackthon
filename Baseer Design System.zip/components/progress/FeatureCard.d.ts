import * as React from 'react';
/** Cream lifted paper card for a feature/challenge entry: cut-paper shape icon, title, muted line, one action.
 * @startingPoint section="Progress" subtitle="Feature cards" viewport="700x320" */
export interface FeatureCardProps{
  /** a flat cut-paper shape SVG (hexagon, trapezoid, flame) */
  icon?:React.ReactNode;
  title?:React.ReactNode;
  body?:React.ReactNode;
  /** action, usually a Button */
  children?:React.ReactNode;
  cut?:1|2|3|4;
  color?:'cream'|'orange'|'green'|'blue'|'red';
  /** centered layout for stat cards (streak) */
  centered?:boolean;
}
export declare function FeatureCard(props:FeatureCardProps):JSX.Element;
