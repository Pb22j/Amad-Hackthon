Primary call-to-action and secondary actions; one blue primary per screen, verb-first Saudi-dialect labels.
```jsx
<Button onClick={next}>ابدأ رحلتك</Button>
<Button variant="ghost">ليش؟</Button>
<Button variant="quiet">تخطّي</Button>
```
- 60px tall, 44px side padding, Thmanyah Sans 700 18px. Hover tilts the paper -1° and scales 1.03.
- disabled → 40% opacity.
