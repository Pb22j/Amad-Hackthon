(()=>{
const {Piece,Button}=window.BaseerDesignSystem_f0524d;
const Q=[{q:'معك 750 ريال. وش الأخطر؟',a:['كلها في سهم واحد','موزعة على صندوق'],ok:0},
{q:'سهم ارتفع 50% في أسبوع، وكل القروبات تتكلم عنه. وش تسوي؟',a:['أدخل بسرعة','أتحقق أول','أدخل بكل فلوسي'],ok:1},
{q:'السوق نزل 15%. وش تسوي؟',a:['أبيع كل شي','أراجع توزيعي وأصبر','أسحب وما أرجع'],ok:1}];
const CONF=['شوي','متأكد','متأكد مرة'];
function QuizQ({go,S,put,n}){
  const q=Q[n],ans=S.quiz[n]||{};
  const setA=p=>{const z=S.quiz.slice();z[n]={...ans,...p};put({quiz:z});};
  const ready=ans.a!=null&&ans.c!=null;
  const next=()=>{if(n<2)return go('quiz-'+(n+2));
    const score=S.quiz.reduce((s,x,i)=>s+(x.a===Q[i].ok?1:0),0),conf=S.quiz.filter(x=>x.c>=1).length;
    const lvl=score===3&&conf>=2?'pro':'beginner';go('quiz-'+lvl,{level:lvl});};
  return <main style={{...bsScreen,alignItems:'center',gap:26}}>
    <div style={{...bsCol,gap:4}}>
      <span style={{font:'700 22px/1.4 var(--f-display)'}}>قبل نبدأ… خلنا نعرف وين أنت</span>
      <span style={{font:'var(--type-label)',color:'var(--ink-muted)'}}>ما نخليك تختار مستواك. الكويز يحدده 😉</span>
    </div>
    <div aria-label={'السؤال '+(n+1)+' من 3'} style={{display:'flex',gap:8,alignItems:'center'}}>
      {[0,1,2].map(i=><Piece key={i} color={i<=n?'blue':'faint'} cut={i+2} style={{width:46,height:14}}></Piece>)}
      <span style={{font:'700 15px/1 var(--f-sans)',marginInlineStart:6,fontVariantNumeric:'tabular-nums'}}>{n+1}/3</span>
    </div>
    <h1 key={n} style={{font:'var(--type-headline)',margin:0,maxWidth:'22ch',textAlign:'center',textWrap:'balance',animation:'bs-in .45s ease both'}}>{q.q}</h1>
    <div style={{display:'flex',gap:24,flexWrap:'wrap',justifyContent:'center'}}>
      {q.a.map((a,i)=><ChoiceCard key={n+'-'+i} i={i} label={a} on={ans.a===i} onClick={()=>setA({a:i})} cut={[1,3,4][i]} tilt={[-1,1,-.5][i]} w={250} h={130}/>)}
    </div>
    <div style={{...bsCol,gap:12}}>
      <span style={{font:'var(--type-label)'}}>كم أنت متأكد؟</span>
      <div role="radiogroup" aria-label="كم أنت متأكد؟" style={{display:'flex',gap:12}}>
        {CONF.map((c,i)=>{const on=ans.c===i;return <Piece key={c} as="button" type="button" role="radio" aria-checked={on} onClick={()=>setA({c:i})} color={on?'orange':'faint'} cut={[2,3,4][i]} lift={on} tilt={on?-2:0} style={{border:0,background:'none',cursor:'pointer',padding:'10px 22px',minHeight:44,font:'700 16px/1.4 var(--f-sans)'}}>{c}</Piece>;})}
      </div>
    </div>
    <Button disabled={!ready} onClick={next}>{n<2?'التالي':'شوف مستواك'}</Button>
  </main>;
}
function QuizBeginner({go}){
  return <main style={{...bsCenter,gap:30}}>
    <Chip>مستواك: مبتدئ</Chip>
    <h1 style={{font:'var(--type-hero)',margin:0}}>رحلتك تبدأ حبة حبة 🌱</h1>
    <p style={{font:'var(--type-lead)',color:'var(--ink-muted)',margin:0}}>5 ألعاب تعلمك الأساسيات</p>
    <div style={{display:'flex',gap:20}}>
      {['💸','📱','⚽','🎢','🍦'].map((e,i)=><div key={e} style={{animation:'bs-deal .5s cubic-bezier(.2,.8,.2,1) both',animationDelay:(200+i*110)+'ms'}}>
        <Piece color="cream" cut={(i%4)+1} lift tilt={[-3,2,-1,3,-2][i]} style={{width:92,height:92,display:'grid',placeItems:'center',fontSize:40}}>{e}</Piece></div>)}
    </div>
    <Button onClick={()=>go('journey')}>ابدأ رحلتك</Button>
  </main>;
}
function QuizPro({go}){
  return <main style={{...bsCenter,gap:30}}>
    <Chip color="green">مستواك: متمكن</Chip>
    <h1 style={{font:'var(--type-hero)',margin:0}}>واضح إنك فاهم الأساسيات 💪</h1>
    <p style={{font:'var(--type-lead)',color:'var(--ink-muted)',margin:0}}>تقدر تدخل ساحة التذبذب مباشرة</p>
    <div style={{animation:'bs-pop .5s cubic-bezier(.3,1.4,.5,1) .3s both'}}><Piece color="orange" cut="circle" lift tilt={-6} style={{width:150,height:150,display:'grid',placeItems:'center',fontSize:72}}>⚡</Piece></div>
    <Button onClick={()=>go('arena-calm')}>ادخل الساحة</Button>
  </main>;
}
Object.assign(window,{QuizQ,QuizBeginner,QuizPro});
})();
