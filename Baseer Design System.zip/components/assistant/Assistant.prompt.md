Voice assistant trigger (72px orange disc). Floats bottom-left (fixed) or sits beside a CoachBubble.
```jsx
<Assistant state="listening" onClick={cycle} />
```
- States cycle idle → listening → speaking → idle on tap.
