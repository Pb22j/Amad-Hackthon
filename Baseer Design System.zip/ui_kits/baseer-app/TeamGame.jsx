(()=>{
const {Piece,Button}=window.BaseerDesignSystem_f0524d;
const POS=[[50,90],[15,70],[38,74],[62,74],[85,70],[20,46],[40,50],[60,50],[80,46],[38,20],[62,20]];
const COL=['ink','blue','green','orange','red','blue','orange','green','red','orange','blue'];
const tag=<GameTag n={3} icon="⚽" name="النجم ولا الفريق؟"/>;
function Pitch({mode,injured,w=520,h=350}){
  const k=w/520,line='2px solid rgba(242,239,227,.75)',fall='transform .9s cubic-bezier(.5,-0.4,.6,1.3)';
  return <Piece color="green" cut={2} lift style={{width:w,height:h,flex:'none'}}>
    <div style={{position:'absolute',inset:18*k,border:line}}></div>
    <div style={{position:'absolute',left:18*k,right:18*k,top:'50%',borderTop:line}}></div>
    <div style={{position:'absolute',left:'50%',top:'50%',width:90*k,height:90*k,marginLeft:-45*k,marginTop:-45*k,border:line,borderRadius:'50%'}}></div>
    <div style={{position:'absolute',left:'50%',top:18*k,width:150*k,height:50*k,marginLeft:-75*k,border:line,borderTop:0}}></div>
    <div style={{position:'absolute',left:'50%',bottom:18*k,width:150*k,height:50*k,marginLeft:-75*k,border:line,borderBottom:0}}></div>
    {mode==='star'&&<div style={{position:'absolute',left:'50%',top:'50%',transition:fall,transform:'translate(-50%,-50%)'+(injured?' translateY('+60*k+'px) rotate(100deg)':'')}}>
      <Piece color="orange" cut={3} lift style={{width:104*k,height:136*k,display:'grid',placeItems:'center',font:'900 '+Math.round(24*k)+'px/1 var(--f-display)'}}>⭐</Piece></div>}
    {mode==='team'&&POS.map((p,i)=><div key={i} style={{position:'absolute',left:p[0]+'%',top:p[1]+'%',transition:fall,transform:'translate(-50%,-50%)'+(injured&&i===9?' translateY('+28*k+'px) rotate(90deg)':'')}}>
      <Piece color={COL[i]} cut={(i%4)+1} lift style={{width:34*k,height:42*k}}></Piece></div>)}
    {injured&&<div style={{position:'absolute',left:mode==='star'?'62%':'30%',top:mode==='star'?'70%':'28%',animation:'bs-pop .4s cubic-bezier(.3,1.4,.5,1) .8s both'}}><Chip color="red" lift tilt={-4}>إصابة!</Chip></div>}
  </Piece>;
}
function TeamPick({go,S,put}){
  const b=S.budget;
  return <main style={{...bsScreen,alignItems:'center',gap:30}}>
    {tag}
    <h1 style={{font:'var(--type-headline)',margin:0,fontVariantNumeric:'tabular-nums'}}>عندك {bsFmt(b)} ريال. تبني فريقك؟</h1>
    <div style={{display:'flex',gap:48,flexWrap:'wrap',justifyContent:'center'}}>
      <ChoiceCard i={0} label="⭐ النجم" sub={'لاعب واحد ياخذ كل الـ'+bsFmt(b)} cut={1} tilt={-1} w={320} onClick={()=>{put({teamPick:'star'});go('team-injury');}}><Pitch mode="star" w={280} h={188}/></ChoiceCard>
      <ChoiceCard i={1} label="👥 الفريق" sub={'11 لاعب، كل واحد '+bsFmt(b/11)} cut={3} tilt={1} w={320} onClick={()=>{put({teamPick:'team'});go('team-injury');}}><Pitch mode="team" w={280} h={188}/></ChoiceCard>
    </div>
  </main>;
}
function TeamInjury({go,S}){
  const pick=S.teamPick||'star',down=useLater(900),b=S.budget;
  const pct=pick==='star'?(down?60:100):(down?95:100),val=useTween(b*pct/100,1100);
  return <main style={{...bsScreen,alignItems:'center',gap:22}}>
    {tag}
    <ol aria-label="الموسم" style={{display:'flex',gap:12,alignItems:'center',listStyle:'none',margin:0,padding:0}}>
      {[1,2,3].map(m=><React.Fragment key={m}>
        <Piece as="li" color={m<2?'green':m===2?'blue':'faint'} cut={m+1} lift={m===2} tilt={m===2?-2:0} style={{padding:'10px 22px',font:'700 16px/1.4 var(--f-sans)',color:m===2?'var(--cream)':m<2?'var(--ink)':'var(--ink-muted)'}}>المباراة {m}</Piece>
        {m<3&&<li aria-hidden="true" style={{font:'500 20px/1 var(--f-sans)',color:'var(--ink-muted)'}}>←</li>}</React.Fragment>)}
    </ol>
    <div style={{display:'flex',gap:56,alignItems:'center',justifyContent:'center'}}>
      <div style={{...bsCol,gap:6,minWidth:220}}>
        <span style={{font:'var(--type-label)',color:'var(--ink-muted)'}}>قيمة {pick==='star'?'النجم':'الفريق'}</span>
        <span style={{font:'900 72px/1.1 var(--f-display)',fontVariantNumeric:'tabular-nums',color:pct<90?'var(--red)':'var(--ink)'}}>{bsFmt(val)}</span>
        <span style={{font:'700 22px/1 var(--f-sans)',direction:'ltr',color:pct<90?'var(--red)':'var(--ink)'}}>{pct<100?'↓'+(100-pct)+'%':'—'}</span>
      </div>
      <Pitch mode={pick} injured={down} w={480} h={320}/>
    </div>
    <div style={{display:'flex',gap:40,alignItems:'flex-end',alignSelf:'stretch',justifyContent:'space-between'}}>
      <TalkingOrb big hype speaker="بصير · المعلّق" text="الدقيقة 20… يا ساتر! إصابة! 🚑"/>
      <Button onClick={()=>go('team-reveal')}>كمّل الموسم</Button>
    </div>
  </main>;
}
function TeamReveal({go,S}){
  const flip=useLater(1500),gather=useLater(500);
  return <main style={{...bsCenter,gap:34}}>
    {tag}
    <div style={{display:'flex',gap:80,alignItems:'center',justifyContent:'center'}}>
      <Flip w={240} h={180} flipped={flip} color="orange" backColor="red" cut={3} backCut={2} front={<span style={{font:'900 32px/1.2 var(--f-display)'}}>⭐ النجم</span>} back={<span style={{font:'900 36px/1.2 var(--f-display)'}}>سهم واحد</span>}/>
      <div style={{position:'relative',width:260,height:190}}>
        {POS.map((p,i)=><div key={i} style={{position:'absolute',left:gather?'50%':p[0]+'%',top:gather?'50%':p[1]+'%',transform:'translate(-50%,-50%)'+(gather?' scale(.3)':''),opacity:gather?0:1,transition:'all .7s cubic-bezier(.5,0,.3,1)',transitionDelay:(i*25)+'ms'}}>
          <Piece color={COL[i]} cut={(i%4)+1} lift style={{width:30,height:36}}></Piece></div>)}
        {gather&&<div style={{position:'absolute',inset:'5px 10px',animation:'bs-pop .4s cubic-bezier(.3,1.4,.5,1) .5s both'}}>
          <Flip w={240} h={180} flipped={flip} color="blue" backColor="green" cut={1} backCut={4} front={<span style={{font:'900 32px/1.2 var(--f-display)'}}>👥 الفريق</span>} back={<span style={{font:'900 36px/1.2 var(--f-display)'}}>صندوق</span>}/></div>}
      </div>
    </div>
    <h1 style={{font:'var(--type-headline)',margin:0,animation:'bs-in .5s ease both',animationDelay:'2.2s'}}>الفريق = الصندوق. ما تراهن على لاعب واحد.</h1>
    <Button onClick={()=>go(S.teamPick==='team'?'team-win':'team-lose')}>شوف النتيجة</Button>
  </main>;
}
function TeamWin({go,onWin}){return <Result id="team" win tag={tag} go={go} onWin={onWin} headline="يا سلااام! النجم طاح بس الفريق كمّل!" lesson="الصندوق المتنوع أقل مخاطرة من السهم الواحد." scene={<Pitch mode="team" injured w={420} h={280}/>}/>;}
function TeamLose({go,onWin}){return <Result id="team" tag={tag} go={go} onWin={onWin} lesson="راهنت على لاعب واحد وطاح، وطاحت معه فلوسك." scene={<Pitch mode="star" injured w={420} h={280}/>}/>;}
Object.assign(window,{TeamPick,TeamInjury,TeamReveal,TeamWin,TeamLose});
})();
