import * as React from 'react';
/** What the assistant says: orange paper speech scrap with the speaker name on top. */
export interface CoachBubbleProps{
  /** default بصير */
  speaker?:string;
  color?:'orange'|'cream'|'blue'|'green'|'red';
  cut?:1|2|3|4;
  children?:React.ReactNode;
}
export declare function CoachBubble(props:CoachBubbleProps):JSX.Element;
export interface AssistantTipProps{children?:React.ReactNode}
/** Small flat faint-paper caption beside the floating Assistant. */
export declare function AssistantTip(props:AssistantTipProps):JSX.Element;
