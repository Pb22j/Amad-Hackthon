(()=>{
const {Piece,Button}=window.BaseerDesignSystem_f0524d;
const JAR='polygon(30% 0,70% 0,70% 9%,80% 13%,91% 22%,96% 36%,97% 86%,92% 96%,80% 100%,20% 100%,8% 96%,3% 86%,4% 36%,9% 22%,20% 13%,30% 9%)';
const JARS=[{k:'rent',n:'إيجار',c:'blue'},{k:'loan',n:'أقساط',c:'ink'},{k:'emg',n:'طوارئ',c:'green'},{k:'inv',n:'استثمار',c:'orange'}];
const FILL={blue:'var(--blue)',ink:'var(--ink)',green:'var(--green)',orange:'var(--orange)'};
const SAL=8000,REPAIR=1200,CAP=3000;
const tag=<GameTag n={1} icon="💸" name="يوم 27"/>;
function Jar({n,c,amount,w=150,h=196,onClick,chip}){
  const v=useTween(amount,800),fill=Math.min(1,v/CAP),txt=(c==='blue'||c==='ink')&&fill>.5?'var(--cream)':'var(--ink)';
  const body=<><div style={{position:'relative',width:w,height:h,filter:'var(--lift)'}}>
      <span style={{position:'absolute',inset:0,background:'var(--cream)',backgroundImage:'var(--grain)',clipPath:JAR}}></span>
      <span style={{position:'absolute',inset:0,clipPath:JAR}}><span style={{position:'absolute',insetInline:0,bottom:0,height:(fill*100)+'%',background:FILL[c],backgroundImage:'var(--grain)'}}></span></span>
      <span style={{position:'absolute',top:-8,left:'25%',right:'25%',height:16,background:'var(--ink)',clipPath:'var(--cut-2)'}}></span>
      <span style={{position:'absolute',inset:0,display:'grid',placeItems:'center',paddingTop:'30%',font:'900 '+Math.round(w/6)+'px/1 var(--f-display)',fontVariantNumeric:'tabular-nums',color:txt}}>{bsFmt(v)}</span>
      {chip&&<span style={{position:'absolute',top:-30,left:'50%',transform:'translateX(-50%)',zIndex:2}}>{chip}</span>}
    </div><span style={{font:'700 17px/1.4 var(--f-sans)'}}>{n}</span></>;
  const st={display:'flex',flexDirection:'column',alignItems:'center',gap:10,background:'none',border:0,padding:0};
  return onClick?<button type="button" onClick={onClick} aria-label={'حط 250 في '+n} style={{...st,cursor:'pointer'}}>{body}</button>:<div style={st}>{body}</div>;
}
function LiveJar({from,to,...p}){const on=useLater(700);return <Jar amount={on?to:from} {...p}/>;}
const NOTES=[8,19,31,44,57,69,81,92,38,63];
const TEMPT=[{t:'تخفيضات!',x:4,y:44,r:-8},{t:'توصيل مجاني',x:84,y:40,r:7},{t:'جوال جديد بالتقسيط',x:78,y:80,r:-5},{t:'عرض لفترة محدودة',x:2,y:80,r:5}];
function Day27Play({go,S,put}){
  const j=S.d27,left=SAL-j.rent-j.loan-j.emg-j.inv;
  const add=k=>{if(left<=0)return;put({d27:{...j,[k]:j[k]+Math.min(250,left)}});};
  return <main style={{...bsScreen,alignItems:'center',gap:18,position:'relative'}}>
    {tag}
    <div aria-hidden="true" style={{position:'absolute',inset:'0 0 45% 0',overflow:'hidden',pointerEvents:'none'}}>
      {NOTES.map((x,i)=><div key={i} style={{position:'absolute',left:x+'%',top:0,animation:'bs-fall '+(2.6+(i%3)*.5)+'s linear infinite',animationDelay:(-i*.55)+'s'}}>
        <Piece color="green" cut={(i%4)+1} lift tilt={i%2?12:-10} style={{width:66,height:34,display:'grid',placeItems:'center',font:'700 14px/1 var(--f-sans)'}}>100</Piece></div>)}
    </div>
    <h1 style={{font:'900 clamp(44px,5.4vw,68px)/1.3 var(--f-display)',margin:'20px 0 0',position:'relative'}}>نزل الراتب! 💸</h1>
    <p style={{font:'var(--type-lead)',color:'var(--ink-muted)',margin:0,position:'relative'}}>وزّع 8,000 ريال على جرارك. كل ضغطة على الجرة = 250.</p>
    <Piece color="ink" cut={2} style={{padding:'8px 20px',font:'700 18px/1.4 var(--f-sans)',fontVariantNumeric:'tabular-nums'}} aria-live="polite">باقي بيدك {bsFmt(left)} ريال</Piece>
    <div style={{display:'flex',gap:44,alignItems:'flex-end',justifyContent:'center',marginTop:18}}>
      {JARS.map(x=><Jar key={x.k} n={x.n} c={x.c} amount={j[x.k]} onClick={()=>add(x.k)}/>)}
    </div>
    {TEMPT.map((t,i)=><div key={i} aria-hidden="true" style={{position:'absolute',left:t.x+'%',top:t.y+'%','--r':t.r+'deg',animation:'bs-float '+(1.4+i*.3)+'s ease-in-out infinite alternate',pointerEvents:'none'}}>
      <Piece color="red" cut={(i%4)+1} lift style={{padding:'10px 18px',font:'700 16px/1.4 var(--f-sans)',whiteSpace:'nowrap'}}>{t.t}</Piece></div>)}
    <Button onClick={()=>go('d27-surprise')}>كمّل الشهر</Button>
  </main>;
}
function Day27Surprise({go,S}){
  const j=S.d27,ok=j.emg>=REPAIR;
  return <main style={{...bsScreen,alignItems:'center',justifyContent:'center',gap:30}}>
    {tag}
    <div style={{animation:'bs-drop .7s cubic-bezier(.3,1.3,.5,1) both'}}>
      <Piece color="cream" cut="torn" lift tilt={-2} style={{padding:'34px 64px 28px',textAlign:'center'}}>
        <span style={{display:'block',font:'var(--type-label)',color:'var(--ink-muted)'}}>نص الشهر…</span>
        <span style={{display:'block',font:'900 clamp(40px,5vw,64px)/1.3 var(--f-display)'}}>تعطلت السيارة 🚗💥</span>
      </Piece></div>
    <div style={{animation:'bs-pop .45s cubic-bezier(.3,1.4,.5,1) .8s both'}}><Chip color="red" big tilt={2} lift>التصليح: 1,200 ريال</Chip></div>
    <div style={{display:'flex',gap:40,alignItems:'flex-end'}}>
      <Jar n="طوارئ" c="green" amount={j.emg} w={120} h={156}/><Jar n="استثمار" c="orange" amount={j.inv} w={120} h={156}/>
    </div>
    <Button onClick={()=>go(ok?'d27-win':'d27-lose')}>من وين بتدفع؟</Button>
  </main>;
}
function Day27Win({go,S,onWin}){
  const j=S.d27,e=j.emg>=REPAIR?j.emg:1500,inv=j.inv||750;
  return <Result id="d27" win tag={tag} go={go} onWin={onWin} headline="كفو! الطوارئ حمت استثمارك" lesson="خلّ مبلغ للطوارئ قبل ما تستثمر."
    scene={<div style={{display:'flex',gap:40,alignItems:'flex-end',paddingTop:30}}>
      <LiveJar n="طوارئ" c="green" from={e} to={e-REPAIR} chip={<Chip color="red" lift>−1,200 تصليح</Chip>}/>
      <LiveJar n="استثمار" c="orange" from={inv} to={inv} chip={<Chip color="green" lift>سليم</Chip>}/></div>}/>;
}
function Day27Lose({go,S,onWin}){
  const inv=S.d27.inv>0?S.d27.inv:1500;
  return <Result id="d27" tag={tag} go={go} onWin={onWin} lesson="شفت؟ الطوارئ مو رفاهية. هي اللي تحمي استثمارك."
    scene={<div style={{display:'flex',gap:40,alignItems:'flex-end',paddingTop:30}}>
      <Jar n="طوارئ" c="green" amount={0} chip={<Chip>فاضية</Chip>}/>
      <LiveJar n="استثمار" c="orange" from={inv} to={Math.max(0,inv-REPAIR)} chip={<Chip color="red" lift>−1,200 تصليح</Chip>}/></div>}/>;
}
Object.assign(window,{Day27Play,Day27Surprise,Day27Win,Day27Lose});
})();
