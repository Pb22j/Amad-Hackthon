import * as React from 'react';
export type PieceColor='cream'|'blue'|'orange'|'green'|'red'|'ink'|'faint';
export type PieceCut=1|2|3|4|'circle'|'torn';
/** A cut-paper surface: grained fill clipped to a hand-cut polygon. The base unit of every Baseer surface.
 * @startingPoint section="Core" subtitle="Cut-paper surface" viewport="700x260" */
export interface PieceProps{
  /** element tag, default div */
  as?:keyof JSX.IntrinsicElements;
  /** paper colour; blue/red/ink switch text to cream */
  color?:PieceColor;
  /** which irregular cut polygon; 'circle' for discs */
  cut?:PieceCut;
  /** drop-shadow so the paper sits above the page */
  lift?:boolean;
  /** rotation in degrees, typically -2..2 */
  tilt?:number;
  style?:React.CSSProperties;
  children?:React.ReactNode;
  [k:string]:any;
}
export declare function Piece(props:PieceProps):JSX.Element;
export declare function cutVar(cut?:PieceCut):string;
