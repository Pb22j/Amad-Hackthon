import React from 'react';
import { Piece } from '../core/Piece.jsx';

export function CoachBubble({speaker='بصير',children,color='orange',cut=4}){
  return React.createElement(Piece,{color,cut,lift:true,'aria-live':'polite',style:{padding:'24px 32px',font:'var(--type-bubble)'}},
    React.createElement('b',{style:{display:'block',font:'700 15px/1.5 var(--f-sans)',marginBottom:4}},speaker),children);
}

export function AssistantTip({children}){
  return React.createElement(Piece,{as:'span',color:'faint',cut:2,style:{padding:'12px 20px',font:'700 15px/1.4 var(--f-sans)'}},children);
}
