import React from 'react';
import { Piece } from '../core/Piece.jsx';

export function ObligationField({label,value,onChange,cut=2,tilt=0,color='cream',placeholder='0'}){
  return React.createElement(Piece,{as:'label',color,cut,lift:true,tilt,style:{display:'flex',flexDirection:'column',gap:4,padding:'22px 30px',minWidth:190,cursor:'text'}},
    React.createElement('span',{style:{font:'var(--type-label)'}},label),
    React.createElement('input',{inputMode:'numeric',autoComplete:'off',value,placeholder,onChange:e=>onChange&&onChange(e.target.value),style:{all:'unset',font:'700 30px/1.3 var(--f-display)',width:'6ch',fontVariantNumeric:'tabular-nums'}}));
}
