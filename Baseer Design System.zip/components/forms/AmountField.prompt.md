The big "كم راتبك؟" input: Display 900 up to 92px, 3px ink underline, unit in muted sans.
```jsx
<AmountField value={salary} onChange={setSalary} ariaLabel="الراتب" />
```
- Format with en-US thousands separators (8,000) on input.
