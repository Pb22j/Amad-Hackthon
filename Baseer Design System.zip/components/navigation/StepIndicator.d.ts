/** Onboarding progress: flat bars, blue = done, ink = current, line = upcoming. */
export interface StepIndicatorProps{
  count?:number;
  /** 1-based current step */
  current?:number;
  label?:string;
}
export declare function StepIndicator(props:StepIndicatorProps):JSX.Element;
