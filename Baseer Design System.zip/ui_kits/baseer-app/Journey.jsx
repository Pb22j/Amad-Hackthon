(()=>{
const {StarRating,Piece}=window.BaseerDesignSystem_f0524d;
const G5=['d27','family','team','coaster','ice'];
const ST=[{id:'d27',ic:'💸',n:'يوم 27'},{id:'family',ic:'📱',n:'قروب العيلة'},{id:'team',ic:'⚽',n:'النجم ولا الفريق؟'},{id:'coaster',ic:'🎢',n:'القطار الأفعواني'},{id:'ice',ic:'🍦',n:'آيسكريم الصيف'},{id:'arena',ic:'⚡',n:'ساحة التذبذب'},{id:'grad',ic:'🎓',n:'التخرج'}];
const TOP=[30,160,30,160,30,160,30];
const X=i=>i*(100/7)+100/14;
const DEST={d27:'d27-play',family:'family-play',team:'team-pick',coaster:'coaster-play',ice:'ice-play',arena:'arena-calm',grad:'grad'};
function JourneyScreen({go,S}){
  const won=G5.filter(x=>S.won.includes(x)),cur=G5.find(x=>!won.includes(x));
  const open=won.length>=5||S.level==='pro';
  const status=id=>G5.includes(id)?(won.includes(id)?'passed':id===cur?'current':'locked'):(open?'current':'locked');
  const tokenAt=ST.findIndex(s=>s.id===(cur||'arena'));
  const pts=ST.map((_,i)=>(100-X(i))+','+(TOP[i]+56)).join(' ');
  return <main style={{...bsScreen,gap:30,alignItems:'center'}}>
    <section style={{...bsCol,gap:10}}>
      <StarRating value={won.length} size={64} animate delay={300} step={180}/>
      <span style={{font:'700 22px/1.4 var(--f-display)',fontVariantNumeric:'tabular-nums',whiteSpace:'nowrap'}}>نجومك: {won.length} من 5</span>
      <span style={{font:'var(--type-label)',color:'var(--ink-muted)'}}>النجمة تقيس جودة القرار، مو الربح.</span>
    </section>
    <section aria-label="خريطة الرحلة" style={{position:'relative',height:300,width:'100%',maxWidth:1180}}>
      <svg viewBox="0 0 100 300" preserveAspectRatio="none" aria-hidden="true" style={{position:'absolute',inset:0,width:'100%',height:'100%'}}>
        <polyline points={pts} fill="none" stroke="var(--line-strong)" strokeWidth="2" strokeDasharray="8 8" vectorEffect="non-scaling-stroke"/>
      </svg>
      {ST.map((st,i)=>{const s=status(st.id),click=s!=='locked',special=!G5.includes(st.id);
        const color=s==='passed'?'green':s==='current'?(special?'orange':'cream'):'#E5E2D7';
        const P={color,cut:(i%4)+1,lift:s!=='locked',tilt:[-1.5,1,-1,1.5,-1,1,-1.5][i],style:{width:142,minHeight:112,padding:'14px 10px',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:8,textAlign:'center',border:0,background:'none',cursor:click?'pointer':'default'}};
        const inner=<><span style={{fontSize:34,lineHeight:1,opacity:s==='locked'?.5:1}}>{st.ic}</span><span style={{font:(s==='locked'?'500':'700')+' 16px/1.35 var(--f-sans)',color:s==='locked'?'var(--ink-muted)':'var(--ink)'}}>{st.n}</span></>;
        return <div key={st.id} style={{position:'absolute',right:X(i)+'%',top:TOP[i],transform:'translateX(50%)',zIndex:1}}>
          <div style={{animation:s==='current'?'bs-pulse 1.8s ease-in-out infinite':'none'}}>
            {click?<Piece as="button" type="button" onClick={()=>go(DEST[st.id])} {...P}>{inner}</Piece>:<Piece {...P}>{inner}</Piece>}
          </div>
          {st.id==='arena'&&!open&&<Piece color="ink" cut={2} lift tilt={-3} style={{position:'absolute',bottom:-20,insetInline:-8,padding:'5px 8px',font:'700 12px/1.4 var(--f-sans)',textAlign:'center'}}>تنفتح عند 5 نجوم</Piece>}
          {s==='passed'&&<div style={{position:'absolute',top:-24,left:-16,animation:S.fly===st.id?'bs-fly 1.3s cubic-bezier(.3,.9,.4,1.15) .3s both':'none'}}><StarRating value={1} max={1} size={44} label="مجتازة"/></div>}
          {i===tokenAt&&<div aria-label="أنت هنا" style={{position:'absolute',top:-50,left:'50%',marginLeft:-20,animation:'bs-float 1s ease-in-out infinite alternate'}}><Piece color="orange" cut="circle" lift style={{width:40,height:40}}></Piece></div>}
        </div>;})}
    </section>
  </main>;
}
Object.assign(window,{JourneyScreen});
})();
