Small labelled number on a paper tile; lay 2–4 in a wrapping row with varied cut/tilt.
```jsx
<ObligationField label="إيجار" value="2,500" cut={2} tilt={1} />
```
