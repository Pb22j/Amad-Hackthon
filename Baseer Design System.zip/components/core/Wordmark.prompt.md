The brand mark — the word بصير in Thmanyah Serif Display 900. Use instead of any logo.
```jsx
<Wordmark onClick={()=>go('welcome')} />
```
