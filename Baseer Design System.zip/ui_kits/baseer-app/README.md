# Baseer web app — UI kit

Click-through recreation of `source/baseer.html` (the only product surface provided): a single-page, one-idea-per-screen RTL web app.

Every important moment is its own hash-addressable state (`index.html#team-injury`), listed in **`Screens.html`** (screen index for screenshots).

Flow: welcome → salary → margin → quiz (3 Qs → مبتدئ/متمكن) → journey map → 5 games (play → moment → win/lose) → ساحة التذبذب → التخرج.

- `Onboarding.jsx` welcome/salary/margin · `Quiz.jsx` level quiz · `Journey.jsx` 7-station map with 5 stars.
- `Games.jsx` shared: Result (1 star + lesson bubble from the orb + retry), ChoiceCard, Flip, Torn, TalkingOrb (commentator mode), EyeOrb (risk watcher), GameTag, Chip.
- `Day27.jsx`, `FamilyGame.jsx`, `TeamGame.jsx`, `Coaster.jsx`, `Ice.jsx` — the five games.
- `Arena.jsx` — volatility arena (calm/alert) + graduation (the only dark screen).
- `index.html` — router/shell: R table maps each state id to its screen, back target, footer and orb visibility.
