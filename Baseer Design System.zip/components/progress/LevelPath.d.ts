/** Level ladder: done = green, current = tilted lifted blue, upcoming = faint, joined by ← arrows. */
export interface LevelPathProps{
  levels?:string[];
  /** 0-based index of current level */
  current?:number;
}
export declare function LevelPath(props:LevelPathProps):JSX.Element;
