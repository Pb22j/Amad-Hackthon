/** The Saudi-dialect voice assistant orb: orange paper disc with a 4-bar waveform.
 * @startingPoint section="Assistant" subtitle="Voice orb states" viewport="700x200" */
export interface AssistantProps{
  /** idle = static bars; listening = spinning dashed ring; speaking = animated bars */
  state?:'idle'|'listening'|'speaking';
  onClick?:()=>void;
  label?:string;
}
export declare function Assistant(props:AssistantProps):JSX.Element;
