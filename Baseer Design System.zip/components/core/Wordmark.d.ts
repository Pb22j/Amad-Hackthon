import * as React from 'react';
/** The Baseer wordmark: the name set in Thmanyah Serif Display Black. No graphic logo exists. */
export interface WordmarkProps{
  /** makes it a button (usually: go home) */
  onClick?:()=>void;
  /** px, default 34 */
  size?:number;
  style?:React.CSSProperties;
}
export declare function Wordmark(props:WordmarkProps):JSX.Element;
