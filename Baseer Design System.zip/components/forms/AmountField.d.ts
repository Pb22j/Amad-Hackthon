/** Hero-size numeric input on a heavy ink underline — for the one big number a screen asks for (salary). */
export interface AmountFieldProps{
  value?:string;
  onChange?:(v:string)=>void;
  /** default ريال */
  unit?:string;
  ariaLabel?:string;
  id?:string;
  /** faint hint, e.g. «مثلاً 8,000» */
  placeholder?:string;
}
export declare function AmountField(props:AmountFieldProps):JSX.Element;
