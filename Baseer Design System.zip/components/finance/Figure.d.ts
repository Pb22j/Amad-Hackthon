/** The one big number on a screen, set in Display Black with a unit. */
export interface FigureProps{
  value?:string;
  /** default ريال */
  unit?:string;
  /** small muted label above (hero only) */
  label?:string;
  /** hero = up to 150px; points = 46px compact figure */
  variant?:'hero'|'points';
}
export declare function Figure(props:FigureProps):JSX.Element;
