A cut-paper surface (grain + irregular clip-path) — wrap any card, chip, bubble or tile in it.
```jsx
<Piece color="green" cut={3} lift tilt={-1} style={{padding:'22px 30px'}}>محتوى</Piece>
```
- color: cream (default, needs lift to read on page), blue, orange, green, red, faint (ink 6%, flat, for inactive).
- cut: 1–4 rectangles with slightly different hand-cut edges; vary them between neighbours. 'circle' for discs.
- lift: shadow; tilt: degrees (keep within ±2).
