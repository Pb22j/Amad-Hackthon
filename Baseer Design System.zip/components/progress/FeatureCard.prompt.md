Home-screen cards in a grid (repeat(auto-fit,minmax(240px,1fr)), gap 32).
```jsx
<FeatureCard icon={<img src="assets/shape-hexagon-blue.svg" width="44"/>} title="آلة الزمن" body="شوف فلوسك بعد 5 سنين"><Button>جرّب</Button></FeatureCard>
```
- centered for stats: big Display 900 64px number + label.
