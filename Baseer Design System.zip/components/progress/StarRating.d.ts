/** Cut-paper star rating: earned stars orange + lifted, remaining a faint ink shadow. Supports halves (fills from the start/right side in RTL).
 * @startingPoint section="Progress" subtitle="5-star paper rating" viewport="700x620" */
export interface StarRatingProps{
  /** 0..max, halves allowed (e.g. 3.5) */
  value?:number;
  max?:number;
  /** px per star, default 56 */
  size?:number;
  gap?:number;
  /** pop earned stars in one by one */
  animate?:boolean;
  /** ms before first star */
  delay?:number;
  /** ms between stars, default 260 */
  step?:number;
  label?:string;
}
export declare function StarRating(props:StarRatingProps):JSX.Element;
