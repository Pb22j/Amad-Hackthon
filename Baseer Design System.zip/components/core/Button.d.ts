import * as React from 'react';
/** Baseer action button. One primary per screen.
 * @startingPoint section="Core" subtitle="Cut-paper buttons" viewport="700x220" */
export interface ButtonProps{
  /** primary = blue cut-paper; ghost = 2px ink outline; quiet = underlined blue text link */
  variant?:'primary'|'ghost'|'quiet';
  disabled?:boolean;
  type?:'button'|'submit'|'reset';
  /** cut polygon for the primary paper (1–4), default 2 */
  cut?:1|2|3|4;
  onClick?:(e:React.MouseEvent<HTMLButtonElement>)=>void;
  style?:React.CSSProperties;
  children?:React.ReactNode;
}
export declare function Button(props:ButtonProps):JSX.Element;
