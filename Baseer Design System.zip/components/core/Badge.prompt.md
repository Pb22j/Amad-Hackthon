Achievement sticker awarded after a challenge — a tilted, lifted paper scrap.
```jsx
<Badge>صمدت في الهبوط</Badge>
```
- Default orange, cut 3, -2° tilt. Keep copy to 2–4 words.
