import React from 'react';
import { Wordmark } from '../core/Wordmark.jsx';

export function TopBar({onHome,children,onFullscreen,showFullscreen=true}){
  return React.createElement('header',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:16,padding:'28px var(--header-pad-x)'}},
    React.createElement(Wordmark,{onClick:onHome}),
    React.createElement('div',{style:{display:'flex',alignItems:'center',gap:20}},children,
      showFullscreen?React.createElement('button',{type:'button','aria-label':'ملء الشاشة',onClick:onFullscreen,style:{background:'none',border:'2px solid var(--line-strong)',width:44,height:44,display:'grid',placeItems:'center',cursor:'pointer'}},
        React.createElement('svg',{width:20,height:20,viewBox:'0 0 20 20',fill:'none',stroke:'currentColor',strokeWidth:2,'aria-hidden':true},React.createElement('path',{d:'M2 7V2h5M13 2h5v5M18 13v5h-5M7 18H2v-5'}))):null));
}
