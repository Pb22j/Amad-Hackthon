/** Scenario outcome tile: a label and a big signed percentage, for side-by-side comparisons. */
export interface OutcomeCardProps{
  label?:string;
  /** e.g. "↓15%" */
  value?:string;
  /** red = loss, green = held up */
  color?:'green'|'red'|'blue'|'orange';
  cut?:1|2|3|4;
  tilt?:number;
  /** lifts and scales the winning card */
  emphasis?:boolean;
}
export declare function OutcomeCard(props:OutcomeCardProps):JSX.Element;
