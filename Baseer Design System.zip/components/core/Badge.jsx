import React from 'react';
import { Piece } from './Piece.jsx';

export function Badge({color='orange',cut=3,tilt=-2,children,style}){
  return React.createElement(Piece,{as:'span',color,cut,lift:true,tilt,style:{display:'inline-flex',padding:'16px 34px',font:'var(--type-button)',...style}},children);
}
