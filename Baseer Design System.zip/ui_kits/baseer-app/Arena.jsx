(()=>{
const {Piece,CoachBubble,Badge,Button}=window.BaseerDesignSystem_f0524d;
const STK=[{n:'صقر للتقنية',ch:4.2,c:'blue'},{n:'نخلة للتطوير',ch:-2.1,c:'green'},{n:'موجة للطاقة',ch:1.3,c:'orange'},{n:'قمرة للاتصالات',ch:-0.8,c:'cream'},{n:'رمال للتعدين',ch:3.5,c:'red'},{n:'واحة للأغذية',ch:-1.6,c:'ink'}];
function Arena({S,alert}){
  const alloc=alert?[70,6,6,6,6,6]:[20,15,20,15,15,15];
  return <main style={{...bsScreen,gap:22,position:'relative',alignItems:'center',paddingBottom:alert?40:100}}>
    <div style={{display:'flex',gap:16,alignItems:'center',alignSelf:'stretch',justifyContent:'space-between',flexWrap:'wrap'}}>
      <div style={{display:'flex',gap:12}}><Chip color="ink">اليوم 12 من 30</Chip><Chip color="cream" lift>محفظتك: {bsFmt(S.budget)} ريال</Chip></div>
      <Chip color={alert?'red':'faint'} lift={alert}>إنذارات المراقب: {alert?1:0}</Chip>
    </div>
    <h1 style={{font:'var(--type-headline)',margin:0,textAlign:'center'}}>ساحة التذبذب. هنا السوق يتحرك بسرعة ⚡</h1>
    <div style={{display:'flex',flexWrap:'wrap',gap:28,justifyContent:'center',alignItems:'center',maxWidth:1000}}>
      {STK.map((s,i)=>{const big=alert&&i===0,up=s.ch>0;
        return <div key={s.n} style={{'--r':[-1.5,1,-.5,1.5,-1,.5][i]+'deg',animation:'bs-jitter '+(.7+i*.11)+'s ease-in-out infinite',animationDelay:(-i*.17)+'s'}}>
          <Piece color={s.c} cut={(i%4)+1} lift style={{width:big?300:alert?200:240,height:big?200:alert?140:160,...bsCol,gap:8,transition:'width .5s, height .5s'}}>
            <span style={{font:'700 '+(big?22:18)+'px/1.3 var(--f-sans)'}}>{s.n}</span>
            <Piece as="span" color="cream" cut={2} style={{padding:'3px 12px',font:'700 16px/1.4 var(--f-sans)',direction:'ltr',color:up?'var(--green)':'var(--red)'}}>{(up?'↑':'↓')+Math.abs(s.ch)+'%'}</Piece>
            <span style={{font:'900 '+(big?36:26)+'px/1.1 var(--f-display)',fontVariantNumeric:'tabular-nums',whiteSpace:'nowrap'}}>حصتك {alloc[i]}%</span>
          </Piece></div>;})}
    </div>
    <div style={{position:alert?'relative':'absolute',left:alert?undefined:0,bottom:alert?undefined:20,alignSelf:'flex-start',display:'flex',gap:18,alignItems:'flex-end',direction:'ltr',marginTop:alert?4:0}}>
      <EyeOrb alert={alert}/>
      {alert&&<div dir="rtl" style={{maxWidth:380,marginBottom:40,transformOrigin:'left bottom',animation:'bs-pop .45s cubic-bezier(.3,1.4,.5,1) .4s both',textAlign:'right'}}><CoachBubble color="red" speaker="مراقب المخاطر 👁️">انتبه: 70% من فلوسك في سهم واحد.</CoachBubble></div>}
    </div>
  </main>;
}
const ArenaCalm=p=><Arena {...p}/>;const ArenaAlert=p=><Arena {...p} alert/>;
const BURST=[['blue',6,12,150,110,-12,1],['orange',88,10,120,120,10,'circle'],['green',12,72,170,90,8,3],['red',86,66,140,150,-9,2],['orange',28,4,80,60,18,4],['green',70,3,100,70,-14,1],['red',3,42,70,120,6,2],['blue',96,40,60,140,-5,3],['cream',20,94,120,50,-6,4],['blue',78,94,150,60,7,2],['green',97,90,70,70,22,1],['red',44,-1,90,44,-4,3],['orange',58,99,70,70,0,'circle']];
function Graduation(){
  return <main style={{flex:1,position:'relative',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:26,padding:'0 var(--gutter-x) 70px',textAlign:'center',color:'var(--cream)'}}>
    {BURST.map(([c,x,y,w,h,r,cut],i)=><div key={i} aria-hidden="true" style={{position:'absolute',left:x+'%',top:y+'%','--bx':((50-x)*11)+'px','--by':((50-y)*7)+'px',animation:'bs-burst .9s cubic-bezier(.2,.9,.3,1.2) both',animationDelay:(i*40)+'ms'}}>
      <Piece color={c} cut={cut} tilt={r} style={{width:w,height:h,transform:'translate(-50%,-50%)'}}></Piece></div>)}
    <h1 style={{position:'relative',font:'900 clamp(44px,5.4vw,78px)/1.3 var(--f-display)',margin:0,maxWidth:'17ch',textWrap:'balance',animation:'bs-in .6s ease .5s both'}}>كفو! أثبت جدارتك وصرت جاهز للسوق الصدقي</h1>
    <div style={{animation:'bs-pop .5s cubic-bezier(.3,1.4,.5,1) .9s both'}}><Badge style={{font:'900 34px/1.3 var(--f-display)',padding:'18px 48px'}}>مستثمر واعي</Badge></div>
    <div style={{display:'flex',gap:16,animation:'bs-in .5s ease 1.2s both'}}><Chip color="blue" big>⭐ 5 نجوم</Chip><Chip color="green" big>🎮 5 ألعاب</Chip><Chip color="red" big>👁️ إنذارين بس</Chip></div>
    <div style={{animation:'bs-deal .6s cubic-bezier(.2,.8,.2,1) 1.5s both',marginTop:8}}>
      <Piece color="cream" cut={3} lift style={{padding:'28px 40px',display:'flex',gap:40,alignItems:'center',textAlign:'right'}}>
        <div style={{display:'flex',flexDirection:'column',gap:6}}>
          <h2 style={{font:'var(--type-title)',margin:0}}>جاهز تبدأ بفلوس حقيقية؟</h2>
          <p style={{font:'var(--type-body)',margin:0,color:'var(--ink-muted)'}}>افتح حسابك عند شريك وساطة مرخّص من هيئة السوق المالية</p>
        </div>
        <Button>افتح حسابي</Button>
      </Piece></div>
  </main>;
}
Object.assign(window,{ArenaCalm,ArenaAlert,Graduation});
})();
