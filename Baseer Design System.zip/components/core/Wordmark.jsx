import React from 'react';

export function Wordmark({onClick,size=34,style}){
  return React.createElement(onClick?'button':'span',{type:onClick?'button':undefined,onClick,'aria-label':'بصير',style:{font:'900 '+size+'px/1 var(--f-display)',background:'none',border:0,padding:0,cursor:onClick?'pointer':'default',color:'var(--ink)',...style}},'بصير');
}
