import React from 'react';

export function AmountField({value,onChange,unit='ريال',ariaLabel,id,placeholder}){
  return React.createElement('label',{style:{display:'flex',alignItems:'baseline',gap:16,borderBottom:'3px solid var(--ink)',paddingBottom:6}},
    React.createElement('input',{id,inputMode:'numeric',autoComplete:'off','aria-label':ariaLabel,value,placeholder,onChange:e=>onChange&&onChange(e.target.value),style:{all:'unset',flex:1,minWidth:0,font:'900 clamp(56px,7vw,92px)/1.15 var(--f-display)',textAlign:'right',fontVariantNumeric:'tabular-nums'}}),
    React.createElement('span',{style:{font:'500 22px/1 var(--f-sans)',color:'var(--ink-muted)'}},unit));
}
