Coach line from the assistant, paired with an Assistant orb (speaking) and 1–2 Buttons under it.
```jsx
<div style={{display:'flex',gap:24,alignItems:'center'}}>
  <Assistant state="speaking"/>
  <CoachBubble>وقف وقف! حاطط كل الـ750 بسهم واحد؟</CoachBubble>
</div>
```
- AssistantTip: tiny faint scrap next to the floating orb ("أسمعك… اسأل اللي ببالك").
