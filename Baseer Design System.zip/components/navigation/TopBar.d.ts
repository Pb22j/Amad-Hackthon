import * as React from 'react';
/** App header: wordmark on the start side, steps/nav + fullscreen square on the end side. */
export interface TopBarProps{
  onHome?:()=>void;
  /** StepIndicator or NavTabs */
  children?:React.ReactNode;
  onFullscreen?:()=>void;
  showFullscreen?:boolean;
}
export declare function TopBar(props:TopBarProps):JSX.Element;
