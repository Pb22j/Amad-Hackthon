Main app nav (after onboarding). Active tab = cream text on a blue cut-2 scrap.
```jsx
<NavTabs items={[{id:'journey',label:'رحلتك'},{id:'portfolio',label:'محفظتي'},{id:'result',label:'التحديات'}]} current="journey" onChange={go} />
```
