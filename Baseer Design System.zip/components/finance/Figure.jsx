import React from 'react';

export function Figure({value,unit='ريال',label,variant='hero'}){
  if(variant==='points'){
    return React.createElement('div',{style:{font:'900 46px/1.2 var(--f-display)'}},value,' ',React.createElement('span',{style:{fontSize:28,fontWeight:700}},unit));
  }
  return React.createElement('div',null,
    label?React.createElement('div',{style:{font:'var(--type-label)',color:'var(--ink-muted)'}},label):null,
    React.createElement('div',null,
      React.createElement('span',{style:{font:'var(--type-figure)',fontVariantNumeric:'tabular-nums'}},value),
      React.createElement('span',{style:{font:'700 clamp(22px,2.4vw,30px)/1 var(--f-display)',marginInlineStart:10}},unit)));
}
