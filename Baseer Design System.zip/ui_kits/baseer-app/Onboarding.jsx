(()=>{
const {Button,CollageBand,AmountField,ObligationField,Figure,Piece}=window.BaseerDesignSystem_f0524d;
const bsDigits=v=>String(v).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[^0-9]/g,'');
const bsFmt=n=>Math.round(n).toLocaleString('en-US');
const bsNum=v=>{const d=bsDigits(v);return d?Number(d):0};
const bsInput=v=>{const d=bsDigits(v);return d?Number(d).toLocaleString('en-US'):''};
const bsScreen={flex:1,display:'flex',flexDirection:'column',paddingInline:'var(--gutter-x)',paddingBlock:'8px 100px',animation:'bs-in .45s ease both'};
const bsCenter={...bsScreen,alignItems:'center',justifyContent:'center',textAlign:'center',gap:40};
function BackLink({onClick,children='رجوع'}){return <div style={{alignSelf:'flex-start',marginBottom:-16}}><Button variant="quiet" onClick={onClick}>{children}</Button></div>;}

function WelcomeScreen({go}){
  return <main style={{...bsCenter,position:'relative',paddingBottom:'clamp(190px,30vh,320px)'}}>
    <h1 style={{font:'var(--type-hero)',margin:0,textWrap:'balance',maxWidth:'16ch'}}>فلوسك موجودة… بس هل انت مستغلها؟</h1>
    <p style={{font:'var(--type-lead)',color:'var(--ink-muted)',margin:0,maxWidth:'40ch'}}>جرّب الاستثمار بمحفظة افتراضية مبنية على راتبك الحقيقي.</p>
    <Button onClick={()=>go('salary')}>ابدأ رحلتك</Button>
    <CollageBand/>
  </main>;
}

function SalaryScreen({go,data,set}){
  const f=k=>v=>set({...data,[k]:bsInput(v)});
  return <main style={{...bsScreen,gap:56,justifyContent:'center'}}>
    <div style={{display:'flex',flexDirection:'column',gap:20,maxWidth:620,width:'100%'}}>
      <h1 style={{font:'var(--type-headline)',margin:0}}>كم راتبك؟</h1>
      <AmountField value={data.salary} onChange={f('salary')} placeholder="مثلاً 8,000" ariaLabel="كم راتبك؟"/>
    </div>
    <div style={{display:'flex',flexDirection:'column',gap:22}}>
      <h2 style={{font:'var(--type-title)',margin:0}}>والتزاماتك كل شهر؟</h2>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}>
        <ObligationField label="إيجار" value={data.rent} onChange={f('rent')} cut={2} tilt={1}/>
        <ObligationField label="أقساط" value={data.loan} onChange={f('loan')} cut={3} tilt={-1.5}/>
        <ObligationField label="مصاريف اخرى" value={data.exp} onChange={f('exp')} cut={4}/>
      </div>
    </div>
    <div><Button disabled={!bsNum(data.salary)} onClick={()=>go('margin')}>احسب هامشي</Button></div>
  </main>;
}

function MarginScreen({go,data,pct,setPct,setSpeak}){
  const sal=bsNum(data.salary),ob=bsNum(data.rent)+bsNum(data.loan)+bsNum(data.exp);
  const m=sal-ob,inv=Math.round(m*pct/100),rest=m-inv,warn=m>0&&pct>75;
  React.useEffect(()=>{setSpeak(warn);return()=>setSpeak(false);},[warn]);
  const calc=<p style={{font:'var(--type-caption)',color:'var(--ink-muted)',margin:0,fontVariantNumeric:'tabular-nums'}}>{bsFmt(sal)} راتب − {bsFmt(ob)} التزامات</p>;
  if(m<=0) return <main style={bsCenter}>
    <Piece color="cream" cut={3} lift tilt={-1} style={{padding:'40px 48px',maxWidth:640}}>
      <h1 style={{font:'var(--type-title)',fontSize:32,margin:0,textWrap:'balance'}}>التزاماتك أكبر من راتبك حالياً، خلنا نبدأ بفهم الميزانية أول</h1>
    </Piece>
    <Button onClick={()=>go('salary')}>رجوع</Button>
    {calc}
  </main>;
  const chips=[25,50,75];
  return <main style={{...bsCenter,gap:36}}>
    <Figure label="هامشك الحر" value={bsFmt(m)}/>
    <Button disabled={inv<1} onClick={()=>go('quiz-1',{budget:inv})}>ابدأ بـ{bsFmt(inv)} ريال افتراضية</Button>
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:18}}>
      <div style={{display:'flex',gap:14,alignItems:'flex-start'}} role="radiogroup" aria-label="نسبة الاستثمار">
        {chips.map((c,i)=>{const on=pct===c;return <div key={c} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:6}}>
          <Piece as="button" type="button" role="radio" aria-checked={on} onClick={()=>setPct(c)} color={on?'blue':'faint'} cut={[2,3,4][i]} lift={on} tilt={on?-2:0} style={{border:0,background:'none',cursor:'pointer',padding:'10px 22px',font:'700 18px/1.4 var(--f-sans)',fontVariantNumeric:'tabular-nums',transition:'transform .2s'}}>{c}%</Piece>
          {c===50&&<span style={{font:'var(--type-caption)',color:'var(--ink-muted)'}}>مقترح</span>}
        </div>;})}
      </div>
      <label style={{display:'flex',alignItems:'center',gap:14,font:'var(--type-label)'}}>
        <span style={{color:'var(--ink-muted)'}}>نسبة مخصصة</span>
        <input type="range" min="5" max="100" step="5" value={pct} onChange={e=>setPct(+e.target.value)} style={{width:240,accentColor:'var(--blue)'}}/>
        <b style={{minWidth:'4ch',fontVariantNumeric:'tabular-nums'}}>{pct}%</b>
      </label>
      <p style={{font:'var(--type-body)',margin:0,fontVariantNumeric:'tabular-nums'}}>والباقي {bsFmt(rest)} للطوارئ</p>
      {warn&&<Piece color="orange" cut={3} lift tilt={1} style={{padding:'12px 22px',font:'700 15px/1.4 var(--f-sans)',animation:'bs-pop .35s cubic-bezier(.2,.8,.2,1) both'}}>بصير: تأكد إنك مخلي شي للطوارئ</Piece>}
    </div>
    {calc}
  </main>;
}
Object.assign(window,{WelcomeScreen,SalaryScreen,MarginScreen,BackLink,bsFmt,bsNum,bsScreen,bsCenter});
})();
