import React from 'react';
import { Piece } from '../core/Piece.jsx';

export function OutcomeCard({label,value,color='green',cut=2,tilt=0,emphasis=false}){
  return React.createElement(Piece,{color,cut,lift:true,tilt,style:{width:240,height:220,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:14,transform:emphasis?'translateY(-12px) scale(1.06)':undefined}},
    React.createElement('span',{style:{font:'var(--type-label)'}},label),
    React.createElement('span',{style:{font:'900 60px/1 var(--f-display)',fontVariantNumeric:'tabular-nums',direction:'ltr'}},value));
}
