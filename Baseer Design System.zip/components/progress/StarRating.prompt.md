Star rating (تقييمك) — replaces any numeric score. Overall rating = average stars of all challenges played.
```jsx
<StarRating value={3} size={72} />
<StarRating value={5} animate />  {/* challenge result: stars pop one by one */}
```
- Challenge scale: 5 = no stock >40% and أرامكو+سابك <50%; 4 = no stock >40% but أرامكو+سابك ≥50%; 3 = one stock 40–60%; 2 = 60–80%; 1 = >80%.
- Pair with a caption «تقييمك 3 من 5».
