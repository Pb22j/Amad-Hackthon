import React from 'react';
import { Piece } from '../core/Piece.jsx';

export function LevelPath({levels=['مدّخر','مبتدئ','مستثمر واعي','مخطط مالي'],current=1}){
  const out=[];
  levels.forEach((l,i)=>{
    const done=i<current,on=i===current;
    out.push(React.createElement(Piece,{as:'li',key:'l'+i,color:done?'green':on?'blue':'faint',cut:[2,3,4,1][i%4],lift:on,'aria-current':on?'step':undefined,style:{padding:'14px 24px',font:on?'700 16px/1.4 var(--f-sans)':'500 16px/1.4 var(--f-sans)',color:done?'var(--ink)':on?'var(--cream)':'var(--ink-muted)',transform:on?'rotate(-2deg) scale(1.08)':undefined}},l));
    if(i<levels.length-1) out.push(React.createElement('li',{key:'s'+i,'aria-hidden':true,style:{color:'var(--ink-muted)',font:'500 20px/1 var(--f-sans)'}},'←'));
  });
  return React.createElement('ol',{style:{display:'flex',flexWrap:'wrap',alignItems:'center',gap:12,listStyle:'none',margin:0,padding:0}},out);
}
