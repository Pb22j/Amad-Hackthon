/** Top-level app navigation; active item sits on a blue paper scrap. */
export interface NavTabsProps{
  items?:{id:string;label:string}[];
  current?:string;
  onChange?:(id:string)=>void;
}
export declare function NavTabs(props:NavTabsProps):JSX.Element;
