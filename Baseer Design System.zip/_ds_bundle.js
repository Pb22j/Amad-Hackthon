/* @ds-bundle: {"format":4,"namespace":"BaseerDesignSystem_f0524d","components":[{"name":"Assistant","sourcePath":"components/assistant/Assistant.jsx"},{"name":"CoachBubble","sourcePath":"components/assistant/CoachBubble.jsx"},{"name":"AssistantTip","sourcePath":"components/assistant/CoachBubble.jsx"},{"name":"CollageBand","sourcePath":"components/brand/CollageBand.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Piece","sourcePath":"components/core/Piece.jsx"},{"name":"Wordmark","sourcePath":"components/core/Wordmark.jsx"},{"name":"Figure","sourcePath":"components/finance/Figure.jsx"},{"name":"OutcomeCard","sourcePath":"components/finance/OutcomeCard.jsx"},{"name":"StockCard","sourcePath":"components/finance/StockCard.jsx"},{"name":"AmountField","sourcePath":"components/forms/AmountField.jsx"},{"name":"ObligationField","sourcePath":"components/forms/ObligationField.jsx"},{"name":"NavTabs","sourcePath":"components/navigation/NavTabs.jsx"},{"name":"StepIndicator","sourcePath":"components/navigation/StepIndicator.jsx"},{"name":"TopBar","sourcePath":"components/navigation/TopBar.jsx"},{"name":"FeatureCard","sourcePath":"components/progress/FeatureCard.jsx"},{"name":"LevelPath","sourcePath":"components/progress/LevelPath.jsx"},{"name":"StarRating","sourcePath":"components/progress/StarRating.jsx"}],"sourceHashes":{"components/assistant/Assistant.jsx":"e34b554e3150","components/assistant/CoachBubble.jsx":"0879efbe0097","components/brand/CollageBand.jsx":"6dde39bf3758","components/core/Badge.jsx":"226b6b41be21","components/core/Button.jsx":"eec9568e5530","components/core/Piece.jsx":"741903f818bc","components/core/Wordmark.jsx":"1dfa12dc320c","components/finance/Figure.jsx":"e0e92572b1bf","components/finance/OutcomeCard.jsx":"ee84fb7d8fb7","components/finance/StockCard.jsx":"eefb5ddd09a3","components/forms/AmountField.jsx":"e0e104f47183","components/forms/ObligationField.jsx":"080bf2f663dc","components/navigation/NavTabs.jsx":"b84843a31312","components/navigation/StepIndicator.jsx":"f16e88f0d46f","components/navigation/TopBar.jsx":"5d9629781df0","components/progress/FeatureCard.jsx":"07774d52c101","components/progress/LevelPath.jsx":"59c149fc0d1c","components/progress/StarRating.jsx":"a00445a35876","ui_kits/baseer-app/Arena.jsx":"46205357c63b","ui_kits/baseer-app/Coaster.jsx":"395ec9ebd763","ui_kits/baseer-app/Day27.jsx":"fef643373ff7","ui_kits/baseer-app/FamilyGame.jsx":"c13c82f20202","ui_kits/baseer-app/Games.jsx":"8e6611107e51","ui_kits/baseer-app/Ice.jsx":"4bbdd70a1ec1","ui_kits/baseer-app/Journey.jsx":"5d2778dee155","ui_kits/baseer-app/Onboarding.jsx":"b176091e0d85","ui_kits/baseer-app/Quiz.jsx":"fc500052f5e4","ui_kits/baseer-app/TeamGame.jsx":"0e71033f7c13"},"inlinedExternals":[],"unexposedExports":[{"name":"cutVar","sourcePath":"components/core/Piece.jsx"}]} */

(() => {

const __ds_ns = (window.BaseerDesignSystem_f0524d = window.BaseerDesignSystem_f0524d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/assistant/Assistant.jsx
try { (() => {
function Assistant({
  state = 'idle',
  onClick,
  label
}) {
  const labels = {
    idle: 'تكلّم مع بصير',
    listening: 'بصير يسمعك',
    speaking: 'بصير يتكلم'
  };
  const hs = [8, 18, 12, 22],
    delays = ['0s', '-.3s', '-.6s', '-.15s'];
  return React.createElement('button', {
    type: 'button',
    onClick,
    'aria-label': label || labels[state],
    style: {
      position: 'relative',
      width: 72,
      height: 72,
      flex: 'none',
      border: 0,
      padding: 0,
      background: 'none',
      cursor: 'pointer',
      display: 'grid',
      placeItems: 'center',
      color: 'var(--ink)'
    }
  }, React.createElement('span', {
    'aria-hidden': true,
    style: {
      position: 'absolute',
      inset: 0,
      backgroundColor: 'var(--orange)',
      backgroundImage: 'var(--grain)',
      clipPath: 'var(--circle)'
    }
  }), React.createElement('span', {
    'aria-hidden': true,
    style: {
      position: 'absolute',
      inset: -10,
      border: '2px dashed var(--ink)',
      borderRadius: '50%',
      opacity: state === 'listening' ? 1 : 0,
      animation: state === 'listening' ? 'bs-spin 6s linear infinite' : 'none'
    }
  }), React.createElement('span', {
    'aria-hidden': true,
    style: {
      position: 'relative',
      display: 'flex',
      gap: 3,
      alignItems: 'center',
      height: 26
    }
  }, hs.map((h, i) => React.createElement('i', {
    key: i,
    style: {
      display: 'block',
      width: 4,
      height: h,
      background: 'var(--ink)',
      animation: state === 'speaking' ? 'bs-bar .9s ease-in-out infinite alternate' : 'none',
      animationDelay: delays[i]
    }
  }))));
}
Object.assign(__ds_scope, { Assistant });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/assistant/Assistant.jsx", error: String((e && e.message) || e) }); }

// components/brand/CollageBand.jsx
try { (() => {
const P = [['#4f8f5e', 'M0 96 L170 86 L166 176 L86 182 L84 280 L0 280Z'], ['#1a1a1a', 'M250 70 L330 64 L333 204 L420 198 L418 280 L258 280Z'], ['#e8833a', 'M520 84 L560 60 L612 64 L648 98 L650 146 L620 184 L568 194 L526 172 L504 128Z'], ['#c63b2d', 'M736 34 C810 96 822 206 778 280 L736 280 C766 206 756 110 736 34Z'], ['#4f8f5e', 'M880 58 L1004 50 L1046 112 L1020 196 L908 204 L870 134Z'], ['#e8833a', 'M1100 190 C1150 200 1170 250 1156 280 L1118 280 C1134 250 1126 220 1100 190Z'], ['#f2efe3', 'M1190 112 L1384 100 L1392 280 L1196 280Z']];
function CollageBand({
  height = 'clamp(150px,26vh,270px)',
  style
}) {
  return React.createElement('div', {
    'aria-hidden': true,
    style: {
      position: 'absolute',
      insetInline: 0,
      bottom: 0,
      height,
      pointerEvents: 'none',
      ...style
    }
  }, React.createElement('div', {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundColor: 'var(--blue)',
      backgroundImage: 'var(--grain)',
      clipPath: 'var(--torn)'
    }
  }), React.createElement('svg', {
    viewBox: '0 0 1440 280',
    preserveAspectRatio: 'xMidYMax slice',
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%'
    }
  }, P.map((p, i) => React.createElement('path', {
    key: i,
    fill: p[0],
    d: p[1]
  })), React.createElement('path', {
    d: 'M1230 150 l26 90 M1270 138 l22 104 M1310 132 l20 116 M1350 144 l16 96',
    stroke: '#1a1a1a',
    strokeWidth: 2,
    fill: 'none',
    opacity: .45
  })));
}
Object.assign(__ds_scope, { CollageBand });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/CollageBand.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function Button({
  variant = 'primary',
  disabled = false,
  type = 'button',
  cut = 2,
  children,
  style,
  onClick,
  ...rest
}) {
  const [h, setH] = React.useState(false);
  const base = {
    position: 'relative',
    isolation: 'isolate',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    minHeight: 60,
    padding: '0 44px',
    border: 0,
    background: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    font: 'var(--type-button)',
    color: 'var(--cream)',
    opacity: disabled ? .4 : 1,
    whiteSpace: 'nowrap'
  };
  let layer = null;
  if (variant === 'primary') {
    layer = React.createElement('span', {
      'aria-hidden': true,
      style: {
        position: 'absolute',
        inset: 0,
        zIndex: -1,
        backgroundColor: 'var(--blue)',
        backgroundImage: 'var(--grain)',
        clipPath: 'var(--cut-' + cut + ')',
        transition: 'transform .15s',
        transform: h && !disabled ? 'rotate(-1deg) scale(1.03)' : 'none'
      }
    });
  } else if (variant === 'ghost') {
    base.color = 'var(--ink)';
    layer = React.createElement('span', {
      'aria-hidden': true,
      style: {
        position: 'absolute',
        inset: 0,
        zIndex: -1,
        boxShadow: 'inset 0 0 0 2px var(--line-strong)',
        transition: 'transform .15s',
        transform: h && !disabled ? 'rotate(-1deg) scale(1.03)' : 'none'
      }
    });
  } else if (variant === 'quiet') {
    Object.assign(base, {
      color: 'var(--blue)',
      padding: '0 12px',
      minHeight: 44,
      textDecoration: 'underline',
      textUnderlineOffset: 6,
      textDecorationThickness: 2
    });
  }
  return React.createElement('button', {
    type,
    disabled,
    onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      ...base,
      ...style
    },
    ...rest
  }, layer, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Piece.jsx
try { (() => {
const FILL = {
  cream: 'var(--cream)',
  blue: 'var(--blue)',
  orange: 'var(--orange)',
  green: 'var(--green)',
  red: 'var(--red)',
  ink: 'var(--ink)',
  faint: 'var(--ink-faint)'
};
const TEXT = {
  blue: 'var(--cream)',
  red: 'var(--cream)',
  ink: 'var(--cream)'
};
function cutVar(cut) {
  return cut === 'circle' ? 'var(--circle)' : cut === 'torn' ? 'var(--torn)' : 'var(--cut-' + (cut || 1) + ')';
}
function Piece({
  as = 'div',
  color = 'cream',
  cut = 1,
  lift = false,
  tilt = 0,
  style,
  children,
  ...rest
}) {
  const t = [];
  if (tilt) t.push('rotate(' + tilt + 'deg)');
  if (style && style.transform) t.push(style.transform);
  return React.createElement(as, {
    ...rest,
    style: {
      position: 'relative',
      isolation: 'isolate',
      color: TEXT[color] || 'var(--ink)',
      filter: lift ? 'var(--lift)' : undefined,
      ...style,
      transform: t.length ? t.join(' ') : undefined
    }
  }, React.createElement('span', {
    'aria-hidden': true,
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: -1,
      backgroundColor: FILL[color] || color,
      backgroundImage: 'var(--grain)',
      clipPath: cutVar(cut),
      pointerEvents: 'none'
    }
  }), children);
}
Object.assign(__ds_scope, { cutVar, Piece });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Piece.jsx", error: String((e && e.message) || e) }); }

// components/assistant/CoachBubble.jsx
try { (() => {
function CoachBubble({
  speaker = 'بصير',
  children,
  color = 'orange',
  cut = 4
}) {
  return React.createElement(__ds_scope.Piece, {
    color,
    cut,
    lift: true,
    'aria-live': 'polite',
    style: {
      padding: '24px 32px',
      font: 'var(--type-bubble)'
    }
  }, React.createElement('b', {
    style: {
      display: 'block',
      font: '700 15px/1.5 var(--f-sans)',
      marginBottom: 4
    }
  }, speaker), children);
}
function AssistantTip({
  children
}) {
  return React.createElement(__ds_scope.Piece, {
    as: 'span',
    color: 'faint',
    cut: 2,
    style: {
      padding: '12px 20px',
      font: '700 15px/1.4 var(--f-sans)'
    }
  }, children);
}
Object.assign(__ds_scope, { CoachBubble, AssistantTip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/assistant/CoachBubble.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function Badge({
  color = 'orange',
  cut = 3,
  tilt = -2,
  children,
  style
}) {
  return React.createElement(__ds_scope.Piece, {
    as: 'span',
    color,
    cut,
    lift: true,
    tilt,
    style: {
      display: 'inline-flex',
      padding: '16px 34px',
      font: 'var(--type-button)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Wordmark.jsx
try { (() => {
function Wordmark({
  onClick,
  size = 34,
  style
}) {
  return React.createElement(onClick ? 'button' : 'span', {
    type: onClick ? 'button' : undefined,
    onClick,
    'aria-label': 'بصير',
    style: {
      font: '900 ' + size + 'px/1 var(--f-display)',
      background: 'none',
      border: 0,
      padding: 0,
      cursor: onClick ? 'pointer' : 'default',
      color: 'var(--ink)',
      ...style
    }
  }, 'بصير');
}
Object.assign(__ds_scope, { Wordmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Wordmark.jsx", error: String((e && e.message) || e) }); }

// components/finance/Figure.jsx
try { (() => {
function Figure({
  value,
  unit = 'ريال',
  label,
  variant = 'hero'
}) {
  if (variant === 'points') {
    return React.createElement('div', {
      style: {
        font: '900 46px/1.2 var(--f-display)'
      }
    }, value, ' ', React.createElement('span', {
      style: {
        fontSize: 28,
        fontWeight: 700
      }
    }, unit));
  }
  return React.createElement('div', null, label ? React.createElement('div', {
    style: {
      font: 'var(--type-label)',
      color: 'var(--ink-muted)'
    }
  }, label) : null, React.createElement('div', null, React.createElement('span', {
    style: {
      font: 'var(--type-figure)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, value), React.createElement('span', {
    style: {
      font: '700 clamp(22px,2.4vw,30px)/1 var(--f-display)',
      marginInlineStart: 10
    }
  }, unit)));
}
Object.assign(__ds_scope, { Figure });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/Figure.jsx", error: String((e && e.message) || e) }); }

// components/finance/OutcomeCard.jsx
try { (() => {
function OutcomeCard({
  label,
  value,
  color = 'green',
  cut = 2,
  tilt = 0,
  emphasis = false
}) {
  return React.createElement(__ds_scope.Piece, {
    color,
    cut,
    lift: true,
    tilt,
    style: {
      width: 240,
      height: 220,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 14,
      transform: emphasis ? 'translateY(-12px) scale(1.06)' : undefined
    }
  }, React.createElement('span', {
    style: {
      font: 'var(--type-label)'
    }
  }, label), React.createElement('span', {
    style: {
      font: '900 60px/1 var(--f-display)',
      fontVariantNumeric: 'tabular-nums',
      direction: 'ltr'
    }
  }, value));
}
Object.assign(__ds_scope, { OutcomeCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/OutcomeCard.jsx", error: String((e && e.message) || e) }); }

// components/finance/StockCard.jsx
try { (() => {
const fmt = n => Math.round(n).toLocaleString('en-US');
function StockCard({
  name,
  sector,
  amount = 0,
  color = 'blue',
  cut = 1,
  tilt = 0,
  onInc,
  onDec,
  incDisabled,
  decDisabled,
  dimEmpty = true,
  style,
  children
}) {
  const btn = (label, aria, fn, dis) => React.createElement('button', {
    type: 'button',
    'aria-label': aria,
    onClick: fn,
    disabled: dis,
    style: {
      width: 44,
      height: 44,
      border: '2px solid currentColor',
      background: 'transparent',
      font: '700 20px/1 var(--f-sans)',
      cursor: dis ? 'not-allowed' : 'pointer',
      opacity: dis ? .35 : 1
    }
  }, label);
  return React.createElement(__ds_scope.Piece, {
    color,
    cut,
    lift: true,
    tilt,
    style: {
      width: 180,
      height: 210,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      opacity: dimEmpty && amount === 0 ? .45 : 1,
      transition: 'opacity .2s, transform .5s cubic-bezier(.2,.8,.2,1)',
      ...style
    }
  }, React.createElement('span', {
    style: {
      font: '700 18px/1.4 var(--f-sans)'
    }
  }, name), sector ? React.createElement('span', {
    style: {
      font: 'var(--type-caption)',
      marginTop: -8,
      opacity: .85
    }
  }, sector) : null, React.createElement('span', {
    style: {
      font: '700 34px/1.2 var(--f-display)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, fmt(amount)), children || React.createElement('span', {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 4
    }
  }, btn('+', 'زد ' + name, onInc, incDisabled), btn('−', 'نقّص ' + name, onDec, decDisabled)));
}
Object.assign(__ds_scope, { StockCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/StockCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/AmountField.jsx
try { (() => {
function AmountField({
  value,
  onChange,
  unit = 'ريال',
  ariaLabel,
  id,
  placeholder
}) {
  return React.createElement('label', {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 16,
      borderBottom: '3px solid var(--ink)',
      paddingBottom: 6
    }
  }, React.createElement('input', {
    id,
    inputMode: 'numeric',
    autoComplete: 'off',
    'aria-label': ariaLabel,
    value,
    placeholder,
    onChange: e => onChange && onChange(e.target.value),
    style: {
      all: 'unset',
      flex: 1,
      minWidth: 0,
      font: '900 clamp(56px,7vw,92px)/1.15 var(--f-display)',
      textAlign: 'right',
      fontVariantNumeric: 'tabular-nums'
    }
  }), React.createElement('span', {
    style: {
      font: '500 22px/1 var(--f-sans)',
      color: 'var(--ink-muted)'
    }
  }, unit));
}
Object.assign(__ds_scope, { AmountField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/AmountField.jsx", error: String((e && e.message) || e) }); }

// components/forms/ObligationField.jsx
try { (() => {
function ObligationField({
  label,
  value,
  onChange,
  cut = 2,
  tilt = 0,
  color = 'cream',
  placeholder = '0'
}) {
  return React.createElement(__ds_scope.Piece, {
    as: 'label',
    color,
    cut,
    lift: true,
    tilt,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      padding: '22px 30px',
      minWidth: 190,
      cursor: 'text'
    }
  }, React.createElement('span', {
    style: {
      font: 'var(--type-label)'
    }
  }, label), React.createElement('input', {
    inputMode: 'numeric',
    autoComplete: 'off',
    value,
    placeholder,
    onChange: e => onChange && onChange(e.target.value),
    style: {
      all: 'unset',
      font: '700 30px/1.3 var(--f-display)',
      width: '6ch',
      fontVariantNumeric: 'tabular-nums'
    }
  }));
}
Object.assign(__ds_scope, { ObligationField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/ObligationField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavTabs.jsx
try { (() => {
function NavTabs({
  items = [],
  current,
  onChange
}) {
  return React.createElement('nav', {
    'aria-label': 'التنقل',
    style: {
      display: 'flex',
      gap: 6
    }
  }, items.map(it => {
    const on = it.id === current;
    return React.createElement('button', {
      key: it.id,
      type: 'button',
      'aria-current': on ? 'page' : undefined,
      onClick: () => onChange && onChange(it.id),
      style: {
        position: 'relative',
        isolation: 'isolate',
        background: 'none',
        border: 0,
        padding: '10px 16px',
        font: '700 16px/1 var(--f-sans)',
        cursor: 'pointer',
        color: on ? 'var(--cream)' : 'var(--ink-muted)'
      }
    }, on ? React.createElement('span', {
      'aria-hidden': true,
      style: {
        position: 'absolute',
        inset: 0,
        zIndex: -1,
        background: 'var(--blue)',
        clipPath: 'var(--cut-2)'
      }
    }) : null, it.label);
  }));
}
Object.assign(__ds_scope, { NavTabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavTabs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/StepIndicator.jsx
try { (() => {
function StepIndicator({
  count = 4,
  current = 1,
  label = 'خطوات البداية'
}) {
  const items = [];
  for (let i = 0; i < count; i++) {
    const bg = i < current - 1 ? 'var(--blue)' : i === current - 1 ? 'var(--ink)' : 'var(--line)';
    items.push(React.createElement('li', {
      key: i,
      style: {
        width: 28,
        height: 6,
        background: bg
      }
    }));
  }
  return React.createElement('ol', {
    'aria-label': label,
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      listStyle: 'none',
      margin: 0,
      padding: 0
    }
  }, items);
}
Object.assign(__ds_scope, { StepIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/StepIndicator.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopBar.jsx
try { (() => {
function TopBar({
  onHome,
  children,
  onFullscreen,
  showFullscreen = true
}) {
  return React.createElement('header', {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 16,
      padding: '28px var(--header-pad-x)'
    }
  }, React.createElement(__ds_scope.Wordmark, {
    onClick: onHome
  }), React.createElement('div', {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 20
    }
  }, children, showFullscreen ? React.createElement('button', {
    type: 'button',
    'aria-label': 'ملء الشاشة',
    onClick: onFullscreen,
    style: {
      background: 'none',
      border: '2px solid var(--line-strong)',
      width: 44,
      height: 44,
      display: 'grid',
      placeItems: 'center',
      cursor: 'pointer'
    }
  }, React.createElement('svg', {
    width: 20,
    height: 20,
    viewBox: '0 0 20 20',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 2,
    'aria-hidden': true
  }, React.createElement('path', {
    d: 'M2 7V2h5M13 2h5v5M18 13v5h-5M7 18H2v-5'
  }))) : null));
}
Object.assign(__ds_scope, { TopBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopBar.jsx", error: String((e && e.message) || e) }); }

// components/progress/FeatureCard.jsx
try { (() => {
function FeatureCard({
  icon,
  title,
  body,
  children,
  cut = 2,
  color = 'cream',
  centered = false
}) {
  return React.createElement(__ds_scope.Piece, {
    as: 'article',
    color,
    cut,
    lift: true,
    style: {
      padding: 32,
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      alignItems: centered ? 'center' : 'flex-start',
      justifyContent: centered ? 'center' : undefined,
      textAlign: centered ? 'center' : undefined,
      minWidth: 0
    }
  }, icon || null, title ? React.createElement('h2', {
    style: {
      font: 'var(--type-title)',
      margin: 0
    }
  }, title) : null, body ? React.createElement('p', {
    style: {
      font: 'var(--type-body)',
      margin: 0,
      color: 'var(--ink-muted)'
    }
  }, body) : null, children ? React.createElement('div', {
    style: {
      marginTop: 8
    }
  }, children) : null);
}
Object.assign(__ds_scope, { FeatureCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/progress/FeatureCard.jsx", error: String((e && e.message) || e) }); }

// components/progress/LevelPath.jsx
try { (() => {
function LevelPath({
  levels = ['مدّخر', 'مبتدئ', 'مستثمر واعي', 'مخطط مالي'],
  current = 1
}) {
  const out = [];
  levels.forEach((l, i) => {
    const done = i < current,
      on = i === current;
    out.push(React.createElement(__ds_scope.Piece, {
      as: 'li',
      key: 'l' + i,
      color: done ? 'green' : on ? 'blue' : 'faint',
      cut: [2, 3, 4, 1][i % 4],
      lift: on,
      'aria-current': on ? 'step' : undefined,
      style: {
        padding: '14px 24px',
        font: on ? '700 16px/1.4 var(--f-sans)' : '500 16px/1.4 var(--f-sans)',
        color: done ? 'var(--ink)' : on ? 'var(--cream)' : 'var(--ink-muted)',
        transform: on ? 'rotate(-2deg) scale(1.08)' : undefined
      }
    }, l));
    if (i < levels.length - 1) out.push(React.createElement('li', {
      key: 's' + i,
      'aria-hidden': true,
      style: {
        color: 'var(--ink-muted)',
        font: '500 20px/1 var(--f-sans)'
      }
    }, '←'));
  });
  return React.createElement('ol', {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      gap: 12,
      listStyle: 'none',
      margin: 0,
      padding: 0
    }
  }, out);
}
Object.assign(__ds_scope, { LevelPath });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/progress/LevelPath.jsx", error: String((e && e.message) || e) }); }

// components/progress/StarRating.jsx
try { (() => {
const STAR = 'polygon(50% 1%,62% 35%,98.5% 36%,69% 58%,80% 95%,50% 73%,19.5% 94%,31% 57.5%,1.5% 35%,38.5% 34%)';
function StarRating({
  value = 0,
  max = 5,
  size = 56,
  gap,
  animate = false,
  delay = 0,
  step = 260,
  label
}) {
  const stars = [];
  for (let i = 0; i < max; i++) {
    const fill = Math.max(0, Math.min(1, value - i));
    const piece = (bg, extra) => React.createElement('span', {
      style: {
        position: 'absolute',
        top: 0,
        insetInlineStart: 0,
        width: size,
        height: size,
        backgroundColor: bg,
        backgroundImage: 'var(--grain)',
        clipPath: STAR,
        ...extra
      }
    });
    stars.push(React.createElement('span', {
      key: i,
      style: {
        position: 'relative',
        width: size,
        height: size,
        flex: 'none',
        transform: 'rotate(' + [-4, 3, -2, 4, -3][i % 5] + 'deg)'
      }
    }, piece('rgba(26,26,26,.1)'), fill > 0 ? React.createElement('span', {
      style: {
        position: 'absolute',
        top: 0,
        insetInlineStart: 0,
        width: fill * 100 + '%',
        height: size,
        overflow: 'hidden',
        filter: 'var(--lift)',
        animation: animate ? 'bs-pop .45s cubic-bezier(.3,1.5,.5,1) both' : 'none',
        animationDelay: delay + i * step + 'ms'
      }
    }, piece('var(--orange)')) : null));
  }
  return React.createElement('div', {
    role: 'img',
    'aria-label': label || 'تقييمك ' + value + ' من ' + max,
    style: {
      display: 'flex',
      gap: gap ?? Math.round(size * .18),
      alignItems: 'center'
    }
  }, stars);
}
Object.assign(__ds_scope, { StarRating });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/progress/StarRating.jsx", error: String((e && e.message) || e) }); }

// ui_kits/baseer-app/Arena.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
(() => {
  const {
    Piece,
    CoachBubble,
    Badge,
    Button
  } = window.BaseerDesignSystem_f0524d;
  const STK = [{
    n: 'صقر للتقنية',
    ch: 4.2,
    c: 'blue'
  }, {
    n: 'نخلة للتطوير',
    ch: -2.1,
    c: 'green'
  }, {
    n: 'موجة للطاقة',
    ch: 1.3,
    c: 'orange'
  }, {
    n: 'قمرة للاتصالات',
    ch: -0.8,
    c: 'cream'
  }, {
    n: 'رمال للتعدين',
    ch: 3.5,
    c: 'red'
  }, {
    n: 'واحة للأغذية',
    ch: -1.6,
    c: 'ink'
  }];
  function Arena({
    S,
    alert
  }) {
    const alloc = alert ? [70, 6, 6, 6, 6, 6] : [20, 15, 20, 15, 15, 15];
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        gap: 22,
        position: 'relative',
        alignItems: 'center',
        paddingBottom: alert ? 40 : 100
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 16,
        alignItems: 'center',
        alignSelf: 'stretch',
        justifyContent: 'space-between',
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      color: "ink"
    }, "\u0627\u0644\u064A\u0648\u0645 12 \u0645\u0646 30"), /*#__PURE__*/React.createElement(Chip, {
      color: "cream",
      lift: true
    }, "\u0645\u062D\u0641\u0638\u062A\u0643: ", bsFmt(S.budget), " \u0631\u064A\u0627\u0644")), /*#__PURE__*/React.createElement(Chip, {
      color: alert ? 'red' : 'faint',
      lift: alert
    }, "\u0625\u0646\u0630\u0627\u0631\u0627\u062A \u0627\u0644\u0645\u0631\u0627\u0642\u0628: ", alert ? 1 : 0)), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-headline)',
        margin: 0,
        textAlign: 'center'
      }
    }, "\u0633\u0627\u062D\u0629 \u0627\u0644\u062A\u0630\u0628\u0630\u0628. \u0647\u0646\u0627 \u0627\u0644\u0633\u0648\u0642 \u064A\u062A\u062D\u0631\u0643 \u0628\u0633\u0631\u0639\u0629 \u26A1"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexWrap: 'wrap',
        gap: 28,
        justifyContent: 'center',
        alignItems: 'center',
        maxWidth: 1000
      }
    }, STK.map((s, i) => {
      const big = alert && i === 0,
        up = s.ch > 0;
      return /*#__PURE__*/React.createElement("div", {
        key: s.n,
        style: {
          '--r': [-1.5, 1, -.5, 1.5, -1, .5][i] + 'deg',
          animation: 'bs-jitter ' + (.7 + i * .11) + 's ease-in-out infinite',
          animationDelay: -i * .17 + 's'
        }
      }, /*#__PURE__*/React.createElement(Piece, {
        color: s.c,
        cut: i % 4 + 1,
        lift: true,
        style: {
          width: big ? 300 : alert ? 200 : 240,
          height: big ? 200 : alert ? 140 : 160,
          ...bsCol,
          gap: 8,
          transition: 'width .5s, height .5s'
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          font: '700 ' + (big ? 22 : 18) + 'px/1.3 var(--f-sans)'
        }
      }, s.n), /*#__PURE__*/React.createElement(Piece, {
        as: "span",
        color: "cream",
        cut: 2,
        style: {
          padding: '3px 12px',
          font: '700 16px/1.4 var(--f-sans)',
          direction: 'ltr',
          color: up ? 'var(--green)' : 'var(--red)'
        }
      }, (up ? '↑' : '↓') + Math.abs(s.ch) + '%'), /*#__PURE__*/React.createElement("span", {
        style: {
          font: '900 ' + (big ? 36 : 26) + 'px/1.1 var(--f-display)',
          fontVariantNumeric: 'tabular-nums',
          whiteSpace: 'nowrap'
        }
      }, "\u062D\u0635\u062A\u0643 ", alloc[i], "%")));
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        position: alert ? 'relative' : 'absolute',
        left: alert ? undefined : 0,
        bottom: alert ? undefined : 20,
        alignSelf: 'flex-start',
        display: 'flex',
        gap: 18,
        alignItems: 'flex-end',
        direction: 'ltr',
        marginTop: alert ? 4 : 0
      }
    }, /*#__PURE__*/React.createElement(EyeOrb, {
      alert: alert
    }), alert && /*#__PURE__*/React.createElement("div", {
      dir: "rtl",
      style: {
        maxWidth: 380,
        marginBottom: 40,
        transformOrigin: 'left bottom',
        animation: 'bs-pop .45s cubic-bezier(.3,1.4,.5,1) .4s both',
        textAlign: 'right'
      }
    }, /*#__PURE__*/React.createElement(CoachBubble, {
      color: "red",
      speaker: "\u0645\u0631\u0627\u0642\u0628 \u0627\u0644\u0645\u062E\u0627\u0637\u0631 \uD83D\uDC41\uFE0F"
    }, "\u0627\u0646\u062A\u0628\u0647: 70% \u0645\u0646 \u0641\u0644\u0648\u0633\u0643 \u0641\u064A \u0633\u0647\u0645 \u0648\u0627\u062D\u062F."))));
  }
  const ArenaCalm = p => /*#__PURE__*/React.createElement(Arena, p);
  const ArenaAlert = p => /*#__PURE__*/React.createElement(Arena, _extends({}, p, {
    alert: true
  }));
  const BURST = [['blue', 6, 12, 150, 110, -12, 1], ['orange', 88, 10, 120, 120, 10, 'circle'], ['green', 12, 72, 170, 90, 8, 3], ['red', 86, 66, 140, 150, -9, 2], ['orange', 28, 4, 80, 60, 18, 4], ['green', 70, 3, 100, 70, -14, 1], ['red', 3, 42, 70, 120, 6, 2], ['blue', 96, 40, 60, 140, -5, 3], ['cream', 20, 94, 120, 50, -6, 4], ['blue', 78, 94, 150, 60, 7, 2], ['green', 97, 90, 70, 70, 22, 1], ['red', 44, -1, 90, 44, -4, 3], ['orange', 58, 99, 70, 70, 0, 'circle']];
  function Graduation() {
    return /*#__PURE__*/React.createElement("main", {
      style: {
        flex: 1,
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 26,
        padding: '0 var(--gutter-x) 70px',
        textAlign: 'center',
        color: 'var(--cream)'
      }
    }, BURST.map(([c, x, y, w, h, r, cut], i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      "aria-hidden": "true",
      style: {
        position: 'absolute',
        left: x + '%',
        top: y + '%',
        '--bx': (50 - x) * 11 + 'px',
        '--by': (50 - y) * 7 + 'px',
        animation: 'bs-burst .9s cubic-bezier(.2,.9,.3,1.2) both',
        animationDelay: i * 40 + 'ms'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: c,
      cut: cut,
      tilt: r,
      style: {
        width: w,
        height: h,
        transform: 'translate(-50%,-50%)'
      }
    }))), /*#__PURE__*/React.createElement("h1", {
      style: {
        position: 'relative',
        font: '900 clamp(44px,5.4vw,78px)/1.3 var(--f-display)',
        margin: 0,
        maxWidth: '17ch',
        textWrap: 'balance',
        animation: 'bs-in .6s ease .5s both'
      }
    }, "\u0643\u0641\u0648! \u0623\u062B\u0628\u062A \u062C\u062F\u0627\u0631\u062A\u0643 \u0648\u0635\u0631\u062A \u062C\u0627\u0647\u0632 \u0644\u0644\u0633\u0648\u0642 \u0627\u0644\u0635\u062F\u0642\u064A"), /*#__PURE__*/React.createElement("div", {
      style: {
        animation: 'bs-pop .5s cubic-bezier(.3,1.4,.5,1) .9s both'
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      style: {
        font: '900 34px/1.3 var(--f-display)',
        padding: '18px 48px'
      }
    }, "\u0645\u0633\u062A\u062B\u0645\u0631 \u0648\u0627\u0639\u064A")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 16,
        animation: 'bs-in .5s ease 1.2s both'
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      color: "blue",
      big: true
    }, "\u2B50 5 \u0646\u062C\u0648\u0645"), /*#__PURE__*/React.createElement(Chip, {
      color: "green",
      big: true
    }, "\uD83C\uDFAE 5 \u0623\u0644\u0639\u0627\u0628"), /*#__PURE__*/React.createElement(Chip, {
      color: "red",
      big: true
    }, "\uD83D\uDC41\uFE0F \u0625\u0646\u0630\u0627\u0631\u064A\u0646 \u0628\u0633")), /*#__PURE__*/React.createElement("div", {
      style: {
        animation: 'bs-deal .6s cubic-bezier(.2,.8,.2,1) 1.5s both',
        marginTop: 8
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "cream",
      cut: 3,
      lift: true,
      style: {
        padding: '28px 40px',
        display: 'flex',
        gap: 40,
        alignItems: 'center',
        textAlign: 'right'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        font: 'var(--type-title)',
        margin: 0
      }
    }, "\u062C\u0627\u0647\u0632 \u062A\u0628\u062F\u0623 \u0628\u0641\u0644\u0648\u0633 \u062D\u0642\u064A\u0642\u064A\u0629\u061F"), /*#__PURE__*/React.createElement("p", {
      style: {
        font: 'var(--type-body)',
        margin: 0,
        color: 'var(--ink-muted)'
      }
    }, "\u0627\u0641\u062A\u062D \u062D\u0633\u0627\u0628\u0643 \u0639\u0646\u062F \u0634\u0631\u064A\u0643 \u0648\u0633\u0627\u0637\u0629 \u0645\u0631\u062E\u0651\u0635 \u0645\u0646 \u0647\u064A\u0626\u0629 \u0627\u0644\u0633\u0648\u0642 \u0627\u0644\u0645\u0627\u0644\u064A\u0629")), /*#__PURE__*/React.createElement(Button, null, "\u0627\u0641\u062A\u062D \u062D\u0633\u0627\u0628\u064A"))));
  }
  Object.assign(window, {
    ArenaCalm,
    ArenaAlert,
    Graduation
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/baseer-app/Arena.jsx", error: String((e && e.message) || e) }); }

// ui_kits/baseer-app/Coaster.jsx
try { (() => {
(() => {
  const {
    Piece,
    Button
  } = window.BaseerDesignSystem_f0524d;
  const CP = [[0, .30], [.12, .12], [.26, .48], [.38, .28], [.56, .86], [.74, .40], [.86, .14], [1, .06]];
  const yAt = x => {
    for (let i = 0; i < CP.length - 1; i++) {
      const [x0, y0] = CP[i],
        [x1, y1] = CP[i + 1];
      if (x <= x1) {
        const m = (1 - Math.cos((x - x0) / (x1 - x0) * Math.PI)) / 2;
        return y0 * (1 - m) + y1 * m;
      }
    }
    return CP[CP.length - 1][1];
  };
  const DIP = .56,
    TOPX = .9;
  const tag = /*#__PURE__*/React.createElement(GameTag, {
    n: 4,
    icon: "\uD83C\uDFA2",
    name: "\u0627\u0644\u0642\u0637\u0627\u0631 \u0627\u0644\u0623\u0641\u0639\u0648\u0627\u0646\u064A"
  });
  function Track({
    W = 1000,
    H = 340,
    cartX = DIP,
    ghostX,
    labels
  }) {
    const N = 64,
      strips = [],
      sup = [];
    for (let i = 0; i < N; i++) {
      const a = i / N,
        b = (i + 1) / N,
        x0 = a * W,
        y0 = yAt(a) * H,
        x1 = b * W,
        y1 = yAt(b) * H,
        len = Math.hypot(x1 - x0, y1 - y0),
        ang = Math.atan2(y1 - y0, x1 - x0) * 180 / Math.PI,
        mx = (x0 + x1) / 2,
        my = (y0 + y1) / 2;
      strips.push(/*#__PURE__*/React.createElement("span", {
        key: i,
        style: {
          position: 'absolute',
          left: mx - len / 2 - 1,
          top: my - 5,
          width: len + 3,
          height: 10,
          background: i % 2 ? 'var(--ink)' : '#2a2a2a',
          transform: 'rotate(' + ang + 'deg)'
        }
      }));
      if (i % 5 === 2) sup.push(/*#__PURE__*/React.createElement("span", {
        key: 's' + i,
        style: {
          position: 'absolute',
          left: mx - 3,
          top: my,
          width: 6,
          height: H - my + 20,
          background: 'var(--line)'
        }
      }));
    }
    const cart = (x, ghost) => {
      const y = yAt(x) * H,
        ang = Math.atan2(yAt(x + .01) * H - yAt(x - .01) * H, .02 * W) * 180 / Math.PI;
      return /*#__PURE__*/React.createElement("div", {
        style: {
          position: 'absolute',
          left: x * W,
          top: y - 5,
          transform: 'translate(-50%,-100%) rotate(' + ang + 'deg)',
          transformOrigin: '50% 100%',
          zIndex: 2,
          opacity: ghost ? .35 : 1
        }
      }, /*#__PURE__*/React.createElement(Piece, {
        color: ghost ? 'cream' : 'orange',
        cut: 3,
        lift: !ghost,
        style: {
          width: 120,
          height: 54,
          display: 'grid',
          placeItems: 'center',
          font: '700 17px/1 var(--f-sans)',
          outline: ghost ? '2px dashed var(--ink)' : 'none'
        }
      }, "\u0645\u062D\u0641\u0638\u062A\u0643"), /*#__PURE__*/React.createElement("span", {
        style: {
          position: 'absolute',
          bottom: -8,
          left: 18,
          width: 16,
          height: 16,
          background: 'var(--ink)',
          clipPath: 'var(--circle)'
        }
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          position: 'absolute',
          bottom: -8,
          right: 18,
          width: 16,
          height: 16,
          background: 'var(--ink)',
          clipPath: 'var(--circle)'
        }
      }));
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: W,
        height: H + 20,
        direction: 'ltr',
        flex: 'none'
      }
    }, sup, strips, ghostX != null && cart(ghostX, true), cart(cartX), (labels || []).map((l, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        position: 'absolute',
        left: l.x * W,
        top: yAt(l.x) * H + (l.dy || -120),
        transform: 'translateX(-50%)',
        zIndex: 3,
        direction: 'rtl'
      }
    }, l.el)));
  }
  function CoasterPlay({
    go
  }) {
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        alignItems: 'center',
        gap: 14
      }
    }, tag, /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-headline)',
        margin: 0
      }
    }, "\u0623\u0646\u062A \u0641\u064A \u0623\u0639\u0645\u0642 \u0646\u0632\u0644\u0629\u2026 \u0648\u0634 \u0628\u062A\u0633\u0648\u064A\u061F"), /*#__PURE__*/React.createElement(Track, {
      labels: [{
        x: .45,
        dy: -150,
        el: /*#__PURE__*/React.createElement("div", {
          style: {
            '--r': '-8deg',
            animation: 'bs-float .5s ease-in-out infinite alternate'
          }
        }, /*#__PURE__*/React.createElement(Chip, {
          color: "red",
          big: true,
          lift: true
        }, "\u0628\u064A\u0637\u064A\u064A\u064A\u062D!"))
      }, {
        x: .68,
        dy: -130,
        el: /*#__PURE__*/React.createElement("div", {
          style: {
            '--r': '6deg',
            animation: 'bs-float .6s ease-in-out infinite alternate'
          }
        }, /*#__PURE__*/React.createElement(Chip, {
          color: "cream",
          big: true,
          lift: true
        }, "\u0627\u0627\u0627\u0627\u0647 \uD83D\uDE31"))
      }]
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-caption)',
        color: 'var(--ink-muted)',
        marginTop: -8
      }
    }, "\u0645\u0633\u0627\u0631 \u0627\u0644\u0633\u0648\u0642"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 28,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: () => go('coaster-lose'),
      style: {
        position: 'relative',
        isolation: 'isolate',
        border: 0,
        background: 'none',
        minHeight: 88,
        padding: '0 64px',
        font: '900 36px/1 var(--f-display)',
        color: 'var(--cream)',
        cursor: 'pointer',
        animation: 'bs-shake .55s ease-in-out infinite'
      }
    }, /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        position: 'absolute',
        inset: 0,
        zIndex: -1,
        background: 'var(--red)',
        backgroundImage: 'var(--grain)',
        clipPath: 'var(--cut-3)',
        filter: 'var(--lift)'
      }
    }), "\u0646\u0632\u0651\u0644\u0646\u064A!"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => go('coaster-win')
    }, "\u0623\u0635\u0628\u0631 \u0648\u0623\u0643\u0645\u0644")));
  }
  function MovingTrack() {
    const on = useLater(400);
    const x = useTween(on ? TOPX : DIP, 1600);
    return /*#__PURE__*/React.createElement(Track, {
      W: 820,
      H: 280,
      cartX: x
    });
  }
  function CoasterWin({
    go,
    onWin
  }) {
    return /*#__PURE__*/React.createElement(Result, {
      id: "coaster",
      win: true,
      tag: tag,
      go: go,
      onWin: onWin,
      headline: "\u0627\u0644\u0635\u0628\u0631 \u0647\u0648 \u0646\u0635 \u0627\u0644\u0644\u0639\u0628\u0629",
      lesson: "\u0644\u0627 \u062A\u0628\u064A\u0639 \u0628\u0647\u0644\u0639 \u0648\u0642\u062A \u0627\u0644\u0647\u0628\u0648\u0637.",
      scene: /*#__PURE__*/React.createElement(MovingTrack, null)
    });
  }
  function CoasterLose({
    go,
    onWin
  }) {
    return /*#__PURE__*/React.createElement(Result, {
      id: "coaster",
      tag: tag,
      go: go,
      onWin: onWin,
      lesson: "\u0623\u063A\u0644\u0628 \u0627\u0644\u0646\u0627\u0633 \u062A\u062E\u0633\u0631 \u0644\u0623\u0646\u0647\u0627 \u062A\u0646\u0632\u0644 \u0641\u064A \u0623\u0633\u0648\u0623 \u0644\u062D\u0638\u0629.",
      scene: /*#__PURE__*/React.createElement(Track, {
        W: 820,
        H: 280,
        ghostX: TOPX,
        labels: [{
          x: DIP,
          dy: -110,
          el: /*#__PURE__*/React.createElement(Chip, {
            color: "red",
            lift: true
          }, "\u0646\u0632\u0644\u062A \u0647\u0646\u0627")
        }, {
          x: TOPX,
          dy: -100,
          el: /*#__PURE__*/React.createElement(Chip, {
            color: "green",
            lift: true
          }, "\u0627\u0644\u0633\u0648\u0642 \u0643\u0645\u0651\u0644")
        }]
      })
    });
  }
  Object.assign(window, {
    CoasterPlay,
    CoasterWin,
    CoasterLose
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/baseer-app/Coaster.jsx", error: String((e && e.message) || e) }); }

// ui_kits/baseer-app/Day27.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
(() => {
  const {
    Piece,
    Button
  } = window.BaseerDesignSystem_f0524d;
  const JAR = 'polygon(30% 0,70% 0,70% 9%,80% 13%,91% 22%,96% 36%,97% 86%,92% 96%,80% 100%,20% 100%,8% 96%,3% 86%,4% 36%,9% 22%,20% 13%,30% 9%)';
  const JARS = [{
    k: 'rent',
    n: 'إيجار',
    c: 'blue'
  }, {
    k: 'loan',
    n: 'أقساط',
    c: 'ink'
  }, {
    k: 'emg',
    n: 'طوارئ',
    c: 'green'
  }, {
    k: 'inv',
    n: 'استثمار',
    c: 'orange'
  }];
  const FILL = {
    blue: 'var(--blue)',
    ink: 'var(--ink)',
    green: 'var(--green)',
    orange: 'var(--orange)'
  };
  const SAL = 8000,
    REPAIR = 1200,
    CAP = 3000;
  const tag = /*#__PURE__*/React.createElement(GameTag, {
    n: 1,
    icon: "\uD83D\uDCB8",
    name: "\u064A\u0648\u0645 27"
  });
  function Jar({
    n,
    c,
    amount,
    w = 150,
    h = 196,
    onClick,
    chip
  }) {
    const v = useTween(amount, 800),
      fill = Math.min(1, v / CAP),
      txt = (c === 'blue' || c === 'ink') && fill > .5 ? 'var(--cream)' : 'var(--ink)';
    const body = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: w,
        height: h,
        filter: 'var(--lift)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'var(--cream)',
        backgroundImage: 'var(--grain)',
        clipPath: JAR
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        inset: 0,
        clipPath: JAR
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        insetInline: 0,
        bottom: 0,
        height: fill * 100 + '%',
        background: FILL[c],
        backgroundImage: 'var(--grain)'
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -8,
        left: '25%',
        right: '25%',
        height: 16,
        background: 'var(--ink)',
        clipPath: 'var(--cut-2)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        inset: 0,
        display: 'grid',
        placeItems: 'center',
        paddingTop: '30%',
        font: '900 ' + Math.round(w / 6) + 'px/1 var(--f-display)',
        fontVariantNumeric: 'tabular-nums',
        color: txt
      }
    }, bsFmt(v)), chip && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -30,
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 2
      }
    }, chip)), /*#__PURE__*/React.createElement("span", {
      style: {
        font: '700 17px/1.4 var(--f-sans)'
      }
    }, n));
    const st = {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 10,
      background: 'none',
      border: 0,
      padding: 0
    };
    return onClick ? /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: onClick,
      "aria-label": 'حط 250 في ' + n,
      style: {
        ...st,
        cursor: 'pointer'
      }
    }, body) : /*#__PURE__*/React.createElement("div", {
      style: st
    }, body);
  }
  function LiveJar({
    from,
    to,
    ...p
  }) {
    const on = useLater(700);
    return /*#__PURE__*/React.createElement(Jar, _extends({
      amount: on ? to : from
    }, p));
  }
  const NOTES = [8, 19, 31, 44, 57, 69, 81, 92, 38, 63];
  const TEMPT = [{
    t: 'تخفيضات!',
    x: 4,
    y: 44,
    r: -8
  }, {
    t: 'توصيل مجاني',
    x: 84,
    y: 40,
    r: 7
  }, {
    t: 'جوال جديد بالتقسيط',
    x: 78,
    y: 80,
    r: -5
  }, {
    t: 'عرض لفترة محدودة',
    x: 2,
    y: 80,
    r: 5
  }];
  function Day27Play({
    go,
    S,
    put
  }) {
    const j = S.d27,
      left = SAL - j.rent - j.loan - j.emg - j.inv;
    const add = k => {
      if (left <= 0) return;
      put({
        d27: {
          ...j,
          [k]: j[k] + Math.min(250, left)
        }
      });
    };
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        alignItems: 'center',
        gap: 18,
        position: 'relative'
      }
    }, tag, /*#__PURE__*/React.createElement("div", {
      "aria-hidden": "true",
      style: {
        position: 'absolute',
        inset: '0 0 45% 0',
        overflow: 'hidden',
        pointerEvents: 'none'
      }
    }, NOTES.map((x, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        position: 'absolute',
        left: x + '%',
        top: 0,
        animation: 'bs-fall ' + (2.6 + i % 3 * .5) + 's linear infinite',
        animationDelay: -i * .55 + 's'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "green",
      cut: i % 4 + 1,
      lift: true,
      tilt: i % 2 ? 12 : -10,
      style: {
        width: 66,
        height: 34,
        display: 'grid',
        placeItems: 'center',
        font: '700 14px/1 var(--f-sans)'
      }
    }, "100")))), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: '900 clamp(44px,5.4vw,68px)/1.3 var(--f-display)',
        margin: '20px 0 0',
        position: 'relative'
      }
    }, "\u0646\u0632\u0644 \u0627\u0644\u0631\u0627\u062A\u0628! \uD83D\uDCB8"), /*#__PURE__*/React.createElement("p", {
      style: {
        font: 'var(--type-lead)',
        color: 'var(--ink-muted)',
        margin: 0,
        position: 'relative'
      }
    }, "\u0648\u0632\u0651\u0639 8,000 \u0631\u064A\u0627\u0644 \u0639\u0644\u0649 \u062C\u0631\u0627\u0631\u0643. \u0643\u0644 \u0636\u063A\u0637\u0629 \u0639\u0644\u0649 \u0627\u0644\u062C\u0631\u0629 = 250."), /*#__PURE__*/React.createElement(Piece, {
      color: "ink",
      cut: 2,
      style: {
        padding: '8px 20px',
        font: '700 18px/1.4 var(--f-sans)',
        fontVariantNumeric: 'tabular-nums'
      },
      "aria-live": "polite"
    }, "\u0628\u0627\u0642\u064A \u0628\u064A\u062F\u0643 ", bsFmt(left), " \u0631\u064A\u0627\u0644"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 44,
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginTop: 18
      }
    }, JARS.map(x => /*#__PURE__*/React.createElement(Jar, {
      key: x.k,
      n: x.n,
      c: x.c,
      amount: j[x.k],
      onClick: () => add(x.k)
    }))), TEMPT.map((t, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      "aria-hidden": "true",
      style: {
        position: 'absolute',
        left: t.x + '%',
        top: t.y + '%',
        '--r': t.r + 'deg',
        animation: 'bs-float ' + (1.4 + i * .3) + 's ease-in-out infinite alternate',
        pointerEvents: 'none'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "red",
      cut: i % 4 + 1,
      lift: true,
      style: {
        padding: '10px 18px',
        font: '700 16px/1.4 var(--f-sans)',
        whiteSpace: 'nowrap'
      }
    }, t.t))), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go('d27-surprise')
    }, "\u0643\u0645\u0651\u0644 \u0627\u0644\u0634\u0647\u0631"));
  }
  function Day27Surprise({
    go,
    S
  }) {
    const j = S.d27,
      ok = j.emg >= REPAIR;
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        alignItems: 'center',
        justifyContent: 'center',
        gap: 30
      }
    }, tag, /*#__PURE__*/React.createElement("div", {
      style: {
        animation: 'bs-drop .7s cubic-bezier(.3,1.3,.5,1) both'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "cream",
      cut: "torn",
      lift: true,
      tilt: -2,
      style: {
        padding: '34px 64px 28px',
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'block',
        font: 'var(--type-label)',
        color: 'var(--ink-muted)'
      }
    }, "\u0646\u0635 \u0627\u0644\u0634\u0647\u0631\u2026"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'block',
        font: '900 clamp(40px,5vw,64px)/1.3 var(--f-display)'
      }
    }, "\u062A\u0639\u0637\u0644\u062A \u0627\u0644\u0633\u064A\u0627\u0631\u0629 \uD83D\uDE97\uD83D\uDCA5"))), /*#__PURE__*/React.createElement("div", {
      style: {
        animation: 'bs-pop .45s cubic-bezier(.3,1.4,.5,1) .8s both'
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      color: "red",
      big: true,
      tilt: 2,
      lift: true
    }, "\u0627\u0644\u062A\u0635\u0644\u064A\u062D: 1,200 \u0631\u064A\u0627\u0644")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 40,
        alignItems: 'flex-end'
      }
    }, /*#__PURE__*/React.createElement(Jar, {
      n: "\u0637\u0648\u0627\u0631\u0626",
      c: "green",
      amount: j.emg,
      w: 120,
      h: 156
    }), /*#__PURE__*/React.createElement(Jar, {
      n: "\u0627\u0633\u062A\u062B\u0645\u0627\u0631",
      c: "orange",
      amount: j.inv,
      w: 120,
      h: 156
    })), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go(ok ? 'd27-win' : 'd27-lose')
    }, "\u0645\u0646 \u0648\u064A\u0646 \u0628\u062A\u062F\u0641\u0639\u061F"));
  }
  function Day27Win({
    go,
    S,
    onWin
  }) {
    const j = S.d27,
      e = j.emg >= REPAIR ? j.emg : 1500,
      inv = j.inv || 750;
    return /*#__PURE__*/React.createElement(Result, {
      id: "d27",
      win: true,
      tag: tag,
      go: go,
      onWin: onWin,
      headline: "\u0643\u0641\u0648! \u0627\u0644\u0637\u0648\u0627\u0631\u0626 \u062D\u0645\u062A \u0627\u0633\u062A\u062B\u0645\u0627\u0631\u0643",
      lesson: "\u062E\u0644\u0651 \u0645\u0628\u0644\u063A \u0644\u0644\u0637\u0648\u0627\u0631\u0626 \u0642\u0628\u0644 \u0645\u0627 \u062A\u0633\u062A\u062B\u0645\u0631.",
      scene: /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          gap: 40,
          alignItems: 'flex-end',
          paddingTop: 30
        }
      }, /*#__PURE__*/React.createElement(LiveJar, {
        n: "\u0637\u0648\u0627\u0631\u0626",
        c: "green",
        from: e,
        to: e - REPAIR,
        chip: /*#__PURE__*/React.createElement(Chip, {
          color: "red",
          lift: true
        }, "\u22121,200 \u062A\u0635\u0644\u064A\u062D")
      }), /*#__PURE__*/React.createElement(LiveJar, {
        n: "\u0627\u0633\u062A\u062B\u0645\u0627\u0631",
        c: "orange",
        from: inv,
        to: inv,
        chip: /*#__PURE__*/React.createElement(Chip, {
          color: "green",
          lift: true
        }, "\u0633\u0644\u064A\u0645")
      }))
    });
  }
  function Day27Lose({
    go,
    S,
    onWin
  }) {
    const inv = S.d27.inv > 0 ? S.d27.inv : 1500;
    return /*#__PURE__*/React.createElement(Result, {
      id: "d27",
      tag: tag,
      go: go,
      onWin: onWin,
      lesson: "\u0634\u0641\u062A\u061F \u0627\u0644\u0637\u0648\u0627\u0631\u0626 \u0645\u0648 \u0631\u0641\u0627\u0647\u064A\u0629. \u0647\u064A \u0627\u0644\u0644\u064A \u062A\u062D\u0645\u064A \u0627\u0633\u062A\u062B\u0645\u0627\u0631\u0643.",
      scene: /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          gap: 40,
          alignItems: 'flex-end',
          paddingTop: 30
        }
      }, /*#__PURE__*/React.createElement(Jar, {
        n: "\u0637\u0648\u0627\u0631\u0626",
        c: "green",
        amount: 0,
        chip: /*#__PURE__*/React.createElement(Chip, null, "\u0641\u0627\u0636\u064A\u0629")
      }), /*#__PURE__*/React.createElement(LiveJar, {
        n: "\u0627\u0633\u062A\u062B\u0645\u0627\u0631",
        c: "orange",
        from: inv,
        to: Math.max(0, inv - REPAIR),
        chip: /*#__PURE__*/React.createElement(Chip, {
          color: "red",
          lift: true
        }, "\u22121,200 \u062A\u0635\u0644\u064A\u062D")
      }))
    });
  }
  Object.assign(window, {
    Day27Play,
    Day27Surprise,
    Day27Win,
    Day27Lose
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/baseer-app/Day27.jsx", error: String((e && e.message) || e) }); }

// ui_kits/baseer-app/FamilyGame.jsx
try { (() => {
(() => {
  const {
    Piece,
    Button
  } = window.BaseerDesignSystem_f0524d;
  const WHO = {
    abu: {
      n: 'خالك أبو فهد',
      c: 'blue',
      cut: 1
    },
    cousin: {
      n: 'ولد عمك',
      c: 'green',
      cut: 2
    },
    aunt: {
      n: 'عمتك',
      c: 'orange',
      cut: 3
    }
  };
  const MSG1 = [['abu', 'شباب السهم الفلاني بيطير بكرة!! 🚀🚀'], ['cousin', 'أنا دخلت بكل فلوسي 😎'], ['abu', 'ولد خويي ربح الضعف بأسبوع'], ['aunt', 'الله يرزقكم 🤲']];
  const MSG2 = [['abu', 'شباب… السهم نزل 30% 😅'], ['cousin', '😶']];
  const WARN = ['ارتفع 60% في أسبوع بدون خبر رسمي', 'ما حققت أرباح آخر سنتين', 'أغلب الكلام عنه في القروبات، مو في الإعلانات الرسمية'];
  const tag = /*#__PURE__*/React.createElement(GameTag, {
    n: 2,
    icon: "\uD83D\uDCF1",
    name: "\u0642\u0631\u0648\u0628 \u0627\u0644\u0639\u064A\u0644\u0629"
  });
  function Bubble({
    who,
    text,
    i,
    delay
  }) {
    const w = WHO[who];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        alignSelf: 'flex-start',
        maxWidth: '90%',
        animation: 'bs-deal .45s cubic-bezier(.2,.8,.2,1) both',
        animationDelay: delay + 'ms'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: w.c,
      cut: w.cut,
      lift: true,
      tilt: [-1, 1, -.5, .5][i % 4],
      style: {
        padding: '10px 20px 12px'
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        display: 'block',
        font: '700 13px/1.5 var(--f-sans)'
      }
    }, w.n), /*#__PURE__*/React.createElement("span", {
      style: {
        font: '500 18px/1.6 var(--f-text)'
      }
    }, text)));
  }
  function Chat({
    week = false
  }) {
    return /*#__PURE__*/React.createElement("section", {
      "aria-label": "\u0645\u062D\u0627\u062F\u062B\u0629 \u0627\u0644\u0639\u064A\u0644\u0629",
      style: {
        width: 420,
        flex: 'none',
        display: 'flex',
        flexDirection: 'column',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "ink",
      cut: 4,
      lift: true,
      tilt: -1,
      style: {
        padding: '12px 22px',
        font: '700 20px/1.3 var(--f-display)'
      }
    }, "\u0627\u0644\u0639\u064A\u0644\u0629 \uD83C\uDFE0"), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-caption)',
        color: 'var(--ink-muted)'
      }
    }, "4 \u0623\u0639\u0636\u0627\u0621")), /*#__PURE__*/React.createElement(Piece, {
      color: "faint",
      cut: 1,
      style: {
        padding: '20px 18px',
        display: 'flex',
        flexDirection: 'column',
        gap: 12
      }
    }, MSG1.map((m, i) => /*#__PURE__*/React.createElement(Bubble, {
      key: 'a' + i,
      who: m[0],
      text: m[1],
      i: i,
      delay: week ? 0 : 150 + i * 260
    })), week && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        alignSelf: 'center',
        margin: '4px 0'
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      color: "cream",
      lift: true
    }, "\u0628\u0639\u062F \u0623\u0633\u0628\u0648\u0639")), MSG2.map((m, i) => /*#__PURE__*/React.createElement(Bubble, {
      key: 'b' + i,
      who: m[0],
      text: m[1],
      i: i + 1,
      delay: 500 + i * 600
    })))));
  }
  const Layout = ({
    children,
    week
  }) => /*#__PURE__*/React.createElement("main", {
    style: {
      ...bsScreen,
      gap: 16
    }
  }, tag, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      gap: 56,
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Chat, {
    week: week
  }), /*#__PURE__*/React.createElement("section", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 26,
      alignItems: 'center',
      maxWidth: 640,
      minWidth: 0
    }
  }, children)));
  function FamilyPlay({
    go,
    put
  }) {
    return /*#__PURE__*/React.createElement(Layout, null, /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-headline)',
        margin: 0
      }
    }, "\u0648\u0634 \u0628\u062A\u0633\u0648\u064A\u061F"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 20
      }
    }, /*#__PURE__*/React.createElement(ChoiceCard, {
      i: 0,
      icon: "\uD83D\uDD25",
      label: "\u0623\u062F\u062E\u0644 \u0628\u0643\u0644 \u0641\u0644\u0648\u0633\u064A",
      cut: 1,
      tilt: -1.5,
      w: 180,
      h: 190,
      onClick: () => {
        put({
          familyChoice: 'all'
        });
        go('family-week');
      }
    }), /*#__PURE__*/React.createElement(ChoiceCard, {
      i: 1,
      icon: "\uD83E\uDD0F",
      label: "\u0623\u062F\u062E\u0644 \u0628\u062C\u0632\u0621 \u0635\u063A\u064A\u0631",
      cut: 3,
      tilt: 1,
      w: 180,
      h: 190,
      onClick: () => {
        put({
          familyChoice: 'part'
        });
        go('family-week');
      }
    }), /*#__PURE__*/React.createElement(ChoiceCard, {
      i: 2,
      icon: "\uD83D\uDD0D",
      label: "\u0623\u062A\u062D\u0642\u0642 \u0623\u0648\u0644",
      cut: 4,
      tilt: -.5,
      w: 180,
      h: 190,
      onClick: () => go('family-verify')
    })));
  }
  function FamilyVerify({
    go,
    put
  }) {
    const flip = useLater(350);
    const c = (k, i, ic, l, cut) => /*#__PURE__*/React.createElement(ChoiceCard, {
      key: k,
      i: i,
      icon: ic,
      label: l,
      cut: cut,
      w: 160,
      h: 120,
      onClick: () => {
        put({
          familyChoice: k
        });
        go('family-week');
      }
    });
    return /*#__PURE__*/React.createElement(Layout, null, /*#__PURE__*/React.createElement(Flip, {
      w: 480,
      h: 260,
      flipped: flip,
      color: "cream",
      backColor: "cream",
      front: /*#__PURE__*/React.createElement("span", {
        style: {
          font: 'var(--type-title)'
        }
      }, "\uD83D\uDD0D \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0633\u0647\u0645"),
      back: /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          flexDirection: 'column',
          gap: 10,
          width: '100%'
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          font: '700 16px/1.4 var(--f-sans)',
          textAlign: 'right'
        }
      }, "\u0644\u0642\u064A\u062A 3 \u0639\u0644\u0627\u0645\u0627\u062A \u062A\u062D\u0630\u064A\u0631:"), WARN.map((w, i) => /*#__PURE__*/React.createElement(Piece, {
        key: i,
        color: "orange",
        cut: i + 1,
        style: {
          padding: '9px 16px',
          font: '700 15px/1.45 var(--f-sans)',
          textAlign: 'right',
          animation: 'bs-in .35s ease both',
          animationDelay: 800 + i * 200 + 'ms'
        }
      }, "\u26A0 ", w)))
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 16
      }
    }, c('all', 0, '🔥', 'أدخل بكل فلوسي', 1), c('part', 1, '🤏', 'أدخل بجزء صغير', 3), c('none', 2, '✋', 'ما أدخل', 2)));
  }
  function FamilyWeek({
    go,
    S
  }) {
    const ch = S.familyChoice;
    return /*#__PURE__*/React.createElement(Layout, {
      week: true
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        animation: 'bs-drop .7s cubic-bezier(.3,1.3,.5,1) both'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "cream",
      cut: "torn",
      lift: true,
      tilt: -3,
      style: {
        padding: '38px 80px 32px',
        font: '900 clamp(48px,6vw,76px)/1.2 var(--f-display)'
      }
    }, "\u0628\u0639\u062F \u0623\u0633\u0628\u0648\u0639\u2026")), /*#__PURE__*/React.createElement(Chip, {
      color: ch === 'all' ? 'red' : 'faint'
    }, ch === 'all' ? 'أنت دخلت بكل فلوسك' : ch === 'part' ? 'أنت دخلت بجزء صغير' : 'أنت ما دخلت'), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go(ch === 'all' ? 'family-lose' : 'family-win')
    }, "\u0634\u0648\u0641 \u0627\u0644\u0646\u062A\u064A\u062C\u0629"));
  }
  function FamilyWin({
    go,
    S,
    onWin
  }) {
    const part = S.familyChoice === 'part',
      loss = Math.round(S.budget * .1 * .3);
    return /*#__PURE__*/React.createElement(Result, {
      id: "family",
      win: true,
      tag: tag,
      go: go,
      onWin: onWin,
      headline: "\u0643\u0641\u0648! \u0627\u0644\u0642\u0631\u0648\u0628 \u0645\u0648 \u0645\u0635\u062F\u0631 \u0627\u0633\u062A\u062B\u0645\u0627\u0631",
      lesson: "\u0644\u0627 \u062A\u0633\u062A\u062B\u0645\u0631 \u0628\u0646\u0627\u0621\u064B \u0639\u0644\u0649 \u0625\u0634\u0627\u0639\u0629.",
      scene: /*#__PURE__*/React.createElement(Piece, {
        color: "green",
        cut: 3,
        lift: true,
        tilt: -2,
        style: {
          padding: '34px 44px',
          font: '900 32px/1.4 var(--f-display)',
          textAlign: 'center',
          maxWidth: 340,
          fontVariantNumeric: 'tabular-nums'
        }
      }, part ? 'خسرت ' + bsFmt(loss) + ' بس، والباقي سليم' : 'فلوسك سليمة 100%')
    });
  }
  function FamilyLose({
    go,
    S,
    onWin
  }) {
    return /*#__PURE__*/React.createElement(Result, {
      id: "family",
      tag: tag,
      go: go,
      onWin: onWin,
      lesson: "\u0633\u0645\u0639\u062A \u0625\u0646 \u0627\u0644\u0633\u0647\u0645 \u0632\u064A\u0646\u061F \u0647\u0630\u064A \u0628\u0627\u0644\u0636\u0628\u0637 \u0627\u0644\u062C\u0645\u0644\u0629 \u0627\u0644\u0644\u064A \u0646\u0628\u064A\u0643 \u062A\u0646\u0633\u0627\u0647\u0627.",
      scene: /*#__PURE__*/React.createElement(Torn, {
        color: "red"
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          font: '900 34px/1.3 var(--f-display)',
          fontVariantNumeric: 'tabular-nums'
        }
      }, "\u062E\u0633\u0631\u062A ", bsFmt(S.budget * .3), " \u0631\u064A\u0627\u0644"))
    });
  }
  Object.assign(window, {
    FamilyPlay,
    FamilyVerify,
    FamilyWeek,
    FamilyWin,
    FamilyLose
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/baseer-app/FamilyGame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/baseer-app/Games.jsx
try { (() => {
(() => {
  const {
    Piece,
    Assistant,
    CoachBubble,
    StarRating,
    Button
  } = window.BaseerDesignSystem_f0524d;
  const bsCol = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center'
  };
  function useTween(target, ms = 900) {
    const [v, setV] = React.useState(target);
    const from = React.useRef(target);
    React.useEffect(() => {
      let raf, st;
      const a = from.current;
      const tick = ts => {
        if (!st) st = ts;
        const p = Math.min(1, (ts - st) / ms);
        const x = a + (target - a) * (1 - Math.pow(1 - p, 3));
        setV(x);
        from.current = x;
        if (p < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
      return () => cancelAnimationFrame(raf);
    }, [target]);
    return v;
  }
  function useLater(ms = 500) {
    const [on, setOn] = React.useState(false);
    React.useEffect(() => {
      const t = setTimeout(() => setOn(true), ms);
      return () => clearTimeout(t);
    }, []);
    return on;
  }
  function Flip({
    flipped,
    front,
    back,
    w = 220,
    h = 160,
    color = 'cream',
    backColor = 'blue',
    cut = 2,
    backCut = 3
  }) {
    const face = {
      position: 'absolute',
      inset: 0,
      backfaceVisibility: 'hidden',
      WebkitBackfaceVisibility: 'hidden'
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        width: w,
        height: h,
        perspective: 1000,
        flex: 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: '100%',
        height: '100%',
        transformStyle: 'preserve-3d',
        transition: 'transform .8s cubic-bezier(.3,1.3,.5,1)',
        transform: flipped ? 'rotateY(180deg)' : 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: face
    }, /*#__PURE__*/React.createElement(Piece, {
      color: color,
      cut: cut,
      lift: true,
      style: {
        width: '100%',
        height: '100%',
        ...bsCol,
        gap: 6,
        padding: 16
      }
    }, front)), /*#__PURE__*/React.createElement("div", {
      style: {
        ...face,
        transform: 'rotateY(180deg)'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: backColor,
      cut: backCut,
      lift: true,
      style: {
        width: '100%',
        height: '100%',
        ...bsCol,
        gap: 6,
        padding: 16
      }
    }, back))));
  }
  function Torn({
    color = 'red',
    w = 340,
    h = 150,
    children
  }) {
    const L = 'polygon(0 0,52% 0,47% 18%,54% 35%,46% 55%,53% 72%,48% 100%,0 100%)';
    const R = 'polygon(52% 0,100% 0,100% 100%,48% 100%,53% 72%,46% 55%,54% 35%,47% 18%)';
    const half = (cp, a) => /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        clipPath: cp,
        animation: a + ' .9s cubic-bezier(.3,1.2,.5,1) .6s both'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: color,
      cut: 2,
      style: {
        width: '100%',
        height: '100%',
        ...bsCol,
        padding: 16
      }
    }, children));
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: w,
        height: h,
        filter: 'var(--lift)'
      }
    }, half(L, 'bs-tearL'), half(R, 'bs-tearR'));
  }
  function TalkingOrb({
    text,
    big = false,
    hype = false,
    color = 'orange',
    speaker
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: big ? 44 : 20,
        alignItems: 'flex-end',
        direction: 'ltr',
        maxWidth: big ? 680 : 640
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 'none',
        transform: big ? 'scale(1.6)' : 'none',
        transformOrigin: 'left bottom'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        animation: hype ? 'bs-hype .45s ease-in-out infinite alternate' : 'none'
      }
    }, /*#__PURE__*/React.createElement(Assistant, {
      state: "speaking"
    }))), text && /*#__PURE__*/React.createElement("div", {
      key: text,
      dir: "rtl",
      style: {
        textAlign: 'right',
        marginBottom: big ? 70 : 30,
        transformOrigin: 'left bottom',
        animation: 'bs-pop .45s cubic-bezier(.3,1.4,.5,1) .3s both'
      }
    }, /*#__PURE__*/React.createElement(CoachBubble, {
      color: color,
      speaker: speaker
    }, text)));
  }
  const LENS = 'polygon(0% 50%,8% 38%,18% 27%,30% 18%,42% 13%,50% 12%,58% 13%,70% 18%,82% 27%,92% 38%,100% 50%,92% 62%,82% 73%,70% 82%,58% 87%,50% 88%,42% 87%,30% 82%,18% 73%,8% 62%)';
  function EyeOrb({
    alert = false
  }) {
    const s = alert ? 120 : 64,
      c = alert ? 'var(--red)' : 'var(--blue)';
    const dot = (k, bg) => /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: '50%',
        top: '50%',
        width: s * k,
        height: s * k,
        marginLeft: -s * k / 2,
        marginTop: -s * k / 2,
        background: bg,
        backgroundImage: 'var(--grain)',
        clipPath: 'var(--circle)'
      }
    });
    return /*#__PURE__*/React.createElement("div", {
      role: "img",
      "aria-label": alert ? 'مراقب المخاطر ينبهك' : 'مراقب المخاطر',
      style: {
        position: 'relative',
        width: s * 1.6,
        height: s,
        flex: 'none',
        filter: 'var(--lift)',
        animation: alert ? 'bs-shake .5s ease-in-out 3' : 'none'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        inset: 0,
        background: c,
        backgroundImage: 'var(--grain)',
        clipPath: LENS
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        inset: '15% 11%',
        background: 'var(--cream)',
        clipPath: LENS
      }
    }), dot(.54, c), dot(.24, 'var(--ink)'));
  }
  function GameTag({
    n,
    icon,
    name
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        alignSelf: 'flex-start'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "faint",
      cut: 2,
      style: {
        padding: '8px 18px',
        font: '700 15px/1.4 var(--f-sans)',
        display: 'inline-flex',
        gap: 8,
        whiteSpace: 'nowrap',
        flex: 'none'
      }
    }, /*#__PURE__*/React.createElement("span", null, "\u0627\u0644\u0644\u0639\u0628\u0629 ", n), /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true"
    }, "\xB7"), /*#__PURE__*/React.createElement("span", null, name, " ", icon)));
  }
  function ChoiceCard({
    icon,
    label,
    sub,
    on,
    onClick,
    cut = 2,
    tilt = 0,
    w = 200,
    h = 170,
    i = 0,
    children
  }) {
    const [hv, setHv] = React.useState(false);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        animation: 'bs-deal .5s cubic-bezier(.2,.8,.2,1) both',
        animationDelay: i * 90 + 'ms'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      as: "button",
      type: "button",
      "aria-pressed": on ? 'true' : 'false',
      onClick: onClick,
      onMouseEnter: () => setHv(true),
      onMouseLeave: () => setHv(false),
      color: on ? 'blue' : 'cream',
      cut: cut,
      lift: true,
      tilt: on ? -2 : tilt,
      style: {
        border: 0,
        background: 'none',
        cursor: 'pointer',
        width: w,
        minHeight: h,
        padding: '18px 16px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
        textAlign: 'center',
        transition: 'transform .15s',
        transform: hv && !on ? 'scale(1.04)' : undefined
      }
    }, icon && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 40,
        lineHeight: 1
      }
    }, icon), children, /*#__PURE__*/React.createElement("span", {
      style: {
        font: '700 19px/1.4 var(--f-sans)'
      }
    }, label), sub && /*#__PURE__*/React.createElement("span", {
      style: {
        font: '500 14px/1.4 var(--f-sans)',
        opacity: .85
      }
    }, sub)));
  }
  const PLAY = {
    d27: 'd27-play',
    family: 'family-play',
    team: 'team-pick',
    coaster: 'coaster-play',
    ice: 'ice-play'
  };
  function Result({
    id,
    win,
    tag,
    headline,
    lesson,
    scene,
    go,
    onWin
  }) {
    React.useEffect(() => {
      if (win) onWin(id);
    }, []);
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        gap: 20
      }
    }, tag, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: 'flex',
        gap: '40px 64px',
        alignItems: 'center',
        justifyContent: 'center',
        flexWrap: 'wrap'
      }
    }, scene && /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 'none',
        animation: 'bs-deal .6s cubic-bezier(.2,.8,.2,1) both'
      }
    }, scene), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 24,
        alignItems: 'flex-start',
        maxWidth: 600,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 20,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement(StarRating, {
      value: win ? 1 : 0,
      max: 1,
      size: 84,
      animate: true,
      delay: 250,
      label: win ? 'كسبت نجمة' : 'ما كسبت نجمة'
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-label)',
        color: 'var(--ink-muted)'
      }
    }, win ? 'نجحت · +1 نجمة' : 'ما نجحت هالمرة'), headline && /*#__PURE__*/React.createElement("h1", {
      style: {
        font: '900 clamp(30px,3.4vw,42px)/1.35 var(--f-display)',
        margin: 0,
        textWrap: 'balance'
      }
    }, headline))), /*#__PURE__*/React.createElement(TalkingOrb, {
      text: lesson
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 16,
        flexWrap: 'wrap'
      }
    }, win ? /*#__PURE__*/React.createElement(Button, {
      onClick: () => go('journey', {
        fly: id
      })
    }, "\u0627\u0631\u062C\u0639 \u0644\u0644\u0631\u062D\u0644\u0629") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      onClick: () => go(PLAY[id])
    }, "\u062C\u0631\u0651\u0628 \u0645\u0631\u0629 \u062B\u0627\u0646\u064A\u0629"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => go('journey')
    }, "\u0627\u0631\u062C\u0639 \u0644\u0644\u0631\u062D\u0644\u0629"))))));
  }
  function Chip({
    color = 'faint',
    children,
    tilt = 0,
    cut = 2,
    big = false,
    lift = false
  }) {
    return /*#__PURE__*/React.createElement(Piece, {
      as: "span",
      color: color,
      cut: cut,
      tilt: tilt,
      lift: lift,
      style: {
        display: 'inline-flex',
        padding: big ? '12px 26px' : '6px 14px',
        font: (big ? '700 22px' : '700 15px') + '/1.4 var(--f-sans)',
        whiteSpace: 'nowrap'
      }
    }, /*#__PURE__*/React.createElement("span", null, children));
  }
  Object.assign(window, {
    bsCol,
    useTween,
    useLater,
    Flip,
    Torn,
    TalkingOrb,
    EyeOrb,
    GameTag,
    ChoiceCard,
    Result,
    Chip
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/baseer-app/Games.jsx", error: String((e && e.message) || e) }); }

// ui_kits/baseer-app/Ice.jsx
try { (() => {
(() => {
  const {
    Piece,
    Button
  } = window.BaseerDesignSystem_f0524d;
  const tag = /*#__PURE__*/React.createElement(GameTag, {
    n: 5,
    icon: "\uD83C\uDF66",
    name: "\u0622\u064A\u0633\u0643\u0631\u064A\u0645 \u0627\u0644\u0635\u064A\u0641"
  });
  const DRIP = 'polygon(0 0,100% 0,100% 72%,86% 90%,50% 100%,14% 90%,0 72%)';
  function IceCream({
    s = 1,
    melt = false
  }) {
    const W = 170 * s,
      H = 270 * s;
    const disc = (c, size, bottom, dx = 0) => /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: W / 2 - size / 2 + dx,
        bottom,
        width: size,
        height: size,
        background: c,
        backgroundImage: 'var(--grain)',
        clipPath: 'var(--circle)'
      }
    });
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: W,
        height: H,
        flex: 'none',
        filter: 'var(--lift)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: W / 2 - 50 * s,
        bottom: 0,
        width: 100 * s,
        height: 150 * s,
        background: 'var(--orange)',
        backgroundImage: 'var(--grain)',
        clipPath: 'polygon(0 0,100% 0,52% 100%,48% 100%)'
      }
    }), disc('var(--green)', 118 * s, 118 * s), disc('var(--red)', 100 * s, 180 * s, 6 * s), melt && [[-38, 120, 'var(--green)'], [30, 128, 'var(--green)'], [-6, 190, 'var(--red)']].map(([dx, b, c], i) => /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        position: 'absolute',
        left: W / 2 + dx * s - 8 * s,
        bottom: (b - 44) * s,
        width: 16 * s,
        height: 50 * s,
        background: c,
        clipPath: DRIP,
        transformOrigin: 'top',
        animation: 'bs-melt ' + (1.6 + i * .4) + 's ease-in-out infinite alternate'
      }
    })));
  }
  function Sun() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: 280,
        height: 280,
        flex: 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      "aria-hidden": "true",
      style: {
        position: 'absolute',
        inset: 0,
        animation: 'bs-spin 40s linear infinite'
      }
    }, [...Array(12)].map((_, i) => /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        position: 'absolute',
        left: '50%',
        top: '50%',
        width: 26,
        height: 44,
        marginLeft: -13,
        marginTop: -22,
        background: 'var(--orange)',
        clipPath: 'polygon(50% 0,100% 100%,0 100%)',
        transform: 'rotate(' + i * 30 + 'deg) translateY(-122px)'
      }
    }))), /*#__PURE__*/React.createElement(Piece, {
      color: "orange",
      cut: "circle",
      lift: true,
      style: {
        position: 'absolute',
        inset: 40,
        ...bsCol,
        gap: 4
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: '900 36px/1.2 var(--f-display)'
      }
    }, "\u0627\u0644\u062A\u0636\u062E\u0645"), /*#__PURE__*/React.createElement("span", {
      style: {
        font: '700 20px/1 var(--f-sans)',
        direction: 'rtl'
      }
    }, "\u0627\u0644\u0631\u064A\u0627\u0636 47\xB0")));
  }
  function Timer() {
    const [t, setT] = React.useState(10);
    React.useEffect(() => {
      const id = setInterval(() => setT(x => x > 0 ? x - 1 : 0), 1000);
      return () => clearInterval(id);
    }, []);
    return /*#__PURE__*/React.createElement(Piece, {
      color: "ink",
      cut: "circle",
      lift: true,
      style: {
        width: 120,
        height: 120,
        ...bsCol,
        flex: 'none'
      },
      "aria-live": "polite"
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: '900 48px/1 var(--f-display)',
        fontVariantNumeric: 'tabular-nums'
      }
    }, t), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-caption)'
      }
    }, "\u062B\u0648\u0627\u0646\u064A"));
  }
  function Puddle() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: 300,
        height: 150,
        flex: 'none',
        filter: 'var(--lift)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 0,
        height: 60,
        background: 'var(--green)',
        backgroundImage: 'var(--grain)',
        clipPath: 'polygon(4% 60%,14% 22%,32% 8%,52% 18%,70% 4%,90% 20%,99% 55%,88% 90%,60% 100%,30% 94%,8% 88%)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 70,
        right: 90,
        bottom: 18,
        height: 36,
        background: 'var(--red)',
        backgroundImage: 'var(--grain)',
        clipPath: 'polygon(6% 50%,20% 10%,50% 0,80% 12%,96% 46%,80% 90%,40% 100%,10% 86%)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        right: 6,
        bottom: 30,
        width: 80,
        height: 118,
        background: 'var(--orange)',
        backgroundImage: 'var(--grain)',
        clipPath: 'polygon(0 0,100% 0,52% 100%,48% 100%)',
        transform: 'rotate(-104deg)'
      }
    }));
  }
  function Freezer() {
    return /*#__PURE__*/React.createElement(Piece, {
      color: "blue",
      cut: 1,
      lift: true,
      style: {
        width: 250,
        height: 340,
        flex: 'none',
        padding: 18
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "cream",
      cut: 2,
      style: {
        width: '100%',
        height: '100%',
        display: 'grid',
        placeItems: 'end center',
        paddingBottom: 14
      }
    }, /*#__PURE__*/React.createElement(IceCream, {
      s: .9
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: '40%',
        left: 6,
        width: 8,
        height: 70,
        background: 'var(--ink)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -16,
        right: -14,
        zIndex: 2
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      color: "cream",
      lift: true,
      tilt: 6
    }, "\u2744\uFE0F \u0641\u0631\u064A\u0632\u0631")));
  }
  function IcePlay({
    go,
    put
  }) {
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        alignItems: 'center',
        gap: 20
      }
    }, tag, /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-headline)',
        margin: 0
      }
    }, "\u0627\u0644\u0635\u064A\u0641 \u0648\u0635\u0644\u2026 \u0648\u064A\u0646 \u0628\u062A\u062D\u0637 \u0622\u064A\u0633\u0643\u0631\u064A\u0645\u0643\u061F"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 56,
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(Sun, null), /*#__PURE__*/React.createElement(IceCream, {
      melt: true
    }), /*#__PURE__*/React.createElement(Timer, null)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 28
      }
    }, /*#__PURE__*/React.createElement(ChoiceCard, {
      i: 0,
      icon: "\u270B",
      label: "\u062E\u0644\u0647 \u0628\u064A\u062F\u064A",
      sub: "\u0641\u0644\u0648\u0633 \u0645\u0631\u0643\u0648\u0646\u0629",
      cut: 1,
      tilt: -1,
      w: 220,
      h: 150,
      onClick: () => {
        put({
          iceChoice: 'hand'
        });
        go('ice-timemachine');
      }
    }), /*#__PURE__*/React.createElement(ChoiceCard, {
      i: 1,
      icon: "\u2744\uFE0F",
      label: "\u062D\u0637\u0647 \u0628\u0627\u0644\u0641\u0631\u064A\u0632\u0631",
      sub: "\u0627\u0633\u062A\u062B\u0645\u0627\u0631",
      cut: 3,
      tilt: 1,
      w: 220,
      h: 150,
      onClick: () => {
        put({
          iceChoice: 'freezer'
        });
        go('ice-timemachine');
      }
    })));
  }
  function IceTime({
    go,
    S
  }) {
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsCenter,
        gap: 34
      }
    }, tag, /*#__PURE__*/React.createElement("div", {
      style: {
        animation: 'bs-drop .7s cubic-bezier(.3,1.3,.5,1) both'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "cream",
      cut: "torn",
      lift: true,
      tilt: -2,
      style: {
        padding: '28px 64px 22px',
        font: '900 clamp(40px,5vw,60px)/1.3 var(--f-display)',
        whiteSpace: 'nowrap'
      }
    }, "\u0628\u0639\u062F 5 \u0633\u0646\u064A\u0646\u2026")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 110,
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginTop: 28
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        ...bsCol,
        gap: 16,
        animation: 'bs-in .5s ease .6s both'
      }
    }, /*#__PURE__*/React.createElement(Puddle, null), /*#__PURE__*/React.createElement(Chip, {
      big: true
    }, "\u270B \u0627\u0644\u0645\u0631\u0643\u0648\u0646")), /*#__PURE__*/React.createElement("div", {
      style: {
        ...bsCol,
        gap: 16,
        animation: 'bs-in .5s ease .9s both'
      }
    }, /*#__PURE__*/React.createElement(Freezer, null), /*#__PURE__*/React.createElement(Chip, {
      big: true,
      color: "blue"
    }, "\u2744\uFE0F \u0627\u0644\u0645\u0633\u062A\u062B\u0645\u0631"))), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go(S.iceChoice === 'freezer' ? 'ice-win' : 'ice-lose')
    }, "\u0634\u0648\u0641 \u0627\u0644\u0646\u062A\u064A\u062C\u0629"));
  }
  function IceWin({
    go,
    onWin
  }) {
    return /*#__PURE__*/React.createElement(Result, {
      id: "ice",
      win: true,
      tag: tag,
      go: go,
      onWin: onWin,
      headline: "\u0641\u0644\u0648\u0633\u0643 \u0645\u0627 \u0630\u0627\u0628\u062A!",
      lesson: "\u0627\u0644\u0641\u0644\u0648\u0633 \u0627\u0644\u0645\u0631\u0643\u0648\u0646\u0629 \u062A\u062E\u0633\u0631 \u0642\u064A\u0645\u062A\u0647\u0627 \u0628\u0633\u0628\u0628 \u0627\u0644\u062A\u0636\u062E\u0645.",
      scene: /*#__PURE__*/React.createElement(Freezer, null)
    });
  }
  function IceLose({
    go,
    onWin
  }) {
    return /*#__PURE__*/React.createElement(Result, {
      id: "ice",
      tag: tag,
      go: go,
      onWin: onWin,
      lesson: "\u0641\u0644\u0648\u0633\u0643 \u0627\u0644\u0645\u0631\u0643\u0648\u0646\u0629 \u0645\u0648 \u0622\u0645\u0646\u0629\u2026 \u0647\u064A \u0642\u0627\u0639\u062F\u0629 \u062A\u0630\u0648\u0628.",
      scene: /*#__PURE__*/React.createElement(Puddle, null)
    });
  }
  Object.assign(window, {
    IcePlay,
    IceTime,
    IceWin,
    IceLose
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/baseer-app/Ice.jsx", error: String((e && e.message) || e) }); }

// ui_kits/baseer-app/Journey.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
(() => {
  const {
    StarRating,
    Piece
  } = window.BaseerDesignSystem_f0524d;
  const G5 = ['d27', 'family', 'team', 'coaster', 'ice'];
  const ST = [{
    id: 'd27',
    ic: '💸',
    n: 'يوم 27'
  }, {
    id: 'family',
    ic: '📱',
    n: 'قروب العيلة'
  }, {
    id: 'team',
    ic: '⚽',
    n: 'النجم ولا الفريق؟'
  }, {
    id: 'coaster',
    ic: '🎢',
    n: 'القطار الأفعواني'
  }, {
    id: 'ice',
    ic: '🍦',
    n: 'آيسكريم الصيف'
  }, {
    id: 'arena',
    ic: '⚡',
    n: 'ساحة التذبذب'
  }, {
    id: 'grad',
    ic: '🎓',
    n: 'التخرج'
  }];
  const TOP = [30, 160, 30, 160, 30, 160, 30];
  const X = i => i * (100 / 7) + 100 / 14;
  const DEST = {
    d27: 'd27-play',
    family: 'family-play',
    team: 'team-pick',
    coaster: 'coaster-play',
    ice: 'ice-play',
    arena: 'arena-calm',
    grad: 'grad'
  };
  function JourneyScreen({
    go,
    S
  }) {
    const won = G5.filter(x => S.won.includes(x)),
      cur = G5.find(x => !won.includes(x));
    const open = won.length >= 5 || S.level === 'pro';
    const status = id => G5.includes(id) ? won.includes(id) ? 'passed' : id === cur ? 'current' : 'locked' : open ? 'current' : 'locked';
    const tokenAt = ST.findIndex(s => s.id === (cur || 'arena'));
    const pts = ST.map((_, i) => 100 - X(i) + ',' + (TOP[i] + 56)).join(' ');
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        gap: 30,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("section", {
      style: {
        ...bsCol,
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(StarRating, {
      value: won.length,
      size: 64,
      animate: true,
      delay: 300,
      step: 180
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        font: '700 22px/1.4 var(--f-display)',
        fontVariantNumeric: 'tabular-nums',
        whiteSpace: 'nowrap'
      }
    }, "\u0646\u062C\u0648\u0645\u0643: ", won.length, " \u0645\u0646 5"), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-label)',
        color: 'var(--ink-muted)'
      }
    }, "\u0627\u0644\u0646\u062C\u0645\u0629 \u062A\u0642\u064A\u0633 \u062C\u0648\u062F\u0629 \u0627\u0644\u0642\u0631\u0627\u0631\u060C \u0645\u0648 \u0627\u0644\u0631\u0628\u062D.")), /*#__PURE__*/React.createElement("section", {
      "aria-label": "\u062E\u0631\u064A\u0637\u0629 \u0627\u0644\u0631\u062D\u0644\u0629",
      style: {
        position: 'relative',
        height: 300,
        width: '100%',
        maxWidth: 1180
      }
    }, /*#__PURE__*/React.createElement("svg", {
      viewBox: "0 0 100 300",
      preserveAspectRatio: "none",
      "aria-hidden": "true",
      style: {
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement("polyline", {
      points: pts,
      fill: "none",
      stroke: "var(--line-strong)",
      strokeWidth: "2",
      strokeDasharray: "8 8",
      vectorEffect: "non-scaling-stroke"
    })), ST.map((st, i) => {
      const s = status(st.id),
        click = s !== 'locked',
        special = !G5.includes(st.id);
      const color = s === 'passed' ? 'green' : s === 'current' ? special ? 'orange' : 'cream' : '#E5E2D7';
      const P = {
        color,
        cut: i % 4 + 1,
        lift: s !== 'locked',
        tilt: [-1.5, 1, -1, 1.5, -1, 1, -1.5][i],
        style: {
          width: 142,
          minHeight: 112,
          padding: '14px 10px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 8,
          textAlign: 'center',
          border: 0,
          background: 'none',
          cursor: click ? 'pointer' : 'default'
        }
      };
      const inner = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 34,
          lineHeight: 1,
          opacity: s === 'locked' ? .5 : 1
        }
      }, st.ic), /*#__PURE__*/React.createElement("span", {
        style: {
          font: (s === 'locked' ? '500' : '700') + ' 16px/1.35 var(--f-sans)',
          color: s === 'locked' ? 'var(--ink-muted)' : 'var(--ink)'
        }
      }, st.n));
      return /*#__PURE__*/React.createElement("div", {
        key: st.id,
        style: {
          position: 'absolute',
          right: X(i) + '%',
          top: TOP[i],
          transform: 'translateX(50%)',
          zIndex: 1
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          animation: s === 'current' ? 'bs-pulse 1.8s ease-in-out infinite' : 'none'
        }
      }, click ? /*#__PURE__*/React.createElement(Piece, _extends({
        as: "button",
        type: "button",
        onClick: () => go(DEST[st.id])
      }, P), inner) : /*#__PURE__*/React.createElement(Piece, P, inner)), st.id === 'arena' && !open && /*#__PURE__*/React.createElement(Piece, {
        color: "ink",
        cut: 2,
        lift: true,
        tilt: -3,
        style: {
          position: 'absolute',
          bottom: -20,
          insetInline: -8,
          padding: '5px 8px',
          font: '700 12px/1.4 var(--f-sans)',
          textAlign: 'center'
        }
      }, "\u062A\u0646\u0641\u062A\u062D \u0639\u0646\u062F 5 \u0646\u062C\u0648\u0645"), s === 'passed' && /*#__PURE__*/React.createElement("div", {
        style: {
          position: 'absolute',
          top: -24,
          left: -16,
          animation: S.fly === st.id ? 'bs-fly 1.3s cubic-bezier(.3,.9,.4,1.15) .3s both' : 'none'
        }
      }, /*#__PURE__*/React.createElement(StarRating, {
        value: 1,
        max: 1,
        size: 44,
        label: "\u0645\u062C\u062A\u0627\u0632\u0629"
      })), i === tokenAt && /*#__PURE__*/React.createElement("div", {
        "aria-label": "\u0623\u0646\u062A \u0647\u0646\u0627",
        style: {
          position: 'absolute',
          top: -50,
          left: '50%',
          marginLeft: -20,
          animation: 'bs-float 1s ease-in-out infinite alternate'
        }
      }, /*#__PURE__*/React.createElement(Piece, {
        color: "orange",
        cut: "circle",
        lift: true,
        style: {
          width: 40,
          height: 40
        }
      })));
    })));
  }
  Object.assign(window, {
    JourneyScreen
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/baseer-app/Journey.jsx", error: String((e && e.message) || e) }); }

// ui_kits/baseer-app/Onboarding.jsx
try { (() => {
(() => {
  const {
    Button,
    CollageBand,
    AmountField,
    ObligationField,
    Figure,
    Piece
  } = window.BaseerDesignSystem_f0524d;
  const bsDigits = v => String(v).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[^0-9]/g, '');
  const bsFmt = n => Math.round(n).toLocaleString('en-US');
  const bsNum = v => {
    const d = bsDigits(v);
    return d ? Number(d) : 0;
  };
  const bsInput = v => {
    const d = bsDigits(v);
    return d ? Number(d).toLocaleString('en-US') : '';
  };
  const bsScreen = {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    paddingInline: 'var(--gutter-x)',
    paddingBlock: '8px 100px',
    animation: 'bs-in .45s ease both'
  };
  const bsCenter = {
    ...bsScreen,
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    gap: 40
  };
  function BackLink({
    onClick,
    children = 'رجوع'
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        alignSelf: 'flex-start',
        marginBottom: -16
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "quiet",
      onClick: onClick
    }, children));
  }
  function WelcomeScreen({
    go
  }) {
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsCenter,
        position: 'relative',
        paddingBottom: 'clamp(190px,30vh,320px)'
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-hero)',
        margin: 0,
        textWrap: 'balance',
        maxWidth: '16ch'
      }
    }, "\u0641\u0644\u0648\u0633\u0643 \u0645\u0648\u062C\u0648\u062F\u0629\u2026 \u0628\u0633 \u0647\u0644 \u0627\u0646\u062A \u0645\u0633\u062A\u063A\u0644\u0647\u0627\u061F"), /*#__PURE__*/React.createElement("p", {
      style: {
        font: 'var(--type-lead)',
        color: 'var(--ink-muted)',
        margin: 0,
        maxWidth: '40ch'
      }
    }, "\u062C\u0631\u0651\u0628 \u0627\u0644\u0627\u0633\u062A\u062B\u0645\u0627\u0631 \u0628\u0645\u062D\u0641\u0638\u0629 \u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629 \u0645\u0628\u0646\u064A\u0629 \u0639\u0644\u0649 \u0631\u0627\u062A\u0628\u0643 \u0627\u0644\u062D\u0642\u064A\u0642\u064A."), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go('salary')
    }, "\u0627\u0628\u062F\u0623 \u0631\u062D\u0644\u062A\u0643"), /*#__PURE__*/React.createElement(CollageBand, null));
  }
  function SalaryScreen({
    go,
    data,
    set
  }) {
    const f = k => v => set({
      ...data,
      [k]: bsInput(v)
    });
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        gap: 56,
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 20,
        maxWidth: 620,
        width: '100%'
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-headline)',
        margin: 0
      }
    }, "\u0643\u0645 \u0631\u0627\u062A\u0628\u0643\u061F"), /*#__PURE__*/React.createElement(AmountField, {
      value: data.salary,
      onChange: f('salary'),
      placeholder: "\u0645\u062B\u0644\u0627\u064B 8,000",
      ariaLabel: "\u0643\u0645 \u0631\u0627\u062A\u0628\u0643\u061F"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 22
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        font: 'var(--type-title)',
        margin: 0
      }
    }, "\u0648\u0627\u0644\u062A\u0632\u0627\u0645\u0627\u062A\u0643 \u0643\u0644 \u0634\u0647\u0631\u061F"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexWrap: 'wrap',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement(ObligationField, {
      label: "\u0625\u064A\u062C\u0627\u0631",
      value: data.rent,
      onChange: f('rent'),
      cut: 2,
      tilt: 1
    }), /*#__PURE__*/React.createElement(ObligationField, {
      label: "\u0623\u0642\u0633\u0627\u0637",
      value: data.loan,
      onChange: f('loan'),
      cut: 3,
      tilt: -1.5
    }), /*#__PURE__*/React.createElement(ObligationField, {
      label: "\u0645\u0635\u0627\u0631\u064A\u0641 \u0627\u062E\u0631\u0649",
      value: data.exp,
      onChange: f('exp'),
      cut: 4
    }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
      disabled: !bsNum(data.salary),
      onClick: () => go('margin')
    }, "\u0627\u062D\u0633\u0628 \u0647\u0627\u0645\u0634\u064A")));
  }
  function MarginScreen({
    go,
    data,
    pct,
    setPct,
    setSpeak
  }) {
    const sal = bsNum(data.salary),
      ob = bsNum(data.rent) + bsNum(data.loan) + bsNum(data.exp);
    const m = sal - ob,
      inv = Math.round(m * pct / 100),
      rest = m - inv,
      warn = m > 0 && pct > 75;
    React.useEffect(() => {
      setSpeak(warn);
      return () => setSpeak(false);
    }, [warn]);
    const calc = /*#__PURE__*/React.createElement("p", {
      style: {
        font: 'var(--type-caption)',
        color: 'var(--ink-muted)',
        margin: 0,
        fontVariantNumeric: 'tabular-nums'
      }
    }, bsFmt(sal), " \u0631\u0627\u062A\u0628 \u2212 ", bsFmt(ob), " \u0627\u0644\u062A\u0632\u0627\u0645\u0627\u062A");
    if (m <= 0) return /*#__PURE__*/React.createElement("main", {
      style: bsCenter
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "cream",
      cut: 3,
      lift: true,
      tilt: -1,
      style: {
        padding: '40px 48px',
        maxWidth: 640
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-title)',
        fontSize: 32,
        margin: 0,
        textWrap: 'balance'
      }
    }, "\u0627\u0644\u062A\u0632\u0627\u0645\u0627\u062A\u0643 \u0623\u0643\u0628\u0631 \u0645\u0646 \u0631\u0627\u062A\u0628\u0643 \u062D\u0627\u0644\u064A\u0627\u064B\u060C \u062E\u0644\u0646\u0627 \u0646\u0628\u062F\u0623 \u0628\u0641\u0647\u0645 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629 \u0623\u0648\u0644")), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go('salary')
    }, "\u0631\u062C\u0648\u0639"), calc);
    const chips = [25, 50, 75];
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsCenter,
        gap: 36
      }
    }, /*#__PURE__*/React.createElement(Figure, {
      label: "\u0647\u0627\u0645\u0634\u0643 \u0627\u0644\u062D\u0631",
      value: bsFmt(m)
    }), /*#__PURE__*/React.createElement(Button, {
      disabled: inv < 1,
      onClick: () => go('quiz-1', {
        budget: inv
      })
    }, "\u0627\u0628\u062F\u0623 \u0628\u0640", bsFmt(inv), " \u0631\u064A\u0627\u0644 \u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 18
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 14,
        alignItems: 'flex-start'
      },
      role: "radiogroup",
      "aria-label": "\u0646\u0633\u0628\u0629 \u0627\u0644\u0627\u0633\u062A\u062B\u0645\u0627\u0631"
    }, chips.map((c, i) => {
      const on = pct === c;
      return /*#__PURE__*/React.createElement("div", {
        key: c,
        style: {
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Piece, {
        as: "button",
        type: "button",
        role: "radio",
        "aria-checked": on,
        onClick: () => setPct(c),
        color: on ? 'blue' : 'faint',
        cut: [2, 3, 4][i],
        lift: on,
        tilt: on ? -2 : 0,
        style: {
          border: 0,
          background: 'none',
          cursor: 'pointer',
          padding: '10px 22px',
          font: '700 18px/1.4 var(--f-sans)',
          fontVariantNumeric: 'tabular-nums',
          transition: 'transform .2s'
        }
      }, c, "%"), c === 50 && /*#__PURE__*/React.createElement("span", {
        style: {
          font: 'var(--type-caption)',
          color: 'var(--ink-muted)'
        }
      }, "\u0645\u0642\u062A\u0631\u062D"));
    })), /*#__PURE__*/React.createElement("label", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        font: 'var(--type-label)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--ink-muted)'
      }
    }, "\u0646\u0633\u0628\u0629 \u0645\u062E\u0635\u0635\u0629"), /*#__PURE__*/React.createElement("input", {
      type: "range",
      min: "5",
      max: "100",
      step: "5",
      value: pct,
      onChange: e => setPct(+e.target.value),
      style: {
        width: 240,
        accentColor: 'var(--blue)'
      }
    }), /*#__PURE__*/React.createElement("b", {
      style: {
        minWidth: '4ch',
        fontVariantNumeric: 'tabular-nums'
      }
    }, pct, "%")), /*#__PURE__*/React.createElement("p", {
      style: {
        font: 'var(--type-body)',
        margin: 0,
        fontVariantNumeric: 'tabular-nums'
      }
    }, "\u0648\u0627\u0644\u0628\u0627\u0642\u064A ", bsFmt(rest), " \u0644\u0644\u0637\u0648\u0627\u0631\u0626"), warn && /*#__PURE__*/React.createElement(Piece, {
      color: "orange",
      cut: 3,
      lift: true,
      tilt: 1,
      style: {
        padding: '12px 22px',
        font: '700 15px/1.4 var(--f-sans)',
        animation: 'bs-pop .35s cubic-bezier(.2,.8,.2,1) both'
      }
    }, "\u0628\u0635\u064A\u0631: \u062A\u0623\u0643\u062F \u0625\u0646\u0643 \u0645\u062E\u0644\u064A \u0634\u064A \u0644\u0644\u0637\u0648\u0627\u0631\u0626")), calc);
  }
  Object.assign(window, {
    WelcomeScreen,
    SalaryScreen,
    MarginScreen,
    BackLink,
    bsFmt,
    bsNum,
    bsScreen,
    bsCenter
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/baseer-app/Onboarding.jsx", error: String((e && e.message) || e) }); }

// ui_kits/baseer-app/Quiz.jsx
try { (() => {
(() => {
  const {
    Piece,
    Button
  } = window.BaseerDesignSystem_f0524d;
  const Q = [{
    q: 'معك 750 ريال. وش الأخطر؟',
    a: ['كلها في سهم واحد', 'موزعة على صندوق'],
    ok: 0
  }, {
    q: 'سهم ارتفع 50% في أسبوع، وكل القروبات تتكلم عنه. وش تسوي؟',
    a: ['أدخل بسرعة', 'أتحقق أول', 'أدخل بكل فلوسي'],
    ok: 1
  }, {
    q: 'السوق نزل 15%. وش تسوي؟',
    a: ['أبيع كل شي', 'أراجع توزيعي وأصبر', 'أسحب وما أرجع'],
    ok: 1
  }];
  const CONF = ['شوي', 'متأكد', 'متأكد مرة'];
  function QuizQ({
    go,
    S,
    put,
    n
  }) {
    const q = Q[n],
      ans = S.quiz[n] || {};
    const setA = p => {
      const z = S.quiz.slice();
      z[n] = {
        ...ans,
        ...p
      };
      put({
        quiz: z
      });
    };
    const ready = ans.a != null && ans.c != null;
    const next = () => {
      if (n < 2) return go('quiz-' + (n + 2));
      const score = S.quiz.reduce((s, x, i) => s + (x.a === Q[i].ok ? 1 : 0), 0),
        conf = S.quiz.filter(x => x.c >= 1).length;
      const lvl = score === 3 && conf >= 2 ? 'pro' : 'beginner';
      go('quiz-' + lvl, {
        level: lvl
      });
    };
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        alignItems: 'center',
        gap: 26
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        ...bsCol,
        gap: 4
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: '700 22px/1.4 var(--f-display)'
      }
    }, "\u0642\u0628\u0644 \u0646\u0628\u062F\u0623\u2026 \u062E\u0644\u0646\u0627 \u0646\u0639\u0631\u0641 \u0648\u064A\u0646 \u0623\u0646\u062A"), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-label)',
        color: 'var(--ink-muted)'
      }
    }, "\u0645\u0627 \u0646\u062E\u0644\u064A\u0643 \u062A\u062E\u062A\u0627\u0631 \u0645\u0633\u062A\u0648\u0627\u0643. \u0627\u0644\u0643\u0648\u064A\u0632 \u064A\u062D\u062F\u062F\u0647 \uD83D\uDE09")), /*#__PURE__*/React.createElement("div", {
      "aria-label": 'السؤال ' + (n + 1) + ' من 3',
      style: {
        display: 'flex',
        gap: 8,
        alignItems: 'center'
      }
    }, [0, 1, 2].map(i => /*#__PURE__*/React.createElement(Piece, {
      key: i,
      color: i <= n ? 'blue' : 'faint',
      cut: i + 2,
      style: {
        width: 46,
        height: 14
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        font: '700 15px/1 var(--f-sans)',
        marginInlineStart: 6,
        fontVariantNumeric: 'tabular-nums'
      }
    }, n + 1, "/3")), /*#__PURE__*/React.createElement("h1", {
      key: n,
      style: {
        font: 'var(--type-headline)',
        margin: 0,
        maxWidth: '22ch',
        textAlign: 'center',
        textWrap: 'balance',
        animation: 'bs-in .45s ease both'
      }
    }, q.q), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 24,
        flexWrap: 'wrap',
        justifyContent: 'center'
      }
    }, q.a.map((a, i) => /*#__PURE__*/React.createElement(ChoiceCard, {
      key: n + '-' + i,
      i: i,
      label: a,
      on: ans.a === i,
      onClick: () => setA({
        a: i
      }),
      cut: [1, 3, 4][i],
      tilt: [-1, 1, -.5][i],
      w: 250,
      h: 130
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        ...bsCol,
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-label)'
      }
    }, "\u0643\u0645 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F\u061F"), /*#__PURE__*/React.createElement("div", {
      role: "radiogroup",
      "aria-label": "\u0643\u0645 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F\u061F",
      style: {
        display: 'flex',
        gap: 12
      }
    }, CONF.map((c, i) => {
      const on = ans.c === i;
      return /*#__PURE__*/React.createElement(Piece, {
        key: c,
        as: "button",
        type: "button",
        role: "radio",
        "aria-checked": on,
        onClick: () => setA({
          c: i
        }),
        color: on ? 'orange' : 'faint',
        cut: [2, 3, 4][i],
        lift: on,
        tilt: on ? -2 : 0,
        style: {
          border: 0,
          background: 'none',
          cursor: 'pointer',
          padding: '10px 22px',
          minHeight: 44,
          font: '700 16px/1.4 var(--f-sans)'
        }
      }, c);
    }))), /*#__PURE__*/React.createElement(Button, {
      disabled: !ready,
      onClick: next
    }, n < 2 ? 'التالي' : 'شوف مستواك'));
  }
  function QuizBeginner({
    go
  }) {
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsCenter,
        gap: 30
      }
    }, /*#__PURE__*/React.createElement(Chip, null, "\u0645\u0633\u062A\u0648\u0627\u0643: \u0645\u0628\u062A\u062F\u0626"), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-hero)',
        margin: 0
      }
    }, "\u0631\u062D\u0644\u062A\u0643 \u062A\u0628\u062F\u0623 \u062D\u0628\u0629 \u062D\u0628\u0629 \uD83C\uDF31"), /*#__PURE__*/React.createElement("p", {
      style: {
        font: 'var(--type-lead)',
        color: 'var(--ink-muted)',
        margin: 0
      }
    }, "5 \u0623\u0644\u0639\u0627\u0628 \u062A\u0639\u0644\u0645\u0643 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0627\u062A"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 20
      }
    }, ['💸', '📱', '⚽', '🎢', '🍦'].map((e, i) => /*#__PURE__*/React.createElement("div", {
      key: e,
      style: {
        animation: 'bs-deal .5s cubic-bezier(.2,.8,.2,1) both',
        animationDelay: 200 + i * 110 + 'ms'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "cream",
      cut: i % 4 + 1,
      lift: true,
      tilt: [-3, 2, -1, 3, -2][i],
      style: {
        width: 92,
        height: 92,
        display: 'grid',
        placeItems: 'center',
        fontSize: 40
      }
    }, e)))), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go('journey')
    }, "\u0627\u0628\u062F\u0623 \u0631\u062D\u0644\u062A\u0643"));
  }
  function QuizPro({
    go
  }) {
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsCenter,
        gap: 30
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      color: "green"
    }, "\u0645\u0633\u062A\u0648\u0627\u0643: \u0645\u062A\u0645\u0643\u0646"), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-hero)',
        margin: 0
      }
    }, "\u0648\u0627\u0636\u062D \u0625\u0646\u0643 \u0641\u0627\u0647\u0645 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0627\u062A \uD83D\uDCAA"), /*#__PURE__*/React.createElement("p", {
      style: {
        font: 'var(--type-lead)',
        color: 'var(--ink-muted)',
        margin: 0
      }
    }, "\u062A\u0642\u062F\u0631 \u062A\u062F\u062E\u0644 \u0633\u0627\u062D\u0629 \u0627\u0644\u062A\u0630\u0628\u0630\u0628 \u0645\u0628\u0627\u0634\u0631\u0629"), /*#__PURE__*/React.createElement("div", {
      style: {
        animation: 'bs-pop .5s cubic-bezier(.3,1.4,.5,1) .3s both'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "orange",
      cut: "circle",
      lift: true,
      tilt: -6,
      style: {
        width: 150,
        height: 150,
        display: 'grid',
        placeItems: 'center',
        fontSize: 72
      }
    }, "\u26A1")), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go('arena-calm')
    }, "\u0627\u062F\u062E\u0644 \u0627\u0644\u0633\u0627\u062D\u0629"));
  }
  Object.assign(window, {
    QuizQ,
    QuizBeginner,
    QuizPro
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/baseer-app/Quiz.jsx", error: String((e && e.message) || e) }); }

// ui_kits/baseer-app/TeamGame.jsx
try { (() => {
(() => {
  const {
    Piece,
    Button
  } = window.BaseerDesignSystem_f0524d;
  const POS = [[50, 90], [15, 70], [38, 74], [62, 74], [85, 70], [20, 46], [40, 50], [60, 50], [80, 46], [38, 20], [62, 20]];
  const COL = ['ink', 'blue', 'green', 'orange', 'red', 'blue', 'orange', 'green', 'red', 'orange', 'blue'];
  const tag = /*#__PURE__*/React.createElement(GameTag, {
    n: 3,
    icon: "\u26BD",
    name: "\u0627\u0644\u0646\u062C\u0645 \u0648\u0644\u0627 \u0627\u0644\u0641\u0631\u064A\u0642\u061F"
  });
  function Pitch({
    mode,
    injured,
    w = 520,
    h = 350
  }) {
    const k = w / 520,
      line = '2px solid rgba(242,239,227,.75)',
      fall = 'transform .9s cubic-bezier(.5,-0.4,.6,1.3)';
    return /*#__PURE__*/React.createElement(Piece, {
      color: "green",
      cut: 2,
      lift: true,
      style: {
        width: w,
        height: h,
        flex: 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 18 * k,
        border: line
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: 18 * k,
        right: 18 * k,
        top: '50%',
        borderTop: line
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: '50%',
        top: '50%',
        width: 90 * k,
        height: 90 * k,
        marginLeft: -45 * k,
        marginTop: -45 * k,
        border: line,
        borderRadius: '50%'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18 * k,
        width: 150 * k,
        height: 50 * k,
        marginLeft: -75 * k,
        border: line,
        borderTop: 0
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: '50%',
        bottom: 18 * k,
        width: 150 * k,
        height: 50 * k,
        marginLeft: -75 * k,
        border: line,
        borderBottom: 0
      }
    }), mode === 'star' && /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: '50%',
        top: '50%',
        transition: fall,
        transform: 'translate(-50%,-50%)' + (injured ? ' translateY(' + 60 * k + 'px) rotate(100deg)' : '')
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: "orange",
      cut: 3,
      lift: true,
      style: {
        width: 104 * k,
        height: 136 * k,
        display: 'grid',
        placeItems: 'center',
        font: '900 ' + Math.round(24 * k) + 'px/1 var(--f-display)'
      }
    }, "\u2B50")), mode === 'team' && POS.map((p, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        position: 'absolute',
        left: p[0] + '%',
        top: p[1] + '%',
        transition: fall,
        transform: 'translate(-50%,-50%)' + (injured && i === 9 ? ' translateY(' + 28 * k + 'px) rotate(90deg)' : '')
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: COL[i],
      cut: i % 4 + 1,
      lift: true,
      style: {
        width: 34 * k,
        height: 42 * k
      }
    }))), injured && /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: mode === 'star' ? '62%' : '30%',
        top: mode === 'star' ? '70%' : '28%',
        animation: 'bs-pop .4s cubic-bezier(.3,1.4,.5,1) .8s both'
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      color: "red",
      lift: true,
      tilt: -4
    }, "\u0625\u0635\u0627\u0628\u0629!")));
  }
  function TeamPick({
    go,
    S,
    put
  }) {
    const b = S.budget;
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        alignItems: 'center',
        gap: 30
      }
    }, tag, /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-headline)',
        margin: 0,
        fontVariantNumeric: 'tabular-nums'
      }
    }, "\u0639\u0646\u062F\u0643 ", bsFmt(b), " \u0631\u064A\u0627\u0644. \u062A\u0628\u0646\u064A \u0641\u0631\u064A\u0642\u0643\u061F"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 48,
        flexWrap: 'wrap',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(ChoiceCard, {
      i: 0,
      label: "\u2B50 \u0627\u0644\u0646\u062C\u0645",
      sub: 'لاعب واحد ياخذ كل الـ' + bsFmt(b),
      cut: 1,
      tilt: -1,
      w: 320,
      onClick: () => {
        put({
          teamPick: 'star'
        });
        go('team-injury');
      }
    }, /*#__PURE__*/React.createElement(Pitch, {
      mode: "star",
      w: 280,
      h: 188
    })), /*#__PURE__*/React.createElement(ChoiceCard, {
      i: 1,
      label: "\uD83D\uDC65 \u0627\u0644\u0641\u0631\u064A\u0642",
      sub: '11 لاعب، كل واحد ' + bsFmt(b / 11),
      cut: 3,
      tilt: 1,
      w: 320,
      onClick: () => {
        put({
          teamPick: 'team'
        });
        go('team-injury');
      }
    }, /*#__PURE__*/React.createElement(Pitch, {
      mode: "team",
      w: 280,
      h: 188
    }))));
  }
  function TeamInjury({
    go,
    S
  }) {
    const pick = S.teamPick || 'star',
      down = useLater(900),
      b = S.budget;
    const pct = pick === 'star' ? down ? 60 : 100 : down ? 95 : 100,
      val = useTween(b * pct / 100, 1100);
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsScreen,
        alignItems: 'center',
        gap: 22
      }
    }, tag, /*#__PURE__*/React.createElement("ol", {
      "aria-label": "\u0627\u0644\u0645\u0648\u0633\u0645",
      style: {
        display: 'flex',
        gap: 12,
        alignItems: 'center',
        listStyle: 'none',
        margin: 0,
        padding: 0
      }
    }, [1, 2, 3].map(m => /*#__PURE__*/React.createElement(React.Fragment, {
      key: m
    }, /*#__PURE__*/React.createElement(Piece, {
      as: "li",
      color: m < 2 ? 'green' : m === 2 ? 'blue' : 'faint',
      cut: m + 1,
      lift: m === 2,
      tilt: m === 2 ? -2 : 0,
      style: {
        padding: '10px 22px',
        font: '700 16px/1.4 var(--f-sans)',
        color: m === 2 ? 'var(--cream)' : m < 2 ? 'var(--ink)' : 'var(--ink-muted)'
      }
    }, "\u0627\u0644\u0645\u0628\u0627\u0631\u0627\u0629 ", m), m < 3 && /*#__PURE__*/React.createElement("li", {
      "aria-hidden": "true",
      style: {
        font: '500 20px/1 var(--f-sans)',
        color: 'var(--ink-muted)'
      }
    }, "\u2190")))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 56,
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        ...bsCol,
        gap: 6,
        minWidth: 220
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-label)',
        color: 'var(--ink-muted)'
      }
    }, "\u0642\u064A\u0645\u0629 ", pick === 'star' ? 'النجم' : 'الفريق'), /*#__PURE__*/React.createElement("span", {
      style: {
        font: '900 72px/1.1 var(--f-display)',
        fontVariantNumeric: 'tabular-nums',
        color: pct < 90 ? 'var(--red)' : 'var(--ink)'
      }
    }, bsFmt(val)), /*#__PURE__*/React.createElement("span", {
      style: {
        font: '700 22px/1 var(--f-sans)',
        direction: 'ltr',
        color: pct < 90 ? 'var(--red)' : 'var(--ink)'
      }
    }, pct < 100 ? '↓' + (100 - pct) + '%' : '—')), /*#__PURE__*/React.createElement(Pitch, {
      mode: pick,
      injured: down,
      w: 480,
      h: 320
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 40,
        alignItems: 'flex-end',
        alignSelf: 'stretch',
        justifyContent: 'space-between'
      }
    }, /*#__PURE__*/React.createElement(TalkingOrb, {
      big: true,
      hype: true,
      speaker: "\u0628\u0635\u064A\u0631 \xB7 \u0627\u0644\u0645\u0639\u0644\u0651\u0642",
      text: "\u0627\u0644\u062F\u0642\u064A\u0642\u0629 20\u2026 \u064A\u0627 \u0633\u0627\u062A\u0631! \u0625\u0635\u0627\u0628\u0629! \uD83D\uDE91"
    }), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go('team-reveal')
    }, "\u0643\u0645\u0651\u0644 \u0627\u0644\u0645\u0648\u0633\u0645")));
  }
  function TeamReveal({
    go,
    S
  }) {
    const flip = useLater(1500),
      gather = useLater(500);
    return /*#__PURE__*/React.createElement("main", {
      style: {
        ...bsCenter,
        gap: 34
      }
    }, tag, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 80,
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(Flip, {
      w: 240,
      h: 180,
      flipped: flip,
      color: "orange",
      backColor: "red",
      cut: 3,
      backCut: 2,
      front: /*#__PURE__*/React.createElement("span", {
        style: {
          font: '900 32px/1.2 var(--f-display)'
        }
      }, "\u2B50 \u0627\u0644\u0646\u062C\u0645"),
      back: /*#__PURE__*/React.createElement("span", {
        style: {
          font: '900 36px/1.2 var(--f-display)'
        }
      }, "\u0633\u0647\u0645 \u0648\u0627\u062D\u062F")
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: 260,
        height: 190
      }
    }, POS.map((p, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        position: 'absolute',
        left: gather ? '50%' : p[0] + '%',
        top: gather ? '50%' : p[1] + '%',
        transform: 'translate(-50%,-50%)' + (gather ? ' scale(.3)' : ''),
        opacity: gather ? 0 : 1,
        transition: 'all .7s cubic-bezier(.5,0,.3,1)',
        transitionDelay: i * 25 + 'ms'
      }
    }, /*#__PURE__*/React.createElement(Piece, {
      color: COL[i],
      cut: i % 4 + 1,
      lift: true,
      style: {
        width: 30,
        height: 36
      }
    }))), gather && /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: '5px 10px',
        animation: 'bs-pop .4s cubic-bezier(.3,1.4,.5,1) .5s both'
      }
    }, /*#__PURE__*/React.createElement(Flip, {
      w: 240,
      h: 180,
      flipped: flip,
      color: "blue",
      backColor: "green",
      cut: 1,
      backCut: 4,
      front: /*#__PURE__*/React.createElement("span", {
        style: {
          font: '900 32px/1.2 var(--f-display)'
        }
      }, "\uD83D\uDC65 \u0627\u0644\u0641\u0631\u064A\u0642"),
      back: /*#__PURE__*/React.createElement("span", {
        style: {
          font: '900 36px/1.2 var(--f-display)'
        }
      }, "\u0635\u0646\u062F\u0648\u0642")
    })))), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: 'var(--type-headline)',
        margin: 0,
        animation: 'bs-in .5s ease both',
        animationDelay: '2.2s'
      }
    }, "\u0627\u0644\u0641\u0631\u064A\u0642 = \u0627\u0644\u0635\u0646\u062F\u0648\u0642. \u0645\u0627 \u062A\u0631\u0627\u0647\u0646 \u0639\u0644\u0649 \u0644\u0627\u0639\u0628 \u0648\u0627\u062D\u062F."), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go(S.teamPick === 'team' ? 'team-win' : 'team-lose')
    }, "\u0634\u0648\u0641 \u0627\u0644\u0646\u062A\u064A\u062C\u0629"));
  }
  function TeamWin({
    go,
    onWin
  }) {
    return /*#__PURE__*/React.createElement(Result, {
      id: "team",
      win: true,
      tag: tag,
      go: go,
      onWin: onWin,
      headline: "\u064A\u0627 \u0633\u0644\u0627\u0627\u0627\u0645! \u0627\u0644\u0646\u062C\u0645 \u0637\u0627\u062D \u0628\u0633 \u0627\u0644\u0641\u0631\u064A\u0642 \u0643\u0645\u0651\u0644!",
      lesson: "\u0627\u0644\u0635\u0646\u062F\u0648\u0642 \u0627\u0644\u0645\u062A\u0646\u0648\u0639 \u0623\u0642\u0644 \u0645\u062E\u0627\u0637\u0631\u0629 \u0645\u0646 \u0627\u0644\u0633\u0647\u0645 \u0627\u0644\u0648\u0627\u062D\u062F.",
      scene: /*#__PURE__*/React.createElement(Pitch, {
        mode: "team",
        injured: true,
        w: 420,
        h: 280
      })
    });
  }
  function TeamLose({
    go,
    onWin
  }) {
    return /*#__PURE__*/React.createElement(Result, {
      id: "team",
      tag: tag,
      go: go,
      onWin: onWin,
      lesson: "\u0631\u0627\u0647\u0646\u062A \u0639\u0644\u0649 \u0644\u0627\u0639\u0628 \u0648\u0627\u062D\u062F \u0648\u0637\u0627\u062D\u060C \u0648\u0637\u0627\u062D\u062A \u0645\u0639\u0647 \u0641\u0644\u0648\u0633\u0643.",
      scene: /*#__PURE__*/React.createElement(Pitch, {
        mode: "star",
        injured: true,
        w: 420,
        h: 280
      })
    });
  }
  Object.assign(window, {
    TeamPick,
    TeamInjury,
    TeamReveal,
    TeamWin,
    TeamLose
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/baseer-app/TeamGame.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Assistant = __ds_scope.Assistant;

__ds_ns.CoachBubble = __ds_scope.CoachBubble;

__ds_ns.AssistantTip = __ds_scope.AssistantTip;

__ds_ns.CollageBand = __ds_scope.CollageBand;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Piece = __ds_scope.Piece;

__ds_ns.Wordmark = __ds_scope.Wordmark;

__ds_ns.Figure = __ds_scope.Figure;

__ds_ns.OutcomeCard = __ds_scope.OutcomeCard;

__ds_ns.StockCard = __ds_scope.StockCard;

__ds_ns.AmountField = __ds_scope.AmountField;

__ds_ns.ObligationField = __ds_scope.ObligationField;

__ds_ns.NavTabs = __ds_scope.NavTabs;

__ds_ns.StepIndicator = __ds_scope.StepIndicator;

__ds_ns.TopBar = __ds_scope.TopBar;

__ds_ns.FeatureCard = __ds_scope.FeatureCard;

__ds_ns.LevelPath = __ds_scope.LevelPath;

__ds_ns.StarRating = __ds_scope.StarRating;

})();
