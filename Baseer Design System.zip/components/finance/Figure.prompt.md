Big figure — the hero number of a screen (free margin) or a points award.
```jsx
<Figure label="هامشك الحر" value="1,500" />
```
