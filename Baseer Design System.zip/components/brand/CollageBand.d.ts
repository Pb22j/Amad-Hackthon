import * as React from 'react';
/** Torn blue paper band with cut-paper shapes, pinned to the bottom of a hero screen (parent must be position:relative). */
export interface CollageBandProps{
  /** CSS height, default clamp(150px,26vh,270px) */
  height?:string;
  style?:React.CSSProperties;
}
export declare function CollageBand(props:CollageBandProps):JSX.Element;
