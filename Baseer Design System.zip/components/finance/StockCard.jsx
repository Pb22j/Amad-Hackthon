import React from 'react';
import { Piece } from '../core/Piece.jsx';

const fmt=n=>Math.round(n).toLocaleString('en-US');

export function StockCard({name,sector,amount=0,color='blue',cut=1,tilt=0,onInc,onDec,incDisabled,decDisabled,dimEmpty=true,style,children}){
  const btn=(label,aria,fn,dis)=>React.createElement('button',{type:'button','aria-label':aria,onClick:fn,disabled:dis,style:{width:44,height:44,border:'2px solid currentColor',background:'transparent',font:'700 20px/1 var(--f-sans)',cursor:dis?'not-allowed':'pointer',opacity:dis?.35:1}},label);
  return React.createElement(Piece,{color,cut,lift:true,tilt,style:{width:180,height:210,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:8,opacity:dimEmpty&&amount===0?.45:1,transition:'opacity .2s, transform .5s cubic-bezier(.2,.8,.2,1)',...style}},
    React.createElement('span',{style:{font:'700 18px/1.4 var(--f-sans)'}},name),
    sector?React.createElement('span',{style:{font:'var(--type-caption)',marginTop:-8,opacity:.85}},sector):null,
    React.createElement('span',{style:{font:'700 34px/1.2 var(--f-display)',fontVariantNumeric:'tabular-nums'}},fmt(amount)),
    children||React.createElement('span',{style:{display:'flex',gap:8,marginTop:4}},btn('+','زد '+name,onInc,incDisabled),btn('−','نقّص '+name,onDec,decDisabled)));
}
